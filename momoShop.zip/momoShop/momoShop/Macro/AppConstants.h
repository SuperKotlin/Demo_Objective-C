//
//  AppHeader.h
//  ios-template
//  常量调用
//
//  Created by dmo on 15/11/19.
//  Copyright © 2015年 dmo. All rights reserved.
//

#ifndef AppHeader_h
#define AppHeader_h

//app名字
#define liz_AppName @"墨墨商城"

//审核专用账户
#define liz_user @"15855537219"

//支付宝回调
#define alipay_scheme  @"momoscAlipay"

//网页支付回调
#define kH5Alipay @"momoscH5Alipay"

//------------------------下面是未替换的
//支付提现等加密密钥
#define secret @"999dmooohuikexiong999"

//高德地图
#define GDKey @"9858299090e061ef596bb34d25c3ab26"

//腾讯
#define  tencentAppid  @"1108068770"

//微信
#define  wxKey  @"wx9c80af04be7d9b7c"
#define  wxSecret  @"0d78852bfec33cc9619d8dc810efb4a2"
#define  UNIVERSAL_LINK  @"https://com.dmo.jrsp/"

//极光推送
#define  JPushAppKey @"8e4c1f0c7f1188ee5f67dcfc"

//应用商店ID
#define  AppstoreID @""


#endif /* AppHeader_h */

