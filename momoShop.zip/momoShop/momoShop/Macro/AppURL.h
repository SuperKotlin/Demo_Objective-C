//
//  AppURL.h
//  ios-template
//  数据接口地址
//
//  Created by dmo on 15/11/19.
//  Copyright © 2015年 dmo. All rights reserved.
//

#ifndef AppURL_h
#define AppURL_h

//post
#define kPOST @"POST"
//get
#define kGET @"GET"
//token值
#define kToken @"token"
//响应代码
#define kError @"error"
//响应信息
#define kMessage @"msg"
//platform
#define kPlatform @"platform"
//version
#define kVersion @"version"
//ios
#define kIOS @"ios"

//线下
//#define kBaseURL @"http://9.future666.com"

//线上
#define kBaseURL @"http://open.dmooo.net"


//------------------------------Banner/广告管理接口------------------------------
//获取Banner/广告图列表
#define kGetBannerListURL kBaseURL @"/app.php?c=Banner&a=getBannerList"

//------------------------------商品管理接口------------------------------
//获取顶级商品分类列表
#define kGetParentCatListURL kBaseURL @"/app.php?c=GoodsCat&a=getParentCatList"
//获取子商品分类列表
#define kGetSubCatListURL kBaseURL @"/app.php?c=GoodsCat&a=getSubCatList"
//获取商品列表
#define kGetGoodsListURL kBaseURL @"/app.php?c=Goods&a=getGoodsList"
//获取商品详情
#define kGetGoodsMsgURL kBaseURL @"/app.php?c=Goods&a=getGoodsMsg"
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""

//------------------------------文章管理接口------------------------------
//获取文章列表
#define kGetArticleListURL kBaseURL @"/app.php?c=Article&a=getArticleList"
//获取文章内容
#define kGetArticleMsgURL kBaseURL @"/app.php?c=Article&a=getArticleMsg"

//------------------------------短信管理接口------------------------------
//发送验证码
#define kSendCodeURL kBaseURL @"/app.php?c=Sms&a=send"
//发送用户注册验证码
#define kSendUserRegisterURL kBaseURL @"/app.php?c=Sms&a=sendUserRegister"
//发送用户找回密码验证码
#define kSendUserFindpwdURL kBaseURL @"/app.php?c=Sms&a=sendUserFindpwd"
//发送用户变更手机号验证码
#define kSendChangeBandingURL kBaseURL @"/app.php?c=Sms&a=sendChangeBanding"
//验证短信验证码是否正确
#define kCheckCodeURL kBaseURL @"/app.php?c=Sms&a=checkCode"


//------------------------------用户账号管理接口------------------------------
//注册
#define kRegisterURL kBaseURL @"/app.php?c=UserAccount&a=register"
//登录
#define kLoginURL kBaseURL @"/app.php?c=UserAccount&a=login"
//使用手机找回密码
#define kFindPwdByPhoneURL kBaseURL @"/app.php?c=UserAccount&a=findPwdByPhone"


//------------------------------用户管理接口------------------------------
//获取用户信息
#define kGetUserMsgURL kBaseURL @"/app.php?c=User&a=getUserMsg"
//编辑用户信息
#define kEditUserMsgURL kBaseURL @"/app.php?c=User&a=editUserMsg"
//编辑用户头像
#define kEditUserAvatarURL kBaseURL @"/app.php?c=User&a=editUserAvatar"
//退出登录
#define kExitURL kBaseURL @"/app.php?c=User&a=loginout"
//修改密码
#define kChangePwdURL kBaseURL @"/app.php?c=User&a=changePwd"
//获取原手机验证码
#define kSendChangeBandCodeURL kBaseURL @"/app.php?c=User&a=sendChangeBandCode"
//变更绑定手机号
#define kChangeBandingPhoneURL kBaseURL @"/app.php?c=User&a=changeBandingPhone"


//------------------------------ ------------------------------
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""

//------------------------------收货地址管理接口------------------------------
//获取收货地址列表
#define kGetAddressListURL kBaseURL @"/app.php?c=ConsigneeAddress&a=getAddressList"
//获取收货地址信息
#define kGetAddressMsgURL kBaseURL @"/app.php?c=ConsigneeAddress&a=getAddressMsg"
//添加收货地址
#define kAddAddressURL kBaseURL @"/app.php?c=ConsigneeAddress&a=addAddress"
//编辑收货地址
#define kEditAddressURL kBaseURL @"/app.php?c=ConsigneeAddress&a=editAddress"
//删除收货地址
#define kDelAddressURL kBaseURL @"/app.php?c=ConsigneeAddress&a=delAddress"
//修改默认收货地址
#define kChangeDefaultURL kBaseURL @"/app.php?c=ConsigneeAddress&a=changeDefault"

//------------------------------ ------------------------------
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""


//------------------------------收藏商品管理接口------------------------------
//收藏商品
#define kCollectURL kBaseURL @"/app.php?c=GoodsCollect&a=collect"
//取消收藏
#define kCancelCollectURL kBaseURL @"/app.php?c=GoodsCollect&a=cancelCollect"
//获取用户收藏商品列表
#define kGetCollectListURL kBaseURL @"/app.php?c=GoodsCollect&a=getCollectList"
//用户是否收藏商品
#define kIs_collectURL kBaseURL @"/app.php?c=GoodsCollect&a=is_collect"


//------------------------------购物车管理接口------------------------------
//加入购物车
#define kShopcart_addURL kBaseURL @"/app.php?c=Shopcart&a=add"
//获取用户购物车列表
#define kGetShopcartListURL kBaseURL @"/app.php?c=Shopcart&a=getShopcartList"
//确认订单-购物车
#define kOrderByShopcartURL kBaseURL @"/app.php?c=Order&a=orderByShopcart"
//
#define kURL kBaseURL @""

//------------------------------订单管理接口------------------------------
//立即购买
#define kOrder_buyURL kBaseURL @"/app.php?c=Order&a=order"
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""


//------------------------------ ------------------------------
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""


//------------------------------ ------------------------------
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""


//------------------------------ ------------------------------
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""


//------------------------------ ------------------------------
//
#define kURL kBaseURL @""
//
#define kURL kBaseURL @""



#endif /* AppURL_h */
