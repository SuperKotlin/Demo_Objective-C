//
//  Macro.h
//  normal
//
//  Created by dmooo on 2019/2/13.
//  Copyright © 2019年 dm. All rights reserved.
//

#ifndef AppVariable_h
#define AppVariable_h

#import "AppConstants.h"
#import "AppURL.h"

/** 常用尺寸*/
// 当前屏幕宽度
#define kScreenWidth    [UIScreen mainScreen].bounds.size.width
// 当前屏幕高度
#define kScreenHeight   [UIScreen mainScreen].bounds.size.height
//导航栏高度
#define kNavigationBarHeight self.navigationController.navigationBar.frame.size.height
// 状态栏
#define kStatusHeight  ([[UIApplication sharedApplication] statusBarFrame].size.height>20.0?44.0: 20.0)
// 界面头部高度
#define kHeaderHeight  (kStatusHeight + kNavigationBarHeight)
//　底部标签栏高度
#define kTabBarHeight  ([[UIApplication sharedApplication] statusBarFrame].size.height>20.0?83.0:49.0)
//底部按钮往上偏移高度（只要用于X类型的手机）
#define kFooterHeight  ([[UIApplication sharedApplication] statusBarFrame].size.height>20.0?34.0:0)
//乘的比例
#define kBL kScreenWidth / 320

/** 根据屏幕尺寸判断机型*/
#define SCREEN_CURRENT_MODEL        [UIScreen instancesRespondToSelector:@selector(currentMode)]
//比例为3:2
#define k_iPhone4_4s      (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size) : NO)
//比例为16:9
#define k_iPhone5_5s      (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#define k_iPhone6_6s      (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) : NO)
#define k_iPhone6p_6sp    (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)
#define k_iPhone7     (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) : NO)
#define k_iPhone7p    (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)
#define k_iPhone8     (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) : NO)
#define k_iPhone8p    (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)
//比例为19.5：9
#define k_iPhoneX  (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)
#define k_iPhoneXR   (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size) : NO)
#define k_iPhoneXS    (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)
#define k_iPhoneXS_Max    (SCREEN_CURRENT_MODEL ? CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size) : NO)
//是否是iPhoneX|iPhoneXR|iPhoneXS|iPhoneXS_Max
#define k_iphone_XXX (kTabBarHeight>80 ? 1:0)

/** NSUserDefaults*/
#define kUserDefaults                           [NSUserDefaults standardUserDefaults]
#define kUserDefaults_SETOBJECT(value,key)      [kUserDefaults setObject:value forKey:key]
#define kUserDefaults_SETBOOL(value,key)         [kUserDefaults setBool:value forKey:key]
#define kUserDefaults_OBJECTFORKEY(key)          [kUserDefaults objectForKey:key]
#define kUserDefaults_BOOLFORKEY(key)            [kUserDefaults boolForKey:key]
#define kUserDefaults_REMOVEOBJECTFORKEY(key)    [kUserDefaults removeObjectForKey:key]
#define kUserDefaults_SYNCHRONIZE                [kUserDefaults synchronize]


/** NSNotificationCenter*/
#define NOTIFICATION_CENTER                     [NSNotificationCenter defaultCenter]

#define kTagStart 100

/** 颜色*/
//RGB
#define kRGB(r, g, b) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1]
//RGBA
#define kRGBA(r,g,b,a)  [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]
//十六进制颜色转换
#define kColorFromRGB(rgbValue)            [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
//UIColor
#define kWhiteColor  [UIColor whiteColor]
#define kClearColor  [UIColor clearColor]
#define kBlackColor  [UIColor blackColor]
#define kStatusColor  [UIColor blackColor]
#define kDefaultColor  kColorFromRGB(0xFF6600) // App整体风格基色
#define kGrayBgColor  kRGB(245,246,247) //(灰色) 页面灰色背景
#define k51Color  kRGB(51,51,51)
#define k44Color  kRGB(44,44,44)
#define k153Color kRGB(153, 153, 153)
#define k102Color kRGB(102, 102, 102)
#define k204Color kRGB(204, 204, 204)
#define kRedColor  kRGB(238,31,46)
#define kGrayLabColor  kRGB(165,165,165) //(灰色) 淡灰色的文字，比黑色的浅一点
#define kPinkColor  kRGB(255,192,203) //淡粉色
#define kRedBtnColor kRGB(250,25,8) //红色的按钮
#define k249Color kRGB(249, 249, 249)
#define k239Color kRGB(239, 239, 239)
#define k244Color kRGB(244, 244, 244)

/** 字体*/
#define kFONT(size) [UIFont systemFontOfSize:size]
//加粗
#define kFONT_BOLD(size) [UIFont boldSystemFontOfSize:size]

/** 避免循环引用*/
#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self
/** 图片*/
#define kImage(imageName) [UIImage imageNamed:imageName]

/** 提示通用语*/
//网络连接错误
#define kMessage_Network_Error             @"网络连接错误，请检查您的网络"
//网络请求错误
#define kMessage_Network_Failure           @"网络请求失败，请稍后再试"
//账号登录过期
#define kMessage_Login_Timeout          @"您的账号登录过期，请重新登录"
//没有更多数据
#define kMessage_NoMoreData          @"暂无更多数据"

#define kBuild @"1.0.0"

#define kis_open @"1" //上架开关


#endif /* Macro_h */
