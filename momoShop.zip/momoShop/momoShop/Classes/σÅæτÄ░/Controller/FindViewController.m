//
//  FindViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/12.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "FindViewController.h"

@interface FindViewController ()
@property (nonatomic,strong) UIView *headView;

@end

@implementation FindViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    //    return UIStatusBarStyleDefault;
    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    
}
#pragma mark ->Action Method
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kDefaultColor;

        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"发现" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor whiteColor];
        [_headView addSubview:label];

        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}

@end
