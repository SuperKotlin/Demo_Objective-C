//
//  User_funcCollectionViewCell.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/17.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "User_funcCollectionViewCell.h"

@implementation User_funcCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.iconImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 10 * kBL, kScreenWidth / 4.0, 20 * kBL)];
        self.iconImgV.contentMode = UIViewContentModeCenter;
        [self.contentView addSubview:self.iconImgV];
        
        self.titleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, self.iconImgV.maxY, kScreenWidth / 4.0, 24 * kBL)];
        self.titleLab.textColor = k102Color;
        self.titleLab.font = kFONT(15);
        self.titleLab.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:self.titleLab];
    }
    return self;
}

@end
