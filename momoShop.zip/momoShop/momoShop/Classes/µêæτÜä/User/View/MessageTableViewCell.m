//
//  MessageTableViewCell.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/17.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "MessageTableViewCell.h"

@implementation MessageTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.picImgV = [[UIImageView alloc] initWithFrame:CGRectMake(20 * kBL, 0, 34 * kBL, 34 * kBL)];
        self.picImgV.centerY = 23 * kBL;
        [self.contentView addSubview:self.picImgV];
        
        self.titleLab = [[UILabel alloc] initWithFrame:CGRectMake(self.picImgV.maxX + 5 * kBL, self.picImgV.minY, kScreenWidth - self.picImgV.maxX - 95 * kBL, 18 * kBL)];
        self.titleLab.font = kFONT(14);
        self.titleLab.textColor = kRGB(44,44,44);
        [self.contentView addSubview:self.titleLab];
        
        self.timeLab = [[UILabel alloc] initWithFrame:CGRectMake(self.titleLab.maxX, self.picImgV.minY, 70 * kBL, 18 * kBL)];
        self.timeLab.font = kFONT(14);
        self.timeLab.textColor = kRGB(44,44,44);
        self.timeLab.textAlignment = NSTextAlignmentRight;
        self.timeLab.maxX = kScreenWidth - 10 * kBL;
        [self.contentView addSubview:self.timeLab];
        
        self.conLab = [[UILabel alloc] initWithFrame:CGRectMake(self.titleLab.minX, self.titleLab.maxY, kScreenWidth - self.picImgV.maxX - 20 * kBL, 18 * kBL)];
        self.conLab.font = kFONT(14);
        self.conLab.textColor = k153Color;
        [self.contentView addSubview:self.conLab];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 45 * kBL, kScreenWidth, 1)];
        lineView.backgroundColor = kGrayBgColor;
        [self.contentView addSubview:lineView];
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
