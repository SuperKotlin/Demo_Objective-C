//
//  User_funcCollectionViewCell.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/17.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface User_funcCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *iconImgV;
@property (nonatomic,strong) UILabel *titleLab;

@end

NS_ASSUME_NONNULL_END
