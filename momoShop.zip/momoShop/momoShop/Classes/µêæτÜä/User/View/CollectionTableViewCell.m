//
//  CollectionTableViewCell.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/19.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "CollectionTableViewCell.h"

@implementation CollectionTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 8 * kBL)];
        lineView.backgroundColor = kGrayBgColor;
        [self.contentView addSubview:lineView];
        
        UIView *wView = [[UIView alloc] initWithFrame:CGRectMake(0, lineView.maxY, kScreenWidth, 94 * kBL)];
        wView.backgroundColor = kWhiteColor;
        [wView dmo_setCornerRadius:10.f];
        [self.contentView addSubview:wView];
        
        self.picImgV = [[UIImageView alloc] initWithFrame:CGRectMake(14 * kBL, 0, 68 * kBL, 68 * kBL)];
        self.picImgV.centerY = wView.height / 2.0;
        [wView addSubview:self.picImgV];

        self.titleLab = [[UILabel alloc] initWithFrame:CGRectMake(self.picImgV.maxX + 10, self.picImgV.minY, kScreenWidth - self.picImgV.maxX - 40 * kBL, 44 * kBL)];
        self.titleLab.font = kFONT(14);
        self.titleLab.textColor = kRGB(44,44,44);
        self.titleLab.numberOfLines = 0;
        [wView addSubview:self.titleLab];

        self.priceLab = [[UILabel alloc] initWithFrame:CGRectMake(self.titleLab.minX, self.titleLab.maxY, self.titleLab.width, 18 * kScreenWidth / 320)];
        self.priceLab.font = kFONT(16);
        self.priceLab.textColor = kRedColor;
        [wView addSubview:self.priceLab];
        
        self.buyBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 28 * kBL, 28 * kBL)];
        [self.buyBtn setImage:[UIImage imageNamed:@"collect_cart"] forState:UIControlStateNormal];
        [wView addSubview:self.buyBtn];
        self.buyBtn.maxX = wView.width - 6 * kBL;
        self.buyBtn.centerY = self.picImgV.centerY;
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
