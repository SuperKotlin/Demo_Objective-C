//
//  InfoViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/17.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "InfoViewController.h"
#import "DataChoosePopView.h"
#import <AVFoundation/AVCaptureDevice.h>
#import <AVFoundation/AVMediaFormat.h>
#import <Photos/Photos.h>

@interface InfoViewController ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIScrollView *mScrollView;
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) UIImageView *avatorImgV;
@property (nonatomic,strong) UITextField *nickTextField;
@property (nonatomic,strong) UITextField *nameTextField;
@property (nonatomic,strong) UILabel *phoneLab;
@property (nonatomic,strong) UIButton *manButton;
@property (nonatomic,strong) UIButton *womanButton;
@property (nonatomic,strong) UITextField *heightTextField;
@property (nonatomic,strong) UITextField *weightTextField;
@property (nonatomic,strong) UITextField *birTextField;
@property (nonatomic,strong) UITextField *qqTextField;
@property (nonatomic,strong) UITextField *signatureTextField;
//
@property (nonatomic,strong) UIView *centerView;
@property (nonatomic,strong) NSString *sexStr;

@end

@implementation InfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kWhiteColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.mScrollView];
    [self.mScrollView addSubview:self.topView];
    [self.mScrollView addSubview:self.centerView];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetUserMsgURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSDictionary *dataDict = [obj objectForKey:@"data"];
            NSDictionary *user_detail = dataDict[@"user_detail"];
            NSDictionary *user_msg = dataDict[@"user_msg"];
            [self.avatorImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",user_detail[@"avatar"]]] placeholderImage:[UIImage imageNamed:@"logo"]];
            if ([self isNil:user_detail[@"nickname"]]) {
                self.nickTextField.text = [NSString stringWithFormat:@"%@",user_msg[@"phone"]];
            }else{
                self.nickTextField.text = [NSString stringWithFormat:@"%@",user_detail[@"nickname"]];
            }
            if ([self isNil:user_detail[@"truename"]]) {
                self.nameTextField.text = @"";
            }else{
                self.nameTextField.text = [NSString stringWithFormat:@"%@",user_detail[@"truename"]];
            }
            self.phoneLab.text = [NSString stringWithFormat:@"%@",user_msg[@"phone"]];
            //性别 1男 2女 3保密
            NSString *sexd = [NSString stringWithFormat:@"%@",user_detail[@"sex"]];
            if ([sexd isEqualToString:@"1"]) {
                self.sexStr = @"1";
                [self.manButton setImage:[UIImage imageNamed:@"personal_pre"] forState:UIControlStateNormal];
                [self.womanButton setImage:[UIImage imageNamed:@"personal_nor"] forState:UIControlStateNormal];
            }else if ([sexd isEqualToString:@"2"]){
                self.sexStr = @"2";
                [self.manButton setImage:[UIImage imageNamed:@"personal_nor"] forState:UIControlStateNormal];
                [self.womanButton setImage:[UIImage imageNamed:@"personal_pre"] forState:UIControlStateNormal];
            }else{
                self.sexStr = @"3";
                [self.manButton setImage:[UIImage imageNamed:@"personal_nor"] forState:UIControlStateNormal];
                [self.womanButton setImage:[UIImage imageNamed:@"personal_nor"] forState:UIControlStateNormal];
            }
            if ([self isNil:user_detail[@"height"]]) {
                self.heightTextField.text = @"";
            }else{
                self.heightTextField.text = [NSString stringWithFormat:@"%@",user_detail[@"height"]];
            }
            if ([self isNil:user_detail[@"weight"]]) {
                self.weightTextField.text = @"";
            }else{
                self.weightTextField.text = [NSString stringWithFormat:@"%@",user_detail[@"weight"]];
            }
            if ([self isNil:user_detail[@"birthday"]]) {
                self.birTextField.text = @"";
            }else{
                self.birTextField.text = [NSString stringWithFormat:@"%@",user_detail[@"birthday"]];
            }
            
            if ([self isNil:user_detail[@"qq"]]) {
                self.qqTextField.text = @"";
            }else{
                self.qqTextField.text = [NSString stringWithFormat:@"%@",user_detail[@"qq"]];
            }
            if ([self isNil:user_detail[@"signature"]]) {
                self.signatureTextField.text = @"";
            }else{
                self.signatureTextField.text = [NSString stringWithFormat:@"%@",user_detail[@"signature"]];
            }
            
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->Action Method
- (void)finishButtonAction{
    if ([self.nickTextField.text isEqualToString:@""]) {
        [self showMessage:@"请填写昵称" delay:1.5];
        return;
    }
    
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken),
                                 @"nickname":self.nickTextField.text,
                                 @"truename":self.nameTextField.text,
                                 @"sex":self.sexStr,
                                 @"height":self.heightTextField.text,
                                 @"weight":self.weightTextField.text,
                                 @"blood":@"", //血型 1A型 2B型 3AB型 4O型 5其它
                                 @"birthday":self.birTextField.text,
                                 @"qq":self.qqTextField.text,
                                 @"weixin":@"",
                                 @"province":@"",
                                 @"city":@"",
                                 @"county":@"",
                                 @"detail_address":@"",
                                 @"signature":self.signatureTextField.text
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kEditUserMsgURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self.navigationController popViewControllerAnimated:YES];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"UserViewRefresh" object:nil userInfo:nil];
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
- (void)photoAction{
    UIAlertController *alert = [UIAlertController
                                alertControllerWithTitle:nil
                                message:nil
                                preferredStyle:UIAlertControllerStyleActionSheet];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (status == AVAuthorizationStatusRestricted || status == AVAuthorizationStatusDenied){
            // 无权限
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"请您设置允许该应用访问您的相机\n设置>隐私>相机" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action) {
                
            }];
            [alert addAction:okAction];
            [self presentViewController:alert animated:true completion:nil];
            
            return;
        }
        
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {//相机权限
            if (granted) {
                NSLog(@"Authorized");
                // Hide the keyboard
                [self takePhoto];
            }else{
                NSLog(@"Denied or Restricted");
            }
        }];
        
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {}]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"从相册中选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        //----第一次不会进来
        PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
        if (status == PHAuthorizationStatusRestricted || status == PHAuthorizationStatusDenied){
            // 无权限 做一个友好的提示
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"请您设置允许该应用访问您的相册\n设置>隐私>照片" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action) {
                
            }];
            [alert addAction:okAction];
            [self presentViewController:alert animated:true completion:nil];
            
            return;
        }
        
        //----每次都会走进来
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            if (status == PHAuthorizationStatusAuthorized) {
                NSLog(@"Authorized");
                [self LocalPhoto];
            }else if (status == PHAuthorizationStatusDenied) {
                NSLog(@"用户拒绝当前应用访问相册,我们需要提醒用户打开访问开关");
            }else{
                NSLog(@"其他原因");
            }
        }];
        
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}
//从相册选择
-(void)LocalPhoto{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    //资源类型为图片库
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    //设置选择后的图片可被编辑
    //    picker.allowsEditing = YES;
    //    [[XGetCurrentInfo getCurrentVC] presentViewController:picker animated:YES completion:nil];
//    [[[[UIApplication sharedApplication]delegate]window].rootViewController presentViewController:picker animated:YES completion:nil];
    [self.navigationController presentViewController:picker animated:YES completion:nil];
}
//拍照
- (void)takePhoto{
    //资源类型为照相机
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    //判断是否有相机
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]){
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        //设置拍照后的图片可被编辑
        //        picker.allowsEditing = YES;
        //资源类型为照相机
        picker.sourceType = sourceType;
        //        [[XGetCurrentInfo getCurrentVC] presentViewController:picker animated:YES completion:^{}];
//        [[[[UIApplication sharedApplication]delegate]window].rootViewController presentViewController:picker animated:YES completion:nil];
        [self.navigationController presentViewController:picker animated:YES completion:nil];
    }else {
        //        NSLog(@"该设备无摄像头");
    }
}
#pragma Delegate method UIImagePickerControllerDelegate
//图像选取器的委托方法，选完图片后回调该方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    [self startMultiPartUploadTaskWithURL:kEditUserAvatarURL imagesArray:@[image] parameterOfimages:@"user_avatar" parametersDict:parameters compressionRatio:0.5 succeedBlock:^(NSDictionary *dict) {
        NSLog(@"qwer %@",dict);
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"])  {
            self.avatorImgV.image = image;
            [self showMessage:dict[kMessage] delay:1.5];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"UserViewRefresh" object:nil userInfo:nil];
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:dict[kMessage] delay:1.5];
        }
        
    } failedBlock:^(NSError *error) {
        
    }];
    
    //关闭相册界面
    [picker dismissViewControllerAnimated:YES completion:nil];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info{
    NSLog(@"info==%@",info);
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    [self startMultiPartUploadTaskWithURL:kEditUserAvatarURL imagesArray:@[info[@"UIImagePickerControllerOriginalImage"]] parameterOfimages:@"user_avatar" parametersDict:parameters compressionRatio:0.5 succeedBlock:^(NSDictionary *dict) {
        NSLog(@"qwer %@",dict);
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"])  {
            self.avatorImgV.image = info[@"UIImagePickerControllerOriginalImage"];
            [self showMessage:dict[kMessage] delay:1.5];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"UserViewRefresh" object:nil userInfo:nil];
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:dict[kMessage] delay:1.5];
        }
        
    } failedBlock:^(NSError *error) {
        [self showMessage:@"上传失败" delay:1.5];
    }];
    
    //关闭相册界面
    [picker dismissViewControllerAnimated:YES completion:nil];
}
- (void)manButtonAction:(UIButton *)sender{
    [self.manButton setImage:[UIImage imageNamed:@"personal_pre"] forState:UIControlStateNormal];
    [self.womanButton setImage:[UIImage imageNamed:@"personal_nor"] forState:UIControlStateNormal];
    self.sexStr = @"1";
}
- (void)womanButtonAction:(UIButton *)sender{
    [self.manButton setImage:[UIImage imageNamed:@"personal_nor"] forState:UIControlStateNormal];
    [self.womanButton setImage:[UIImage imageNamed:@"personal_pre"] forState:UIControlStateNormal];
    self.sexStr = @"2";
}
- (void)birButtonAction{
    [DataChoosePopView initWithBlock:^(NSString *date) {
        self.birTextField.text = date;
    }];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = [UIColor whiteColor];
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"个人资料" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIButton *searchButton = [[UIButton alloc]initWithFrame:CGRectMake(0, kStatusHeight, 50 * kBL, kNavigationBarHeight)];
        [searchButton setTitle:@"保存" forState:UIControlStateNormal];
        [searchButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        searchButton.titleLabel.font = kFONT(15);
        searchButton.maxX = kScreenWidth - 2 * kBL;
        [searchButton addTarget:self action:@selector(finishButtonAction) forControlEvents:UIControlEventTouchUpInside];
        [_headView addSubview:searchButton];
    }
    return _headView;
}
- (UIScrollView *)mScrollView{
    if (!_mScrollView) {
        _mScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - _headView.maxY)];
        _mScrollView.backgroundColor = kWhiteColor;
    }
    return _mScrollView;
}
- (UIView *)topView{
    if (!_topView) {
        _topView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 5 * 40 * kBL)];
        NSArray *tArr = @[@"头像",@"昵称",@"用户名",@"手机号",@"性别"];
        for (int i = 0; i < 5; i ++) {
            UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 40 * kBL * i, 80 * kBL, 40 * kBL)];
            leftLabel.font = kFONT(14);
            leftLabel.text = tArr[i];
            [_topView addSubview:leftLabel];
            
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, leftLabel.maxY - 1, kScreenWidth, 1)];
            lineView.backgroundColor = kGrayBgColor;
            [_topView addSubview:lineView];
            
            if (i == 0 || i == 3) {
                UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 5 * kBL, 11 * kBL)];
                rImgV.image = [UIImage imageNamed:@"set_next"];
                rImgV.centerY = 20 * kBL;
                rImgV.maxX = kScreenWidth - 10 * kBL;
                [_topView addSubview:rImgV];
            }
        }
        
        _avatorImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 34 * kBL, 34 * kBL)];
        [_avatorImgV dmo_setCornerRadius:17 * kBL];
        _avatorImgV.centerY = 20 * kBL;
        _avatorImgV.maxX = kScreenWidth - 30 * kBL;
        [_topView addSubview:_avatorImgV];
        _avatorImgV.backgroundColor = kWhiteColor;
        _avatorImgV.clipsToBounds = YES;
        _avatorImgV.contentMode =  UIViewContentModeScaleAspectFill;
        
        _avatorImgV.userInteractionEnabled = YES;
        UITapGestureRecognizer *sing2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoAction)];
        [_avatorImgV addGestureRecognizer:sing2];
        
        _nickTextField = [[UITextField alloc] initWithFrame:CGRectMake(90 * kBL, 40 * kBL, kScreenWidth - 100 * kBL, 40 * kBL)];
        _nickTextField.font = kFONT(14);
        _nickTextField.textAlignment = NSTextAlignmentRight;
        [_topView addSubview:_nickTextField];
        
        _nameTextField = [[UITextField alloc] initWithFrame:CGRectMake(_nickTextField.minX, _nickTextField.maxY, _nickTextField.width, _nickTextField.height)];
        _nameTextField.font = kFONT(14);
        _nameTextField.textAlignment = NSTextAlignmentRight;
        _nameTextField.placeholder = @"填写姓名";
        [_topView addSubview:_nameTextField];
        
        _phoneLab = [[UILabel alloc] initWithFrame:CGRectMake(_nickTextField.minX, _nameTextField.maxY, _nickTextField.width, _nickTextField.height)];
        _phoneLab.font = kFONT(14);
        _phoneLab.textAlignment = NSTextAlignmentRight;
        [_topView addSubview:_phoneLab];
        
        _manButton = [[UIButton alloc] initWithFrame:CGRectMake(kScreenWidth - 96 * kBL, 0, 16 * kBL, 16 * kBL)];
        [_manButton setImage:[UIImage imageNamed:@"personal_pre"] forState:UIControlStateNormal];
        [_manButton addTarget:self action:@selector(manButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [_topView addSubview:_manButton];
        
        UILabel *manLabel = [[UILabel alloc] initWithFrame:CGRectMake(_manButton.maxX, _phoneLab.maxY, 30 * kBL, _nameTextField.height)];
        manLabel.font = kFONT(14);
        manLabel.text = @"男";
        [_topView addSubview:manLabel];
        _manButton.centerY = manLabel.centerY;
        
        _womanButton = [[UIButton alloc] initWithFrame:CGRectMake(manLabel.maxX, 0, 16 * kBL, 16 * kBL)];
        [_womanButton setImage:[UIImage imageNamed:@"personal_nor"] forState:UIControlStateNormal];
        _womanButton.centerY = manLabel.centerY;
        [_womanButton addTarget:self action:@selector(womanButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [_topView addSubview:_womanButton];
        
        UILabel *womanLabel = [[UILabel alloc] initWithFrame:CGRectMake(_womanButton.maxX, 0, manLabel.width, manLabel.height)];
        womanLabel.font = kFONT(14);
        womanLabel.text = @"女";
        womanLabel.centerY = manLabel.centerY;
        [_topView addSubview:womanLabel];
    }
    return _topView;
}
- (UIView *)centerView{
    if (!_centerView) {
        _centerView = [[UIView alloc] initWithFrame:CGRectMake(0, _topView.maxY, kScreenWidth, 5 * 40 * kBL)];
        NSArray *tArr = @[@"身高",@"体重",@"生日",@"QQ",@"个性签名"];
        for (int i = 0; i < 5; i ++) {
            UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 40 * kBL * i, 80 * kBL, 40 * kBL)];
            leftLabel.font = kFONT(14);
            leftLabel.text = tArr[i];
            [_centerView addSubview:leftLabel];
            
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, leftLabel.maxY - 1, kScreenWidth, 1)];
            lineView.backgroundColor = kGrayBgColor;
            [_centerView addSubview:lineView];
        }
        
        _heightTextField = [[UITextField alloc] initWithFrame:CGRectMake(90 * kBL, 0, kScreenWidth - 100 * kBL, 40 * kBL)];
        _heightTextField.font = kFONT(14);
        _heightTextField.textAlignment = NSTextAlignmentRight;
        _heightTextField.placeholder = @"填写身高";
        [_centerView addSubview:_heightTextField];
        
        _weightTextField = [[UITextField alloc] initWithFrame:CGRectMake(_heightTextField.minX, _heightTextField.maxY, _heightTextField.width, _heightTextField.height)];
        _weightTextField.font = kFONT(14);
        _weightTextField.textAlignment = NSTextAlignmentRight;
        _weightTextField.placeholder = @"填写体重";
        [_centerView addSubview:_weightTextField];
        
        _birTextField = [[UITextField alloc] initWithFrame:CGRectMake(_heightTextField.minX, _weightTextField.maxY, _heightTextField.width, _heightTextField.height)];
        _birTextField.font = kFONT(14);
        _birTextField.textAlignment = NSTextAlignmentRight;
        _birTextField.placeholder = @"选择生日";
        [_centerView addSubview:_birTextField];
        _birTextField.userInteractionEnabled = YES;
        UITapGestureRecognizer *sing2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(birButtonAction)];
        [_birTextField addGestureRecognizer:sing2];
        
        _qqTextField = [[UITextField alloc] initWithFrame:CGRectMake(_heightTextField.minX, _birTextField.maxY, _heightTextField.width, _heightTextField.height)];
        _qqTextField.font = kFONT(14);
        _qqTextField.textAlignment = NSTextAlignmentRight;
        _qqTextField.placeholder = @"填写QQ";
        [_centerView addSubview:_qqTextField];
        
        _signatureTextField = [[UITextField alloc] initWithFrame:CGRectMake(_heightTextField.minX, _qqTextField.maxY, _heightTextField.width, _heightTextField.height)];
        _signatureTextField.font = kFONT(14);
        _signatureTextField.textAlignment = NSTextAlignmentRight;
        _signatureTextField.placeholder = @"填写个性签名";
        [_centerView addSubview:_signatureTextField];
    }
    return _centerView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
