//
//  UserViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/5.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "UserViewController.h"
#import "SetViewController.h"
#import "User_funcCollectionViewCell.h"
#import "InfoViewController.h"
#import "MessageViewController.h"
#import "PointSignViewController.h"
#import "AboutUsViewController.h" //关于我们
#import "CollectionViewController.h" //收藏
#import "MyPointViewController.h" //积分

@interface UserViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong) UIScrollView *mScrollView;
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIImageView *avatorImgV;
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) UIView *orderView;
@property (nonatomic,strong) UIView *ggView;
@property (nonatomic,strong) UICollectionView *funcCollectionView;
@property (nonatomic,strong) NSMutableArray *funMutArr;
@property (nonatomic,strong) NSDictionary *dataDict;

@end

@implementation UserViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self getFun];
    [self initData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(UserViewRefresh) name:@"UserViewRefresh" object:nil];
}
- (void)UserViewRefresh{
    [self initData];
    [self getFun];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
//    return UIStatusBarStyleDefault;
    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark - collectionview代理方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.funMutArr.count;
}
#pragma mark - cell显示的内容
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    User_funcCollectionViewCell *cell = (User_funcCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    if (cell == nil) {
        
    }
    
    NSDictionary *dataDict = self.funMutArr[indexPath.row];
    cell.titleLab.text = [NSString stringWithFormat:@"%@",dataDict[@"name"]];
    cell.iconImgV.image = [UIImage imageNamed:dataDict[@"icon"]];
    
    return cell;
}
#pragma mark - cell选择点击
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        User_funcCollectionViewCell *cell = (User_funcCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
        if ([cell.titleLab.text isEqualToString:@"收藏"]) {
            [self.navigationController pushViewController:[CollectionViewController new] animated:YES];
        }else if ([cell.titleLab.text isEqualToString:@"钱包"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"积分"]) {
            MyPointViewController *pointV = [[MyPointViewController alloc] init];
            [self.navigationController pushViewController:pointV animated:YES];
        }else if ([cell.titleLab.text isEqualToString:@"优惠券"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"充值卡"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"客服"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"反馈"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"关于"]) {
            [self.navigationController pushViewController:[AboutUsViewController new] animated:YES];
        }
    }
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.mScrollView];
    [self.mScrollView addSubview:self.headView];
    [self.mScrollView addSubview:self.orderView];
    [self.mScrollView addSubview:self.ggView];
    [self.mScrollView addSubview:self.funcCollectionView];
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, kScreenHeight - kHeaderHeight - kTabBarHeight);
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        self.avatorImgV.image = [UIImage imageNamed:@"logo"];
        self.nameLab.text = @"您还未登录，请先登录或注册";
        self.nameLab.userInteractionEnabled = YES;
    }else{
        self.nameLab.userInteractionEnabled = NO;
        NSDictionary *parameters = @{
                                     kPlatform:kIOS,
                                     kVersion:kBuild,
                                     kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                     };
        [self showLoad];
        [[DmoNetwork dmo_network] dmo_requestWith:kGetUserMsgURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
            [self hideLoad];
            if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                self.dataDict = [obj objectForKey:@"data"];
                NSDictionary *user_detail = self.dataDict[@"user_detail"];
                NSDictionary *user_msg = self.dataDict[@"user_msg"];
                [self.avatorImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",user_detail[@"avatar"]]] placeholderImage:[UIImage imageNamed:@"logo"]];
                
                if ([self isNil:user_detail[@"nickname"]]) {
                    self.nameLab.text = [NSString stringWithFormat:@"%@",user_msg[@"phone"]];
                }else{
                    self.nameLab.text = [NSString stringWithFormat:@"%@",user_detail[@"nickname"]];
                }
                
            }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
                [self toLoginVC:@"UserVC"];
            }else{
                [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            }
        } failure:^(NSString * _Nonnull errMessage) {
            [self hideLoad];
            [self showMessage:kMessage_Network_Failure delay:1.5];
        } requestType:requestTypePost];
    }
    [self.mScrollView.mj_header endRefreshing];
}
- (void)getFun{
    self.funMutArr = [NSMutableArray array];
    //上架处理
    if ([[NSString stringWithFormat:@"%@",kUserDefaults_OBJECTFORKEY(@"user_phone")] isEqualToString:@""] || [[NSString stringWithFormat:@"%@",kUserDefaults_OBJECTFORKEY(@"user_phone")] isEqualToString:@"17512543194"]) {
        [self.funMutArr addObjectsFromArray:@[@{@"icon":@"user_collect",@"name":@"收藏"},@{@"icon":@"user_wallet",@"name":@"钱包"},@{@"icon":@"user_integral",@"name":@"积分"},@{@"icon":@"user_coupon",@"name":@"优惠券"},@{@"icon":@"user_recharge",@"name":@"充值卡"},@{@"icon":@"user_service",@"name":@"客服"},@{@"icon":@"user_feedback",@"name":@"反馈"},@{@"icon":@"user_help",@"name":@"关于"}]];
        self.funcCollectionView.height = 64 * kBL * 2;
    }else{
        [self.funMutArr addObjectsFromArray:@[@{@"icon":@"user_collect",@"name":@"收藏"},@{@"icon":@"user_wallet",@"name":@"钱包"},@{@"icon":@"user_integral",@"name":@"积分"},@{@"icon":@"user_coupon",@"name":@"优惠券"},@{@"icon":@"user_recharge",@"name":@"充值卡"},@{@"icon":@"user_service",@"name":@"客服"},@{@"icon":@"user_feedback",@"name":@"反馈"},@{@"icon":@"user_help",@"name":@"关于"}]];
        self.funcCollectionView.height = 64 * kBL * 2;
    }
    [self.funcCollectionView reloadData];
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, self.funcCollectionView.maxY + 10);
}
#pragma mark ->Action Method
- (void)setBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        [self.navigationController pushViewController:[SetViewController new] animated:YES];
    }
}
- (void)messBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        [self.navigationController pushViewController:[MessageViewController new] animated:YES];
    }
}
- (void)infoAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        InfoViewController *inV = [[InfoViewController alloc] init];
        [self.navigationController pushViewController:inV animated:YES];
    }
}
//签到领积分
- (void)signBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        PointSignViewController *sV = [[PointSignViewController alloc] init];
        [self.navigationController pushViewController:sV animated:YES];
    }
}
- (void)orderMoreBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        
    }
}
- (void)onFunBtnAction:(UIButton *)sender{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
//        OrderViewController *orVC = [[OrderViewController alloc] init];
//        if (sender.tag - kTagStart == 3) {
//            orVC.itemIndex = 0;
//        }else{
//            orVC.itemIndex = sender.tag - kTagStart + 1;
//        }
//        orVC.type = @"1";
//        [self.navigationController pushViewController:orVC animated:YES];
    }
}

#pragma mark ->setter/getter Method
- (UIScrollView *)mScrollView{
    if (!_mScrollView) {
        _mScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight - kTabBarHeight)];
        _mScrollView.backgroundColor = kGrayBgColor;
        
        if (@available(iOS 11.0, *)){
//            if ([[NSString stringWithFormat:@"%d",kPhoneType] isEqualToString:@"1"]) {
//                _mScrollView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
//            }else{
//                _mScrollView.contentInset = UIEdgeInsetsMake(-kStatusHeight, 0, 0, 0);
//            }
            _mScrollView.contentInset = UIEdgeInsetsMake(-kStatusHeight, 0, 0, 0);
        }
        WS(ws);
        _mScrollView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [ws initData];
        }];
    }
    return _mScrollView;
}
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 146 * kBL)];
        _headView.backgroundColor = kGrayBgColor;
        
        UIImageView *bgImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, _headView.height)];
        bgImgV.image = [UIImage imageNamed:@"user_bg"];
        [_headView addSubview:bgImgV];
        bgImgV.userInteractionEnabled = YES;
        
        UIButton *setBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, kStatusHeight, 34 * kBL, 34 * kBL)];
        [setBtn setImage:[UIImage imageNamed:@"user_set"] forState:UIControlStateNormal];
        [setBtn addTarget:self action:@selector(setBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [bgImgV addSubview:setBtn];
        setBtn.maxX = kScreenWidth - 40 * kBL;
        
        UIButton *messBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, kStatusHeight, 34 * kBL, 34 * kBL)];
        [messBtn setImage:[UIImage imageNamed:@"user_message"] forState:UIControlStateNormal];
        [messBtn addTarget:self action:@selector(messBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [bgImgV addSubview:messBtn];
        messBtn.maxX = kScreenWidth;
        
        _avatorImgV = [[UIImageView alloc] initWithFrame:CGRectMake(10 * kBL, 0, 56 * kBL, 56 * kBL)];
        [_avatorImgV dmo_setCornerRadius:28 * kBL];
        [_avatorImgV dmo_setBorder:4.f color:kWhiteColor];
        _avatorImgV.maxY = bgImgV.height - 24 * kBL;
        [bgImgV addSubview:_avatorImgV];
        _avatorImgV.backgroundColor = kWhiteColor;
        _avatorImgV.clipsToBounds = YES;
        _avatorImgV.contentMode =  UIViewContentModeScaleAspectFill;
        
        _avatorImgV.userInteractionEnabled = YES;
        UITapGestureRecognizer *sing1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(infoAction)];
        [_avatorImgV addGestureRecognizer:sing1];
        
        _nameLab = [[UILabel alloc] initWithFrame:CGRectMake(_avatorImgV.maxX + 12 * kBL, 0, kScreenWidth - _avatorImgV.maxX - 22 * kBL, 50 * kBL)];
        _nameLab.textColor = kWhiteColor;
        _nameLab.numberOfLines = 0;
        _nameLab.font = kFONT_BOLD(16);
        [bgImgV addSubview:_nameLab];
        _nameLab.centerY = _avatorImgV.centerY;
        
        _nameLab.userInteractionEnabled = NO;
        UITapGestureRecognizer *sing2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(infoAction)];
        [_nameLab addGestureRecognizer:sing2];
        
        UIButton *signBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 80 * kBL, 30 * kBL)];
        signBtn.backgroundColor = kDefaultColor;
        [signBtn addTarget:self action:@selector(signBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [bgImgV addSubview:signBtn];
        signBtn.maxY = _headView.height - 16 * kBL;
        signBtn.maxX = _headView.width;
        
        UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:signBtn.bounds byRoundingCorners:UIRectCornerTopLeft | UIRectCornerBottomLeft   cornerRadii:CGSizeMake(15 * kBL, 15 * kBL)];
        CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
        maskLayer.frame = signBtn.bounds;
        maskLayer.path = maskPath.CGPath;
        signBtn.layer.mask = maskLayer;
        
        UIImageView *signImgV = [[UIImageView alloc] initWithFrame:CGRectMake(7 * kBL, 0, 14 * kBL, 14 * kBL)];
        signImgV.centerY = signBtn.height / 2.0;
        signImgV.image = [UIImage imageNamed:@"user_sign"];
        [signBtn addSubview:signImgV];
        
        UILabel *signLab = [[UILabel alloc] initWithFrame:CGRectMake(signImgV.maxX, 0, signBtn.width - signImgV.maxX, signBtn.height)];
        signLab.textColor = kWhiteColor;
        signLab.font = kFONT(13);
        signLab.textAlignment = NSTextAlignmentCenter;
        signLab.text = @"签到领积分";
        [signBtn addSubview:signLab];
    }
    return _headView;
}
- (UIView *)orderView{
    if (!_orderView) {
        _orderView = [[UIView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, 112 * kBL)];
        _orderView.backgroundColor = kWhiteColor;
        
        UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, kScreenWidth / 2.0, 36 * kBL)];
        titleLab.font = kFONT(16);
        titleLab.textColor = [UIColor blackColor];
        titleLab.text = @"我的订单";
        [_orderView addSubview:titleLab];
        
        UILabel *moreLab = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, kScreenWidth / 2.0, titleLab.height)];
        moreLab.font = kFONT(15);
        moreLab.textColor = kRGB(153,153,153);
        moreLab.text = @"查看全部订单";
        moreLab.textAlignment = NSTextAlignmentRight;
        moreLab.maxX = kScreenWidth - 22 * kBL;
        [_orderView addSubview:moreLab];
        
        UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 7 * kBL, 12 * kBL)];
        rImgV.image = [UIImage imageNamed:@"order_next"];
        rImgV.maxX = kScreenWidth - 12 * kBL;
        [_orderView addSubview:rImgV];
        rImgV.centerY = moreLab.centerY;
        
        UIButton *localMoreBtn = [[UIButton alloc] initWithFrame:CGRectMake(moreLab.minX, 0, kScreenWidth - moreLab.minX, titleLab.height)];
        [localMoreBtn addTarget:self action:@selector(orderMoreBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_orderView addSubview:localMoreBtn];
        
        UIView *lView = [[UIView alloc] initWithFrame:CGRectMake(0, titleLab.maxY, kScreenWidth, 1)];
        lView.backgroundColor = kGrayBgColor;
        [_orderView addSubview:lView];
        
        UIView *fuView = [[UIView alloc] initWithFrame:CGRectMake(0, lView.maxY, kScreenWidth, _orderView.height - lView.maxY)];
        [_orderView addSubview:fuView];
        
        NSArray *onIcon = @[@"user_daifukuan",@"user_daifahuo",@"user_daishouhuo",@"user_tuihuo"];
        NSArray *onText = @[@"待付款",@"待发货",@"待收货",@"退换/售后"];
        for (int i = 0; i < 4; i ++) {
            UIButton *onFunBtn = [[UIButton alloc] initWithFrame:CGRectMake(kScreenWidth / 4.0 * i, 0, kScreenWidth / 4.0, fuView.height)];
            onFunBtn.tag = kTagStart + i;
            [onFunBtn addTarget:self action:@selector(onFunBtnAction:) forControlEvents:UIControlEventTouchUpInside];
            [fuView addSubview:onFunBtn];
            
            UIImageView *onImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 16 * kBL, 20 * kBL, 20 * kBL)];
            onImgV.image = [UIImage imageNamed:onIcon[i]];
            onImgV.centerX = onFunBtn.width / 2.0;
            [onFunBtn addSubview:onImgV];
            
            UILabel *tLab = [[UILabel alloc] initWithFrame:CGRectMake(0, onImgV.maxY + 10 * kBL, onFunBtn.width, 28)];
            tLab.text = onText[i];
            tLab.textAlignment = NSTextAlignmentCenter;
            tLab.font = kFONT(15);
            tLab.textColor = k102Color;
            [onFunBtn addSubview:tLab];
        }
    }
    return _orderView;
}
- (UIView *)ggView{
    if (!_ggView) {
        _ggView = [[UIView alloc] initWithFrame:CGRectMake(0, _orderView.maxY + 6 * kBL, kScreenWidth, 74 * kBL)];
        _ggView.backgroundColor = [UIColor whiteColor];

        UIImageView *ggImgV = [[UIImageView alloc] initWithFrame:CGRectMake(18 * kBL, 0, kScreenWidth - 36 * kBL, 68 * kBL)];
        ggImgV.image = [UIImage imageNamed:@"user_ad"];
        [_ggView addSubview:ggImgV];
    }
    return _ggView;
}
- (UIScrollView *)funcCollectionView{
    if(!_funcCollectionView){
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 0;
        layout.itemSize = CGSizeMake(kScreenWidth / 4, 64 * kBL);
        
        _funcCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, _ggView.maxY + 6 * kBL, kScreenWidth, 64 * kBL * 3) collectionViewLayout:layout];
        _funcCollectionView.scrollEnabled = NO;
        _funcCollectionView.backgroundColor = [UIColor whiteColor];
        _funcCollectionView.dataSource = self;
        _funcCollectionView.delegate = self;
        [_funcCollectionView registerClass:[User_funcCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    }
    return _funcCollectionView;
}

@end
