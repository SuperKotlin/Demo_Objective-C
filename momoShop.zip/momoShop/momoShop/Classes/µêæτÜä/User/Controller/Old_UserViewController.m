//
//  Old_UserViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/10.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "Old_UserViewController.h"
#import "SetViewController.h"
#import "User_funcCollectionViewCell.h"
#import "InfoViewController.h"
#import "MessageViewController.h"

@interface Old_UserViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong) UIScrollView *mScrollView;
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIImageView *avatorImgV;
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) UIView *orderView;
//钱包
@property (nonatomic,strong) UIView *waltView;
@property (nonatomic,strong) UILabel *balanceLab;
@property (nonatomic,strong) UILabel *quanLab;
@property (nonatomic,strong) UILabel *pointLab;
//常用工具
@property (nonatomic,strong) UIView *toolView;
@property (nonatomic,strong) UICollectionView *funcCollectionView;
@property (nonatomic,strong) NSMutableArray *funMutArr;
@property (nonatomic,strong) NSDictionary *dataDict;

@end

@implementation Old_UserViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self getFun];
    [self initData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(UserViewRefresh) name:@"UserViewRefresh" object:nil];
}
- (void)UserViewRefresh{
    [self initData];
    [self getFun];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    //    return UIStatusBarStyleDefault;
    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark - collectionview代理方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.funMutArr.count;
}
#pragma mark - cell显示的内容
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    User_funcCollectionViewCell *cell = (User_funcCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    if (cell == nil) {
        
    }
    
    NSDictionary *dataDict = self.funMutArr[indexPath.row];
    cell.titleLab.text = [NSString stringWithFormat:@"%@",dataDict[@"name"]];
    cell.iconImgV.image = [UIImage imageNamed:dataDict[@"icon"]];
    
    return cell;
}
#pragma mark - cell选择点击
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        User_funcCollectionViewCell *cell = (User_funcCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
        if ([cell.titleLab.text isEqualToString:@"我的收藏"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"收货地址"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"优惠券"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"我的钱包"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"发票信息"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"消息通知"]) {
            [self.navigationController pushViewController:[MessageViewController new] animated:YES];
        }else if ([cell.titleLab.text isEqualToString:@"客服中心"]) {
            
        }else if ([cell.titleLab.text isEqualToString:@"帮助反馈"]) {
            
        }
    }
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kRGB(255, 238, 238);
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.mScrollView];
    [self.mScrollView addSubview:self.headView];
    [self.mScrollView addSubview:self.orderView];
    [self.mScrollView addSubview:self.waltView];
    [self.mScrollView addSubview:self.toolView];
    [self.mScrollView addSubview:self.funcCollectionView];
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, kScreenHeight - kHeaderHeight - kTabBarHeight);
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        self.avatorImgV.image = [UIImage imageNamed:@"logo"];
        self.nameLab.text = @"您还未登录，请先登录或注册";
        self.nameLab.userInteractionEnabled = YES;
        self.balanceLab.text = @"0";
        self.quanLab.text = @"0";
        self.pointLab.text = @"0";
    }else{
        self.nameLab.userInteractionEnabled = NO;
        NSDictionary *parameters = @{
                                     kPlatform:kIOS,
                                     kVersion:kBuild,
                                     kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                     };
        [self showLoad];
        [[DmoNetwork dmo_network] dmo_requestWith:kGetUserMsgURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
            [self hideLoad];
            if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                self.dataDict = [obj objectForKey:@"data"];
                NSDictionary *user_detail = self.dataDict[@"user_detail"];
                NSDictionary *user_msg = self.dataDict[@"user_msg"];
                [self.avatorImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",user_detail[@"avatar"]]] placeholderImage:[UIImage imageNamed:@"logo"]];
                if ([self isNil:user_detail[@"nickname"]]) {
                    self.nameLab.text = [NSString stringWithFormat:@"%@",user_msg[@"phone"]];
                }else{
                    self.nameLab.text = [NSString stringWithFormat:@"%@",user_detail[@"nickname"]];
                }
                self.balanceLab.text = [NSString stringWithFormat:@"%@",user_msg[@"balance"]];
                self.quanLab.text = @"2";
                self.pointLab.text = [NSString stringWithFormat:@"%@",user_msg[@"point"]];
                
            }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
                [self toLoginVC:@"UserVC"];
            }else{
                [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            }
        } failure:^(NSString * _Nonnull errMessage) {
            [self hideLoad];
            [self showMessage:kMessage_Network_Failure delay:1.5];
        } requestType:requestTypePost];
    }
    [self.mScrollView.mj_header endRefreshing];
}
- (void)getFun{
    self.funMutArr = [NSMutableArray array];
    //上架处理
    if ([[NSString stringWithFormat:@"%@",kUserDefaults_OBJECTFORKEY(@"user_phone")] isEqualToString:@""] || [[NSString stringWithFormat:@"%@",kUserDefaults_OBJECTFORKEY(@"user_phone")] isEqualToString:@"17512543194"]) {
        [self.funMutArr addObjectsFromArray:@[@{@"icon":@"user_shoucang",@"name":@"我的收藏"},@{@"icon":@"user_ads",@"name":@"收货地址"},@{@"icon":@"user_youhuiquan",@"name":@"优惠券"},@{@"icon":@"user_unpay",@"name":@"我的钱包"},@{@"icon":@"user_fapiao",@"name":@"发票信息"},@{@"icon":@"user_message",@"name":@"消息通知"},@{@"icon":@"user_kefu",@"name":@"客服中心"},@{@"icon":@"user_help",@"name":@"帮助反馈"}]];
        self.funcCollectionView.height = 64 * kBL * 2;
    }else{
        [self.funMutArr addObjectsFromArray:@[@{@"icon":@"user_shoucang",@"name":@"我的收藏"},@{@"icon":@"user_ads",@"name":@"收货地址"},@{@"icon":@"user_youhuiquan",@"name":@"优惠券"},@{@"icon":@"user_unpay",@"name":@"我的钱包"},@{@"icon":@"user_fapiao",@"name":@"发票信息"},@{@"icon":@"user_message",@"name":@"消息通知"},@{@"icon":@"user_kefu",@"name":@"客服中心"},@{@"icon":@"user_help",@"name":@"帮助反馈"}]];
        self.funcCollectionView.height = 64 * kBL * 2;
    }
    [self.funcCollectionView reloadData];
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, self.funcCollectionView.maxY + 10);
}
#pragma mark ->Action Method
- (void)setBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        [self.navigationController pushViewController:[SetViewController new] animated:YES];
    }
}
- (void)infoAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        InfoViewController *inV = [[InfoViewController alloc] init];
        [self.navigationController pushViewController:inV animated:YES];
    }
}
- (void)orderMoreBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        
    }
}
- (void)onFunBtnAction:(UIButton *)sender{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        //        OrderViewController *orVC = [[OrderViewController alloc] init];
        //        if (sender.tag - kTagStart == 3) {
        //            orVC.itemIndex = 0;
        //        }else{
        //            orVC.itemIndex = sender.tag - kTagStart + 1;
        //        }
        //        orVC.type = @"1";
        //        [self.navigationController pushViewController:orVC animated:YES];
    }
}
//余额
- (void)balanceBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        
    }
}
//优惠券
- (void)quanBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        
    }
}
- (void)pointBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"UserVC"];
    }else{
        
    }
}
#pragma mark ->setter/getter Method
- (UIScrollView *)mScrollView{
    if (!_mScrollView) {
        _mScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight - kTabBarHeight)];
        _mScrollView.backgroundColor = kRGB(255, 238, 238);
        
        if (@available(iOS 11.0, *)){
            //            if ([[NSString stringWithFormat:@"%d",kPhoneType] isEqualToString:@"1"]) {
            //                _mScrollView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
            //            }else{
            //                _mScrollView.contentInset = UIEdgeInsetsMake(-kStatusHeight, 0, 0, 0);
            //            }
            _mScrollView.contentInset = UIEdgeInsetsMake(-kStatusHeight, 0, 0, 0);
        }
        WS(ws);
        _mScrollView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [ws initData];
        }];
    }
    return _mScrollView;
}
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 130 * kBL)];
        _headView.backgroundColor = kRGB(252, 33, 40);
        
        UIButton *setBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, kStatusHeight, 34 * kBL, 34 * kBL)];
        [setBtn setImage:[UIImage imageNamed:@"user_set"] forState:UIControlStateNormal];
        [setBtn addTarget:self action:@selector(setBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_headView addSubview:setBtn];
        setBtn.maxX = kScreenWidth;
        
        _avatorImgV = [[UIImageView alloc] initWithFrame:CGRectMake(10 * kBL, 0, 50 * kBL, 50 * kBL)];
        [_avatorImgV dmo_setCornerRadius:25 * kBL];
        _avatorImgV.maxY = _headView.height - 16 * kBL;
        [_headView addSubview:_avatorImgV];
        _avatorImgV.backgroundColor = kWhiteColor;
        
        _avatorImgV.userInteractionEnabled = YES;
        UITapGestureRecognizer *sing1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(infoAction)];
        [_avatorImgV addGestureRecognizer:sing1];
        
        _nameLab = [[UILabel alloc] initWithFrame:CGRectMake(_avatorImgV.maxX + 12 * kBL, 0, kScreenWidth - _avatorImgV.maxX - 22 * kBL, 50 * kBL)];
        _nameLab.textColor = kWhiteColor;
        _nameLab.numberOfLines = 0;
        _nameLab.font = kFONT_BOLD(16);
        [_headView addSubview:_nameLab];
        _nameLab.centerY = _avatorImgV.centerY;
        
        _nameLab.userInteractionEnabled = NO;
        UITapGestureRecognizer *sing2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(infoAction)];
        [_nameLab addGestureRecognizer:sing2];
    }
    return _headView;
}
- (UIView *)orderView{
    if (!_orderView) {
        _orderView = [[UIView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, 112 * kBL)];
        _orderView.backgroundColor = kWhiteColor;
        
        UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, kScreenWidth / 2.0, 36 * kBL)];
        titleLab.font = kFONT(16);
        titleLab.textColor = [UIColor blackColor];
        titleLab.text = @"我的订单";
        [_orderView addSubview:titleLab];
        
        UILabel *moreLab = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, kScreenWidth / 2.0, titleLab.height)];
        moreLab.font = kFONT(15);
        moreLab.textColor = kRGB(153,153,153);
        moreLab.text = @"查看更多订单";
        moreLab.textAlignment = NSTextAlignmentRight;
        moreLab.maxX = kScreenWidth - 22 * kBL;
        [_orderView addSubview:moreLab];
        
        UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 7 * kBL, 12 * kBL)];
        rImgV.image = [UIImage imageNamed:@"order_next"];
        rImgV.maxX = kScreenWidth - 12 * kBL;
        [_orderView addSubview:rImgV];
        rImgV.centerY = moreLab.centerY;
        
        UIButton *localMoreBtn = [[UIButton alloc] initWithFrame:CGRectMake(moreLab.minX, 0, kScreenWidth - moreLab.minX, titleLab.height)];
        [localMoreBtn addTarget:self action:@selector(orderMoreBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_orderView addSubview:localMoreBtn];
        
        UIView *lView = [[UIView alloc] initWithFrame:CGRectMake(0, titleLab.maxY, kScreenWidth, 1)];
        lView.backgroundColor = kGrayBgColor;
        [_orderView addSubview:lView];
        
        UIView *fuView = [[UIView alloc] initWithFrame:CGRectMake(0, lView.maxY, kScreenWidth, _orderView.height - lView.maxY)];
        [_orderView addSubview:fuView];
        
        NSArray *onIcon = @[@"user_daifukuan",@"user_daifahuo",@"user_daishouhuo",@"user_daipingjia",@"user_tuihuanhuo"];
        NSArray *onText = @[@"待付款",@"待发货",@"待收货",@"待评价",@"退换货"];
        for (int i = 0; i < 5; i ++) {
            UIButton *onFunBtn = [[UIButton alloc] initWithFrame:CGRectMake(kScreenWidth / 5.0 * i, 0, kScreenWidth / 5.0, fuView.height)];
            onFunBtn.tag = kTagStart + i;
            [onFunBtn addTarget:self action:@selector(onFunBtnAction:) forControlEvents:UIControlEventTouchUpInside];
            [fuView addSubview:onFunBtn];
            
            UIImageView *onImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 16 * kBL, 20 * kBL, 20 * kBL)];
            onImgV.image = [UIImage imageNamed:onIcon[i]];
            onImgV.centerX = onFunBtn.width / 2.0;
            [onFunBtn addSubview:onImgV];
            
            UILabel *tLab = [[UILabel alloc] initWithFrame:CGRectMake(0, onImgV.maxY + 10 * kBL, onFunBtn.width, 28)];
            tLab.text = onText[i];
            tLab.textAlignment = NSTextAlignmentCenter;
            tLab.font = kFONT(15);
            tLab.textColor = k102Color;
            [onFunBtn addSubview:tLab];
        }
    }
    return _orderView;
}
- (UIView *)waltView{
    if (!_waltView) {
        _waltView = [[UIView alloc] initWithFrame:CGRectMake(0, _orderView.maxY + 6 * kBL, kScreenWidth, 94 * kBL)];
        _waltView.backgroundColor = kWhiteColor;
        
        UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, kScreenWidth / 2.0, 36 * kBL)];
        titleLab.font = kFONT(16);
        titleLab.textColor = [UIColor blackColor];
        titleLab.text = @"我的钱包";
        [_waltView addSubview:titleLab];
        
        UIView *lView = [[UIView alloc] initWithFrame:CGRectMake(0, titleLab.maxY, kScreenWidth, 1)];
        lView.backgroundColor = kGrayBgColor;
        [_waltView addSubview:lView];
        
        UIButton *balanceBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, lView.maxY, kScreenWidth / 3.0, _waltView.height - lView.maxY)];
        [balanceBtn addTarget:self action:@selector(balanceBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_waltView addSubview:balanceBtn];
        
        _balanceLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 8 * kBL, balanceBtn.width, 28 * kBL)];
        _balanceLab.textAlignment = NSTextAlignmentCenter;
        _balanceLab.font = kFONT(20);
        _balanceLab.textColor = kRedColor;
        [balanceBtn addSubview:_balanceLab];
        
        UILabel *tLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _balanceLab.maxY, balanceBtn.width, 16 * kBL)];
        tLab.text = @"余额";
        tLab.textAlignment = NSTextAlignmentCenter;
        tLab.font = kFONT(15);
        tLab.textColor = kRGB(102,102,102);
        [balanceBtn addSubview:tLab];
        
        UIButton *quanBtn = [[UIButton alloc] initWithFrame:CGRectMake(balanceBtn.maxX, lView.maxY, kScreenWidth / 3.0, _waltView.height - lView.maxY)];
        [quanBtn addTarget:self action:@selector(quanBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_waltView addSubview:quanBtn];
        
        _quanLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 8 * kBL, quanBtn.width, 28 * kBL)];
        _quanLab.textAlignment = NSTextAlignmentCenter;
        _quanLab.font = kFONT(20);
        _quanLab.textColor = kRedColor;
        [quanBtn addSubview:_quanLab];
        
        UILabel *qtLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _quanLab.maxY, quanBtn.width, 16 * kBL)];
        qtLab.text = @"优惠券";
        qtLab.textAlignment = NSTextAlignmentCenter;
        qtLab.font = kFONT(15);
        qtLab.textColor = kRGB(102,102,102);
        [quanBtn addSubview:qtLab];
        
        UIButton *pointBtn = [[UIButton alloc] initWithFrame:CGRectMake(quanBtn.maxX, lView.maxY, kScreenWidth / 3.0, _waltView.height - lView.maxY)];
        [pointBtn addTarget:self action:@selector(pointBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_waltView addSubview:pointBtn];
        
        _pointLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 8 * kBL, pointBtn.width, 28 * kBL)];
        _pointLab.textAlignment = NSTextAlignmentCenter;
        _pointLab.font = kFONT(20);
        _pointLab.textColor = kRedColor;
        [pointBtn addSubview:_pointLab];
        
        UILabel *ptLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _quanLab.maxY, pointBtn.width, 16 * kBL)];
        ptLab.text = @"积分";
        ptLab.textAlignment = NSTextAlignmentCenter;
        ptLab.font = kFONT(15);
        ptLab.textColor = kRGB(102,102,102);
        [pointBtn addSubview:ptLab];
    }
    return _waltView;
}
- (UIView *)toolView{
    if (!_toolView) {
        _toolView = [[UIView alloc] initWithFrame:CGRectMake(0, _waltView.maxY + 6 * kBL, kScreenWidth, 36 * kBL)];
        _toolView.backgroundColor = [UIColor whiteColor];
        
        UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, kScreenWidth / 2.0, 36 * kBL)];
        titleLab.font = kFONT(16);
        titleLab.textColor = [UIColor blackColor];
        titleLab.text = @"常用工具";
        [_toolView addSubview:titleLab];
        
        UIView *lView = [[UIView alloc] initWithFrame:CGRectMake(0, titleLab.maxY - 1, kScreenWidth, 1)];
        lView.backgroundColor = kGrayBgColor;
        [_toolView addSubview:lView];
    }
    return _toolView;
}
- (UIScrollView *)funcCollectionView{
    if(!_funcCollectionView){
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 0;
        layout.itemSize = CGSizeMake(kScreenWidth / 4, 64 * kBL);
        
        _funcCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, _toolView.maxY, kScreenWidth, 64 * kBL * 3) collectionViewLayout:layout];
        _funcCollectionView.scrollEnabled = NO;
        _funcCollectionView.backgroundColor = [UIColor whiteColor];
        _funcCollectionView.dataSource = self;
        _funcCollectionView.delegate = self;
        [_funcCollectionView registerClass:[User_funcCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    }
    return _funcCollectionView;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
