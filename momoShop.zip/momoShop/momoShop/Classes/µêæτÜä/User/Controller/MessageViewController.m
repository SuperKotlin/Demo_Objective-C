//
//  MessageViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/17.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "MessageViewController.h"
#import "MessageTableViewCell.h"
#import "Message_DetailsViewController.h"

@interface MessageViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UITableView *listTableView;
@property (nonatomic,strong) NSMutableArray *listMutArr;
@property (nonatomic,assign) BOOL isRefresh; /**< 刷新还是加载*/
@property (nonatomic,assign) NSInteger pageNum; /**< 页数*/

@end

@implementation MessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self loadNewData];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.listMutArr.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 46 * kScreenWidth / 320;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    MessageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[MessageTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    NSDictionary *dataDict = self.listMutArr[indexPath.row];
    [cell.picImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,dataDict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
    cell.titleLab.text = [NSString stringWithFormat:@"%@",dataDict[@"title"]];
    cell.timeLab.text = [NSString stringWithFormat:@"%@",[[NSString stringWithFormat:@"%@",dataDict[@"pubtime"]] substringWithRange:NSMakeRange(0, 10)]];
    cell.conLab.text = [NSString stringWithFormat:@"%@",dataDict[@"description"]];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dataDict = self.listMutArr[indexPath.row];
    Message_DetailsViewController *dV = [[Message_DetailsViewController alloc] init];
    dV.article_id = [NSString stringWithFormat:@"%@",dataDict[@"article_id"]];
    [self.navigationController pushViewController:dV animated:YES];
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.listTableView];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
// 刷新
- (void)loadNewData {
    self.isRefresh = YES;
    [self requestData];
}
// 加载更多
- (void)loadMoreData {
    self.isRefresh = NO;
    [self requestData];
}
- (void)requestData{
    WS(ws);
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[kPlatform] = kIOS;
    parameters[kVersion] = kBuild;
    parameters[@"cat_id"] = @"2";
    parameters[@"search"] = @"";
    parameters[@"per"] = @"20";
    if (self.isRefresh) {
        self.pageNum = 1;
        parameters[@"p"] = [NSString stringWithFormat:@"%ld",(long)self.pageNum];
        self.listMutArr = [NSMutableArray array];
        [ws showLoad];
        [[DmoNetwork dmo_network] dmo_requestWith:kGetArticleListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
            [ws hideLoad];
            //0：失败，1：成功
            if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                NSArray *arr = [[obj objectForKey:@"data"] objectForKey:@"list"];
                if (arr.count == 0) {
                    [self showMessage:kMessage_NoMoreData delay:1.5];
                }else{
                    [self.listMutArr addObjectsFromArray:arr];
                }
                [ws.listTableView reloadData];
            }else{
                [ws showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            }
            [ws.listTableView.mj_header endRefreshing];
        } failure:^(NSString * _Nonnull errMessage) {
            [ws hideLoad];
            [ws showMessage:kMessage_Network_Failure delay:1.5];
            [ws.listTableView.mj_header endRefreshing];
        } requestType:requestTypePost];
    }else{
        self.pageNum ++;
        parameters[@"p"] = [NSString stringWithFormat:@"%ld",(long)self.pageNum];
        [ws showLoad];
        [[DmoNetwork dmo_network] dmo_requestWith:kGetArticleListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
            [ws hideLoad];
            //0：失败，1：成功
            if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                NSArray *arr = [[obj objectForKey:@"data"] objectForKey:@"list"];
                if (arr.count == 0) {
                    [self showMessage:kMessage_NoMoreData delay:1.5];
                }else{
                    [self.listMutArr addObjectsFromArray:arr];
                }
                [ws.listTableView reloadData];
            }else{
                [ws showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            }
            [ws.listTableView.mj_footer endRefreshing];
        } failure:^(NSString * _Nonnull errMessage) {
            [ws hideLoad];
            [ws showMessage:kMessage_Network_Failure delay:1.5];
            [ws.listTableView.mj_footer endRefreshing];
        } requestType:requestTypePost];
    }
}
#pragma mark ->Action Method
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"消息中心" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}
- (UITableView *)listTableView{
    if (!_listTableView) {
        _listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - _headView.maxY) style:UITableViewStylePlain];
        _listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listTableView.backgroundColor = kWhiteColor;
        _listTableView.delegate = self;
        _listTableView.dataSource = self;
        WS(ws);
        _listTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [ws loadNewData];
        }];
        
        MJRefreshAutoNormalFooter *footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
        // 禁止自动加载
        footer.automaticallyRefresh = NO;
        // 设置footer
        _listTableView.mj_footer = footer;
    }
    return _listTableView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
