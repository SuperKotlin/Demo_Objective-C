//
//  Message_DetailsViewController.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/17.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Message_DetailsViewController : UIViewController
@property (nonatomic,strong) NSString *article_id;

@end

NS_ASSUME_NONNULL_END
