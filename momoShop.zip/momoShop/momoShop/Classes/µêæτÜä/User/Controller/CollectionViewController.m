//
//  CollectionViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/19.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "CollectionViewController.h"
#import "CollectionTableViewCell.h"

@interface CollectionViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UITableView *listTableView;
@property (nonatomic,strong) NSMutableArray *listMutArr;
@property (nonatomic,assign) BOOL isRefresh; /**< 刷新还是加载*/
@property (nonatomic,assign) NSInteger pageNum; /**< 页数*/

@end

@implementation CollectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.listMutArr.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 102 * kBL;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    CollectionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[CollectionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    NSDictionary *dataDict = self.listMutArr[indexPath.row];
    [cell.picImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,dataDict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
    cell.titleLab.text = [NSString stringWithFormat:@"%@",dataDict[@"goods_name"]];
    cell.priceLab.text = [NSString stringWithFormat:@"¥%@",dataDict[@"price"]];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:cell.priceLab.text];
    [str addAttribute:NSFontAttributeName value:kFONT(12) range:NSMakeRange(0,1)];
    cell.priceLab.attributedText = str;
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
   
}
- (void)tableView:(UITableView *)tableView willBeginEditingRowAtIndexPath:(NSIndexPath *)indexPath{
    for (UIView *subview in tableView.subviews) {
        subview.backgroundColor = kGrayBgColor;
        if ([NSStringFromClass([subview class]) isEqualToString:@"UISwipeActionPullView"]) {
            if ([NSStringFromClass([subview.subviews[0] class]) isEqualToString:@"UISwipeActionStandardButton"]) {
                
                subview.subviews[0].backgroundColor = kGrayBgColor;
                
                UIView *dView = [[UIView alloc] init];
                dView.width = 66 * kBL;
                dView.height = 102 * kBL;
                [subview.subviews[0] addSubview:dView];
                
                UIImageView *imgV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"collect_delete"]];
                imgV.width = 22 * kBL;
                imgV.height = 22 * kBL;
                imgV.centerY = dView.height / 2.0 + 4 * kBL;
                imgV.centerX = dView.width / 2.0;
                [dView addSubview:imgV];
            }
        }
    }
}
- (NSArray<UITableViewRowAction *> *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dataDict = self.listMutArr[indexPath.row];
    UITableViewRowAction *deleteAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDestructive title:@"" handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"确定取消收藏吗？" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action) {
            [self deleteCollect:[NSString stringWithFormat:@"%@",dataDict[@"goods_id"]]];
        }];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        [alert addAction:okAction];
        [alert addAction:cancelAction];
        [self presentViewController:alert animated:true completion:nil];
    }];
    return @[deleteAction];
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.listTableView];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    self.listMutArr = [NSMutableArray array];
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    NSLog(@"%@",parameters);
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetCollectListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSArray *arr = [[obj objectForKey:@"data"] objectForKey:@"list"];
            [self.listMutArr addObjectsFromArray:arr];
            [self.listTableView reloadData];
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
//删除
- (void)deleteCollect:(NSString *)goods_id{
    self.listMutArr = [NSMutableArray array];
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken),
                                 @"goods_id":goods_id
                                 };
    NSLog(@"%@",parameters);
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kCancelCollectURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self initData];
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->Action Method
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"我的收藏" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}
- (UITableView *)listTableView{
    if (!_listTableView) {
        _listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - _headView.maxY) style:UITableViewStylePlain];
        _listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listTableView.delegate = self;
        _listTableView.dataSource = self;
        _listTableView.backgroundColor = kGrayBgColor;
    }
    return _listTableView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
