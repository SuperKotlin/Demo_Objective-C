//
//  Message_DetailsViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/17.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "Message_DetailsViewController.h"

@interface Message_DetailsViewController ()<WKUIDelegate>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIScrollView *mainScrollView;
@property (nonatomic,strong) UIView *infoView;
@property (nonatomic,strong) UILabel *titleLab;
@property (nonatomic,strong) WKWebView *contentWeb;
@property (nonatomic,strong) UILabel *timeLab;
@property (nonatomic,strong) UILabel *countLab;

@end

@implementation Message_DetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
    //    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
//WKScriptMessageHandler协议方法
/// 接收到服务器跳转请求之后调用 (服务器端redirect)，不一定调用
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation{
    
}
/// 3 在收到服务器的响应头，根据response相关信息，决定是否跳转。decisionHandler必须调用，来决定是否跳转，参数WKNavigationActionPolicyCancel取消跳转，WKNavigationActionPolicyAllow允许跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
    
}
/// 1 在发送请求之前，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    
}
/// 2 页面开始加载
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    
}
/// 4 开始获取到网页内容时返回
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{
    
}
/// 5 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    [webView setNeedsLayout];
}
/// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation{
    
}
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    
}

- (WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures{
    if (!navigationAction.targetFrame.isMainFrame) {
        [webView loadRequest:navigationAction.request];
    }
    return nil;
}
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:message?:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:([UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler();
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
    
}
- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler{
    //    DLOG(@"msg = %@ frmae = %@",message,frame);
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:message?:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:([UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(NO);
    }])];
    [alertController addAction:([UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(YES);
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
}
- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable))completionHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:prompt message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.text = defaultText;
    }];
    [alertController addAction:([UIAlertAction actionWithTitle:@"完成" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(alertController.textFields[0].text?:@"");
    }])];
    
    [self presentViewController:alertController animated:YES completion:nil];
}
#pragma mark  - KVO回调
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    //更具内容的高重置webView视图的高度
    NSLog(@"Height is changed! new=%@", [change valueForKey:NSKeyValueChangeNewKey]);
    //    NSLog(@"tianxia :%@",NSStringFromCGSize(self.contentWeb.contentSize));
    CGFloat newHeight = self.contentWeb.scrollView.contentSize.height;
    self.contentWeb.height = newHeight;
    self.mainScrollView.contentSize = CGSizeMake(kScreenWidth, self.contentWeb.maxY);
}
- (void)dealloc{
    [self.contentWeb.scrollView removeObserver:self forKeyPath:@"contentSize"];
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.mainScrollView];
    [self.mainScrollView addSubview:self.titleLab];
    [self.mainScrollView addSubview:self.infoView];
    [self.mainScrollView addSubview:self.contentWeb];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"article_id":self.article_id
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetArticleMsgURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSDictionary *dataDict = [[obj objectForKey:@"data"] objectForKey:@"article_msg"];
            self.titleLab.text = [NSString stringWithFormat:@"%@",dataDict[@"title"]];
            self.titleLab.height = [UILabel dmo_getLabelHeightByWidth:self.titleLab.width text:self.titleLab.text font:self.titleLab.font] + 10;
            self.infoView.minY = self.titleLab.maxY;
            self.timeLab.text = [NSString stringWithFormat:@"发布时间：%@",dataDict[@"pubtime"]];
            self.countLab.text = [NSString stringWithFormat:@"浏览量：%@",dataDict[@"clicknum"]];
            self.countLab.width = [UILabel dmo_getLabelWidthByText:self.countLab.text font:self.countLab.font];
            self.infoView.width = 198 * kBL + self.countLab.width;
            self.infoView.centerX = self.view.centerX;
            self.contentWeb.minY = self.infoView.maxY;
            
            NSString *dataStr = [NSString stringWithFormat:@"%@",[dataDict objectForKey:@"content"]];
            NSString *contents = [NSString stringWithFormat:@"%@%@%@",@"<html><head><meta content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0\" name=\"viewport\"><style type=\"text/css\">img{display: inline-block;max-width: 100%}</style></head><body>",dataStr,@"</body></html>"];
            NSLog(@"contents==%@",contents);
            [self.contentWeb loadHTMLString:contents baseURL:nil];
            self.mainScrollView.contentSize = CGSizeMake(kScreenWidth, self.contentWeb.maxY);
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->Action Method
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"消息中心" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}
- (UIScrollView *)mainScrollView{
    if (!_mainScrollView) {
        _mainScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - _headView.maxY)];
        _mainScrollView.backgroundColor = [UIColor whiteColor];
        _mainScrollView.scrollEnabled = YES;
    }
    return _mainScrollView;
}
- (UILabel *)titleLab{
    if (!_titleLab) {
        _titleLab = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 0, kScreenWidth - 20 * kBL, 30)];
        _titleLab.textAlignment = NSTextAlignmentCenter;
        _titleLab.font = kFONT(17);
        _titleLab.numberOfLines = 0;
    }
    return _titleLab;
}
- (UIView *)infoView{
    if (!_infoView) {
        _infoView = [[UIView alloc] initWithFrame:CGRectMake(0, _titleLab.maxY, kScreenWidth, 32 * kBL)];
     
        UIImageView *tImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 14 * kBL, 14 * kBL)];
        tImgV.image = [UIImage imageNamed:@"message_time"];
        [_infoView addSubview:tImgV];
        
        _timeLab = [[UILabel alloc] initWithFrame:CGRectMake(tImgV.maxX + 2 * kBL, 0, 170 * kBL, _infoView.height)];
        _timeLab.textColor = k153Color;
        _timeLab.font = kFONT(14);
        _timeLab.text = @"发布时间：";
        [_infoView addSubview:_timeLab];
        tImgV.centerY = _timeLab.centerY;
        
        UIImageView *cImgV = [[UIImageView alloc] initWithFrame:CGRectMake(_timeLab.maxX, 0, 14 * kBL, 10 * kBL)];
        cImgV.image = [UIImage imageNamed:@"message_browse"];
        [_infoView addSubview:cImgV];
        cImgV.centerY = _timeLab.centerY;
        
        _countLab = [[UILabel alloc] initWithFrame:CGRectMake(cImgV.maxX + 2 * kBL, 0, 30 * kBL, _infoView.height)];
        _countLab.textColor = k153Color;
        _countLab.font = kFONT(14);
        _countLab.text = @"浏览量：0";
        [_infoView addSubview:_countLab];
        
        _infoView.width = 202 * kBL + 30 * kBL;
        _infoView.centerX = self.view.centerX;
    }
    return _infoView;
}
- (WKWebView *)contentWeb{
    if (!_contentWeb) {
        _contentWeb = [[WKWebView alloc] initWithFrame:CGRectMake(0, _infoView.maxY, kScreenWidth, _mainScrollView.height - _infoView.maxY)];
        _contentWeb.UIDelegate = self;
        _contentWeb.scrollView.bounces = NO;
        _contentWeb.userInteractionEnabled = NO;
        [_contentWeb.scrollView addObserver:self forKeyPath:@"contentSize"
                                    options:NSKeyValueObservingOptionNew context:nil];
        
        //禁止长按弹出 UIMenuController 相关
        //禁止选择 css 配置相关
        NSString *css = @"body{-webkit-user-select:none;-webkit-user-drag:none;}";
        //css 选中样式取消
        NSMutableString *javascript = [NSMutableString string];
        [javascript appendString:@"var style = document.createElement('style');"];
        [javascript appendString:@"style.type = 'text/css';"];
        [javascript appendFormat:@"var cssContent = document.createTextNode('%@');", css];
        [javascript appendString:@"style.appendChild(cssContent);"];
        [javascript appendString:@"document.body.appendChild(style);"];
        [javascript appendString:@"document.documentElement.style.webkitUserSelect='none';"]; //禁止选择
        [javascript appendString:@"document.documentElement.style.webkitTouchCallout='none';"]; //禁止长按
        //javascript 注入
        WKUserScript *noneSelectScript = [[WKUserScript alloc] initWithSource:javascript injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
        WKUserContentController *userContentController = [[WKUserContentController alloc] init];
        [userContentController addUserScript:noneSelectScript];
        WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
        configuration.userContentController = userContentController;
        //控件加载
        [_contentWeb.configuration.userContentController addUserScript:noneSelectScript];
    }
    return _contentWeb;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
