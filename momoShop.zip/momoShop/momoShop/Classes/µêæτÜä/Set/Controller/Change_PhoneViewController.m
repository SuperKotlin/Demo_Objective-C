//
//  Change_PhoneViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/17.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "Change_PhoneViewController.h"

@interface Change_PhoneViewController ()
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) UITextField *codeTextField;
@property (nonatomic,strong) UITextField *phoneTextField;
@property (nonatomic,strong) UITextField *newsTextField2;
@property (nonatomic,strong) UIButton *sureBtn;

@end

@implementation Change_PhoneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.topView];
    [self.view addSubview:self.sureBtn];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    
}
#pragma mark ->Action Method
//获取验证码
- (void)codeBtnAction:(UIButton *)sender{
    [self.view endEditing:YES];
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kSendChangeBandCodeURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self timeFire:sender];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
- (void)newCodeBtnAction:(UIButton *)sender{
    [self.view endEditing:YES];
    if (self.phoneTextField.text.length == 0) {
        [self showMessage:@"请输入新手机号码" delay:1.5];
        return;
    }
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"phone":self.phoneTextField.text
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kSendChangeBandingURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self timeFire:sender];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
- (void)sureBtnAction{
    [self.view endEditing:YES];
    if (self.codeTextField.text.length == 0) {
        [self showMessage:@"请输入原手机验证码" delay:1.5];
        return;
    }
    
    if (self.phoneTextField.text.length == 0) {
        [self showMessage:@"请输入新手机号码" delay:1.5];
        return;
    }
    
    if (self.newsTextField2.text.length == 0) {
        [self showMessage:@"请输入新手机验证码" delay:1.5];
        return;
    }
    
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"phone":[NSString stringWithFormat:@"%@",kUserDefaults_OBJECTFORKEY(@"user_phone")],
                                 @"code":self.codeTextField.text
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kCheckCodeURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self changeBandingPhone];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
- (void)changeBandingPhone{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken),
                                 @"phone":self.phoneTextField.text,
                                 @"code":self.newsTextField2.text
                                 };
    NSLog(@"%@",parameters);
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kChangeBandingPhoneURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            kUserDefaults_SETOBJECT(self.phoneTextField.text, @"user_phone");
            [[NSUserDefaults standardUserDefaults] synchronize];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"SetViewRefresh" object:nil userInfo:nil];
            [self.navigationController popViewControllerAnimated:YES];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"换绑手机号" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}
- (UIView *)topView{
    if (!_topView) {
        _topView = [[UIView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, 54 * kBL * 3)];
        
        UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(10 * kBL, 10 * kBL, kScreenWidth - 20 * kBL, 44 * kBL)];
        view1.backgroundColor = kWhiteColor;
        [view1 dmo_setCornerRadius:10 * kBL];
        [_topView addSubview:view1];
        
        _codeTextField = [[UITextField alloc] initWithFrame:CGRectMake(10 * kBL, 0, view1.width - 86 * kBL, view1.height)];
        _codeTextField.font = kFONT(14);
        _codeTextField.placeholder = @"原手机验证码";
        [view1 addSubview:_codeTextField];
        
        UIButton *codeBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 66 * kBL, 16 * kBL)];
        codeBtn.centerY = _codeTextField.centerY;
        [codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [codeBtn setTitleColor:kRedColor forState:UIControlStateNormal];
        codeBtn.titleLabel.font = kFONT(13);
        [codeBtn addTarget:self action:@selector(codeBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [view1 addSubview:codeBtn];
        codeBtn.maxX = view1.width - 6;
        
        UIView *codeView = [UIView dmo_viewWithFrame:CGRectMake(codeBtn.minX, codeBtn.maxY, codeBtn.width - 8 * kBL, 1) backgroundColor:kRedColor];
        [view1 addSubview:codeView];
        codeView.centerX = codeBtn.centerX;
        
        UIView *view2 = [[UIView alloc] initWithFrame:CGRectMake(view1.minX, view1.maxY + 10 * kBL, view1.width, view1.height)];
        view2.backgroundColor = kWhiteColor;
        [view2 dmo_setCornerRadius:10 * kBL];
        [_topView addSubview:view2];
        
        _phoneTextField = [[UITextField alloc] initWithFrame:CGRectMake(10 * kBL, 0, view2.width - 10 * kBL, view2.height)];
        _phoneTextField.font = kFONT(14);
        _phoneTextField.placeholder = @"新手机号码";
        _phoneTextField.keyboardType = UIKeyboardTypePhonePad;
        [view2 addSubview:_phoneTextField];
        
        UIView *view3 = [[UIView alloc] initWithFrame:CGRectMake(view1.minX, view2.maxY + 10 * kBL, view1.width, view1.height)];
        view3.backgroundColor = kWhiteColor;
        [view3 dmo_setCornerRadius:10 * kBL];
        [_topView addSubview:view3];
        
        _newsTextField2 = [[UITextField alloc] initWithFrame:CGRectMake(10 * kBL, 0, view3.width - 86 * kBL, view3.height)];
        _newsTextField2.font = kFONT(14);
        _newsTextField2.placeholder = @"新手机验证码";
        [view3 addSubview:_newsTextField2];
        
        UIButton *codeBtn2 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 66 * kBL, 16 * kBL)];
        codeBtn2.centerY = _codeTextField.centerY;
        [codeBtn2 setTitle:@"获取验证码" forState:UIControlStateNormal];
        [codeBtn2 setTitleColor:kRedColor forState:UIControlStateNormal];
        codeBtn2.titleLabel.font = kFONT(13);
        [codeBtn2 addTarget:self action:@selector(newCodeBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [view3 addSubview:codeBtn2];
        codeBtn2.maxX = view3.width - 6;
        
        UIView *codeView2 = [UIView dmo_viewWithFrame:CGRectMake(codeBtn2.minX, codeBtn2.maxY, codeBtn2.width - 8 * kBL, 1) backgroundColor:kRedColor];
        [view3 addSubview:codeView2];
        codeView2.centerX = codeBtn2.centerX;
    }
    return _topView;
}

- (UIButton *)sureBtn{
    if (!_sureBtn) {
        _sureBtn = [[UIButton alloc] initWithFrame:CGRectMake(30 * kBL, _topView.maxY + 30 * kBL, kScreenWidth - 60 * kBL, 38 * kBL)];
        _sureBtn.backgroundColor = kRedBtnColor;
        [_sureBtn dmo_setCornerRadius:19.f * kBL];
        [_sureBtn setTitle:@"保存" forState:UIControlStateNormal];
        [_sureBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        _sureBtn.titleLabel.font = kFONT(16);
        [_sureBtn addTarget:self action:@selector(sureBtnAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _sureBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
