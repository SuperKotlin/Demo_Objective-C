//
//  ChangePwdViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/17.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "ChangePwdViewController.h"

@interface ChangePwdViewController ()
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIView *mainView;
@property (nonatomic,strong) UITextField *oldTextField;
@property (nonatomic,strong) UITextField *newsTextField;
@property (nonatomic,strong) UITextField *newsTextField2;
@property (nonatomic,strong) UIButton *sureBtn;

@end

@implementation ChangePwdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.mainView];
    [self.view addSubview:self.sureBtn];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    
}
#pragma mark ->Action Method
- (void)sureBtnAction{
    [self.view endEditing:YES];
    if ([self.oldTextField.text isEqualToString:@""]) {
        [self showMessage:@"请填写原密码" delay:1.5];
        return;
    }
    
    if ([self.newsTextField.text isEqualToString:@""]) {
        [self showMessage:@"请填写新密码" delay:1.5];
        return;
    }
    
    if ([self.newsTextField2.text isEqualToString:@""]) {
        [self showMessage:@"请填写重复密码" delay:1.5];
        return;
    }
    
    if (![self.newsTextField.text isEqualToString:self.newsTextField2.text]) {
        [self showMessage:@"两次密码不一致" delay:1.5];
        return;
    }
    
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken),
                                 @"oldpwd":self.oldTextField.text,
                                 @"pwd1":self.newsTextField.text,
                                 @"pwd2":self.newsTextField2.text
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kChangePwdURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self.navigationController popViewControllerAnimated:YES];
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"修改登录密码" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}
- (UIView *)mainView{
    if (!_mainView) {
        _mainView = [[UIView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, 50 * kBL * 3)];
        
        _oldTextField = [[UITextField alloc] initWithFrame:CGRectMake(10 * kBL, 10 * kBL, kScreenWidth - 20 * kBL, 40 * kBL)];
        _oldTextField.font = kFONT(14);
        _oldTextField.placeholder = @"原密码";
        _oldTextField.backgroundColor = kWhiteColor;
        [_oldTextField dmo_setCornerRadius:10 * kBL];
        [_oldTextField dmo_setTextFieldLeftPadding:_oldTextField forWidth:10 * kBL];
        [_oldTextField setSecureTextEntry:YES];
        [_mainView addSubview:_oldTextField];
        
        _newsTextField = [[UITextField alloc] initWithFrame:CGRectMake(_oldTextField.minX, _oldTextField.maxY + 10 * kBL, _oldTextField.width, _oldTextField.height)];
        _newsTextField.font = kFONT(14);
        _newsTextField.placeholder = @"新密码";
        _newsTextField.backgroundColor = kWhiteColor;
        [_newsTextField dmo_setCornerRadius:10 * kBL];
        [_newsTextField dmo_setTextFieldLeftPadding:_newsTextField forWidth:10 * kBL];
        [_newsTextField setSecureTextEntry:YES];
        [_mainView addSubview:_newsTextField];
        
        _newsTextField2 = [[UITextField alloc] initWithFrame:CGRectMake(_oldTextField.minX, _newsTextField.maxY + 10 * kBL, _oldTextField.width, _oldTextField.height)];
        _newsTextField2.font = kFONT(14);
        _newsTextField2.placeholder = @"重复新密码";
        _newsTextField2.backgroundColor = kWhiteColor;
        [_newsTextField2 dmo_setCornerRadius:10 * kBL];
        [_newsTextField2 dmo_setTextFieldLeftPadding:_newsTextField2 forWidth:10 * kBL];
        [_newsTextField2 setSecureTextEntry:YES];
        [_mainView addSubview:_newsTextField2];
    }
    return _mainView;
}
- (UIButton *)sureBtn{
    if (!_sureBtn) {
        _sureBtn = [[UIButton alloc] initWithFrame:CGRectMake(30 * kBL, _mainView.maxY + 30 * kBL, kScreenWidth - 60 * kBL, 38 * kBL)];
        _sureBtn.backgroundColor = kRedBtnColor;
        [_sureBtn dmo_setCornerRadius:19.f * kBL];
        [_sureBtn setTitle:@"保存" forState:UIControlStateNormal];
        [_sureBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        _sureBtn.titleLabel.font = kFONT(16);
        [_sureBtn addTarget:self action:@selector(sureBtnAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _sureBtn;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
