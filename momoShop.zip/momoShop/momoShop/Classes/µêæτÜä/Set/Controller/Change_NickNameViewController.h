//
//  Change_NickNameViewController.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/12.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Change_NickNameViewController : UIViewController
@property (nonatomic,strong) NSString *nickName;
@property (nonatomic,strong) NSDictionary *user_detail;

@end

NS_ASSUME_NONNULL_END
