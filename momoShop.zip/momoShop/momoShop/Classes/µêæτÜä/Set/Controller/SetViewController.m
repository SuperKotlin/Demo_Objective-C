//
//  SetViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/16.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "SetViewController.h"
#import "Change_PhoneViewController.h"
#import "ChangePwdViewController.h"
#import "Change_NickNameViewController.h" //修改昵称
#import "LZCleanCaches.h"
#import <AVFoundation/AVCaptureDevice.h>
#import <AVFoundation/AVMediaFormat.h>
#import <Photos/Photos.h>
#import "AddressViewController.h"

@interface SetViewController ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIScrollView *mScrollView;
@property (nonatomic,strong) UIView *avatorView;
@property (nonatomic,strong) UIImageView *avatorImgV;
@property (nonatomic,strong) UIView *nickView;
@property (nonatomic,strong) UIView *mainView;
@property (nonatomic,strong) UILabel *phoneLab;
@property (nonatomic,strong) UIView *pwdView;
@property (nonatomic,strong) UIView *huancunView;
@property (nonatomic,strong) UIButton *commitBtn;
@property (nonatomic,strong) NSString *nickName;
@property (nonatomic,strong) NSDictionary *user_detail;
@property (nonatomic,strong) UILabel *alipayLab;
@property (nonatomic,strong) UILabel *wechatLab;

@end

@implementation SetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(SetViewRefresh) name:@"SetViewRefresh" object:nil];
}
- (void)SetViewRefresh{
    self.phoneLab.text = [NSString stringWithFormat:@"%@",kUserDefaults_OBJECTFORKEY(@"user_phone")];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.mScrollView];
    [self.mScrollView addSubview:self.avatorView];
    [self.mScrollView addSubview:self.nickView];
    [self.mScrollView addSubview:self.mainView];
    [self.mScrollView addSubview:self.pwdView];
    [self.mScrollView addSubview:self.huancunView];
    [self.mScrollView addSubview:self.commitBtn];
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, self.commitBtn.maxY + 30);
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetUserMsgURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSDictionary *dataDict = [obj objectForKey:@"data"];
            self.user_detail = dataDict[@"user_detail"];
            [self.avatorImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",self.user_detail[@"avatar"]]] placeholderImage:[UIImage imageNamed:@"logo"]];
            if ([self isNil:self.user_detail[@"nickname"]]) {
                self.nickName = @"";
            }else{
                self.nickName = [NSString stringWithFormat:@"%@",self.user_detail[@"nickname"]];
            }
            
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->Action Method
- (void)photoAction{
    UIAlertController *alert = [UIAlertController
                                alertControllerWithTitle:nil
                                message:nil
                                preferredStyle:UIAlertControllerStyleActionSheet];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (status == AVAuthorizationStatusRestricted || status == AVAuthorizationStatusDenied){
            // 无权限
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"请您设置允许该应用访问您的相机\n设置>隐私>相机" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action) {
                
            }];
            [alert addAction:okAction];
            [self presentViewController:alert animated:true completion:nil];
            
            return;
        }
        
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {//相机权限
            if (granted) {
                NSLog(@"Authorized");
                // Hide the keyboard
                [self takePhoto];
            }else{
                NSLog(@"Denied or Restricted");
            }
        }];
        
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {}]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"从相册中选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        //----第一次不会进来
        PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
        if (status == PHAuthorizationStatusRestricted || status == PHAuthorizationStatusDenied){
            // 无权限 做一个友好的提示
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"请您设置允许该应用访问您的相册\n设置>隐私>照片" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action) {
                
            }];
            [alert addAction:okAction];
            [self presentViewController:alert animated:true completion:nil];
            
            return;
        }
        
        //----每次都会走进来
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            if (status == PHAuthorizationStatusAuthorized) {
                NSLog(@"Authorized");
                [self LocalPhoto];
            }else if (status == PHAuthorizationStatusDenied) {
                NSLog(@"用户拒绝当前应用访问相册,我们需要提醒用户打开访问开关");
            }else{
                NSLog(@"其他原因");
            }
        }];
        
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}
//从相册选择
-(void)LocalPhoto{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    //资源类型为图片库
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    //设置选择后的图片可被编辑
    //    picker.allowsEditing = YES;
    //    [[XGetCurrentInfo getCurrentVC] presentViewController:picker animated:YES completion:nil];
    //    [[[[UIApplication sharedApplication]delegate]window].rootViewController presentViewController:picker animated:YES completion:nil];
    [self.navigationController presentViewController:picker animated:YES completion:nil];
}
//拍照
- (void)takePhoto{
    //资源类型为照相机
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    //判断是否有相机
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]){
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        //设置拍照后的图片可被编辑
        //        picker.allowsEditing = YES;
        //资源类型为照相机
        picker.sourceType = sourceType;
        //        [[XGetCurrentInfo getCurrentVC] presentViewController:picker animated:YES completion:^{}];
        //        [[[[UIApplication sharedApplication]delegate]window].rootViewController presentViewController:picker animated:YES completion:nil];
        [self.navigationController presentViewController:picker animated:YES completion:nil];
    }else {
        //        NSLog(@"该设备无摄像头");
    }
}
#pragma Delegate method UIImagePickerControllerDelegate
//图像选取器的委托方法，选完图片后回调该方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    [self startMultiPartUploadTaskWithURL:kEditUserAvatarURL imagesArray:@[image] parameterOfimages:@"user_avatar" parametersDict:parameters compressionRatio:0.5 succeedBlock:^(NSDictionary *dict) {
        NSLog(@"qwer %@",dict);
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"])  {
            self.avatorImgV.image = image;
            [self showMessage:dict[kMessage] delay:1.5];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"UserViewRefresh" object:nil userInfo:nil];
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:dict[kMessage] delay:1.5];
        }
        
    } failedBlock:^(NSError *error) {
        
    }];
    
    //关闭相册界面
    [picker dismissViewControllerAnimated:YES completion:nil];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info{
    NSLog(@"info==%@",info);
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    [self startMultiPartUploadTaskWithURL:kEditUserAvatarURL imagesArray:@[info[@"UIImagePickerControllerOriginalImage"]] parameterOfimages:@"user_avatar" parametersDict:parameters compressionRatio:0.5 succeedBlock:^(NSDictionary *dict) {
        NSLog(@"qwer %@",dict);
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"])  {
            self.avatorImgV.image = info[@"UIImagePickerControllerOriginalImage"];
            [self showMessage:dict[kMessage] delay:1.5];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"UserViewRefresh" object:nil userInfo:nil];
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:dict[kMessage] delay:1.5];
        }
        
    } failedBlock:^(NSError *error) {
        [self showMessage:@"上传失败" delay:1.5];
    }];
    
    //关闭相册界面
    [picker dismissViewControllerAnimated:YES completion:nil];
}
- (void)nBtnAction:(UIButton *)sender{
    switch (sender.tag - kTagStart) {
        case 0:
        {
            Change_NickNameViewController *nV = [[Change_NickNameViewController alloc] init];
            nV.nickName = self.nickName;
            nV.user_detail = self.user_detail;
            [self.navigationController pushViewController:nV animated:YES];
        }
            break;
        case 1:
        {
            [self.navigationController pushViewController:[AddressViewController new] animated:YES];
        }
            break;
            
        default:
            break;
    }
}
- (void)funBtnAction:(UIButton *)sender{
    switch (sender.tag - kTagStart) {
        case 0:
        {
            
        }
            break;
        case 1:
        {
            
        }
            break;
        case 2:
        {
            [self.navigationController pushViewController:[Change_PhoneViewController new] animated:YES];
        }
            break;
            
        default:
            break;
    }
}
- (void)pwdBtnAction:(UIButton *)sender{
    switch (sender.tag - kTagStart) {
        case 0:
        {
            [self.navigationController pushViewController:[ChangePwdViewController new] animated:YES];
        }
            break;
        case 1:
        {
            
        }
            break;
            
        default:
            break;
    }
}
- (void)clearBtnAction{
    [[LZCleanCaches sharedInstance] cleanCache:^{
        [[LZCleanCaches sharedInstance] getCacheSize:^(NSString *size) {
            NSLog(@"size2==%@",size);
        }];
    }];
}
- (void)commitBtnAction{
    DmoAlert *alert = [[DmoAlert alloc]initAlertWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight) withImg:@"caozuotishi"  withTitle:@"温馨提示" withContent:@"是否退出登录！" alertType:AlertTypeTwo];
    alert.leftAction = ^(UIButton * _Nonnull sender) {
        
    };
    alert.rightAction = ^(UIButton * _Nonnull sender) {
        NSDictionary *parameters = @{
                                     kPlatform:kIOS,
                                     kVersion:kBuild,
                                     kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                     };
        [self showLoad];
        [[DmoNetwork dmo_network] dmo_requestWith:kExitURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
            [self hideLoad];
            if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
                kUserDefaults_SETOBJECT(@"N", @"isLogin");
                kUserDefaults_SETOBJECT(@"", kToken);
                kUserDefaults_SETOBJECT(@"", @"user_phone");
                [[NSUserDefaults standardUserDefaults] synchronize];
                [self.navigationController popViewControllerAnimated:YES];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"UserViewRefresh" object:nil userInfo:nil];
            }else{
                [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            }
        } failure:^(NSString * _Nonnull errMessage) {
            [self hideLoad];
            [self showMessage:kMessage_Network_Failure delay:1.5];
        } requestType:requestTypePost];
    };
    [self.view addSubview:alert];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"设置" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
    }
    return _headView;
}
- (UIScrollView *)mScrollView{
    if (!_mScrollView) {
        _mScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - _headView.maxY)];
        _mScrollView.backgroundColor = kGrayBgColor;
    }
    return _mScrollView;
}
- (UIView *)avatorView{
    if (!_avatorView) {
        _avatorView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 126 * kBL)];
        _avatorView.backgroundColor = kWhiteColor;
        
        _avatorImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 18 * kBL, 62 * kBL, 62 * kBL)];
        [_avatorImgV dmo_setCornerRadius:31 * kBL];
        _avatorImgV.centerX = self.view.centerX;
        [_avatorView addSubview:_avatorImgV];
        _avatorImgV.backgroundColor = kWhiteColor;
        _avatorImgV.clipsToBounds = YES;
        _avatorImgV.contentMode =  UIViewContentModeScaleAspectFill;
        
        _avatorImgV.userInteractionEnabled = YES;
        UITapGestureRecognizer *sing1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoAction)];
        [_avatorImgV addGestureRecognizer:sing1];
        
        UILabel *aLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _avatorImgV.maxY, kScreenWidth, 30 * kBL)];
        aLab.textColor = k51Color;
        aLab.text = @"点击修改头像";
        aLab.textAlignment = NSTextAlignmentCenter;
        aLab.font = kFONT(14);
        [_avatorView addSubview:aLab];
        
        aLab.userInteractionEnabled = NO;
        UITapGestureRecognizer *sing2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoAction)];
        [aLab addGestureRecognizer:sing2];
    }
    return _avatorView;
}
- (UIView *)nickView{
    if (!_nickView) {
        _nickView = [[UIView alloc] initWithFrame:CGRectMake(0, _avatorView.maxY + 10 * kBL, kScreenWidth, 44 * kBL * 2)];
        _nickView.backgroundColor = kWhiteColor;
        
        NSArray *tArr = @[@"昵称",@"收货地址"];
        for (int i = 0; i < 2; i ++) {
            UIButton *funBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 44 * kBL * i, kScreenWidth, 44 * kBL)];
            funBtn.tag = kTagStart + i;
            [funBtn addTarget:self action:@selector(nBtnAction:) forControlEvents:UIControlEventTouchUpInside];
            [_nickView addSubview:funBtn];
            
            UILabel *nLab = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 0, 70 * kBL, 44 * kBL)];
            nLab.text = tArr[i];
            nLab.font = kFONT(14);
            [funBtn addSubview:nLab];
            
            if (i == 0) {
                UILabel *cgLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 60 * kBL, 44 * kBL)];
                cgLab.text = @"修改";
                cgLab.textAlignment = NSTextAlignmentRight;
                cgLab.font = kFONT(14);
                [_nickView addSubview:cgLab];
                cgLab.maxX = kScreenWidth - 18 * kBL;
            }
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, nLab.maxY - 1, kScreenWidth, 1)];
            lineView.backgroundColor = kGrayBgColor;
            [funBtn addSubview:lineView];
            
            UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 5 * kBL, 11 * kBL)];
            rImgV.image = [UIImage imageNamed:@"set_next"];
            rImgV.centerY = funBtn.height / 2.0;
            rImgV.maxX = kScreenWidth - 10 * kBL;
            [funBtn addSubview:rImgV];
        }
    }
    return _nickView;
}
- (UIView *)mainView{
    if (!_mainView) {
        _mainView = [[UIView alloc] initWithFrame:CGRectMake(0, _nickView.maxY + 10 * kBL, kScreenWidth, 40 * kBL * 3)];
        _mainView.backgroundColor = kWhiteColor;
        
        NSArray *tArr = @[@"支付宝绑定",@"微信绑定",@"换绑手机号"];
        for (int i = 0; i < 3; i ++) {
            UIButton *funBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 40 * kBL * i, kScreenWidth, 40 * kBL)];
            funBtn.tag = kTagStart + i;
            [funBtn addTarget:self action:@selector(funBtnAction:) forControlEvents:UIControlEventTouchUpInside];
            [_mainView addSubview:funBtn];
            
            UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 0, 130 * kBL, funBtn.height)];
            leftLabel.font = kFONT(14);
            leftLabel.text = tArr[i];
            [funBtn addSubview:leftLabel];
            
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, leftLabel.maxY - 1, kScreenWidth, 1)];
            lineView.backgroundColor = kGrayBgColor;
            [funBtn addSubview:lineView];
            
            UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 5 * kBL, 11 * kBL)];
            rImgV.image = [UIImage imageNamed:@"set_next"];
            rImgV.maxX = kScreenWidth - 10 * kBL;
            rImgV.centerY = leftLabel.centerY;
            [funBtn addSubview:rImgV];
        }
        
        _alipayLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 120 * kBL, 40 * kBL)];
        _alipayLab.font = kFONT(14);
        _alipayLab.text = @"去绑定";
        _alipayLab.maxX = kScreenWidth - 20 * kBL;
        _alipayLab.textAlignment = NSTextAlignmentRight;
        [_mainView addSubview:_alipayLab];
        
        _wechatLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 40 * kBL, 120 * kBL, 40 * kBL)];
        _wechatLab.font = kFONT(14);
        _wechatLab.text = @"去绑定";
        _wechatLab.maxX = kScreenWidth - 20 * kBL;
        _wechatLab.textAlignment = NSTextAlignmentRight;
        [_mainView addSubview:_wechatLab];
        
        _phoneLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 40 * kBL * 2, 120 * kBL, 40 * kBL)];
        _phoneLab.font = kFONT(14);
        _phoneLab.text = [NSString stringWithFormat:@"%@",kUserDefaults_OBJECTFORKEY(@"user_phone")];
        _phoneLab.maxX = kScreenWidth - 20 * kBL;
        _phoneLab.textAlignment = NSTextAlignmentRight;
        [_mainView addSubview:_phoneLab];
    }
    return _mainView;
}
- (UIView *)pwdView{
    if (!_pwdView) {
        _pwdView = [[UIView alloc] initWithFrame:CGRectMake(0, _mainView.maxY + 10 * kBL, kScreenWidth, 40 * kBL * 2)];
        _pwdView.backgroundColor = kWhiteColor;
        
        NSArray *tArr = @[@"修改登录密码",@"提现密码管理"];
        for (int i = 0; i < 2; i ++) {
            UIButton *funBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 40 * kBL * i, kScreenWidth, 40 * kBL)];
            funBtn.tag = kTagStart + i;
            [funBtn addTarget:self action:@selector(pwdBtnAction:) forControlEvents:UIControlEventTouchUpInside];
            [_pwdView addSubview:funBtn];
            
            UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 0, 130 * kBL, funBtn.height)];
            leftLabel.font = kFONT(14);
            leftLabel.text = tArr[i];
            [funBtn addSubview:leftLabel];
            
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, leftLabel.maxY - 1, kScreenWidth, 1)];
            lineView.backgroundColor = kGrayBgColor;
            [funBtn addSubview:lineView];
            
            UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 5 * kBL, 11 * kBL)];
            rImgV.image = [UIImage imageNamed:@"set_next"];
            rImgV.centerY = 20 * kBL;
            rImgV.maxX = kScreenWidth - 10 * kBL;
            rImgV.centerY = leftLabel.centerY;
            [funBtn addSubview:rImgV];
        }
    }
    return _pwdView;
}
- (UIView *)huancunView{
    if (!_huancunView) {
        _huancunView = [[UIView alloc] initWithFrame:CGRectMake(0, _pwdView.maxY + 10 * kBL, kScreenWidth, 44 * kBL)];
        _huancunView.backgroundColor = kWhiteColor;
        
        UILabel *nLab = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 0, 80 * kBL, 44 * kBL)];
        nLab.text = @"清除缓存";
        nLab.font = kFONT(14);
        [_huancunView addSubview:nLab];
        
        UIButton *clearBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50 * kBL, 20 * kBL)];
        [clearBtn setTitle:@"清除缓存" forState:UIControlStateNormal];
        [clearBtn setTitleColor:kRGB(251, 96, 80) forState:UIControlStateNormal];
        [clearBtn dmo_setBorder:1.f color:kRGB(251, 96, 80)];
        clearBtn.titleLabel.font = kFONT(12);
        clearBtn.centerY = nLab.centerY;
        [clearBtn dmo_setCornerRadius:10 * kBL];
        [clearBtn addTarget:self action:@selector(clearBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_huancunView addSubview:clearBtn];
        clearBtn.maxX = kScreenWidth - 10 * kBL;
    }
    return _huancunView;
}
- (UIButton *)commitBtn{
    if (!_commitBtn) {
        _commitBtn = [[UIButton alloc] initWithFrame:CGRectMake(70 * kBL, _huancunView.maxY + 20 * kBL, kScreenWidth - 140 * kBL, 38 * kBL)];
        [_commitBtn setTitle:@"退出登录" forState:UIControlStateNormal];
        [_commitBtn setTitleColor:kRedColor forState:UIControlStateNormal];
        _commitBtn.titleLabel.font = kFONT(16);
        [_commitBtn dmo_setCornerRadius:19 * kBL];
        [_commitBtn dmo_setBorder:1.f color:kRedColor];
        [_commitBtn addTarget:self action:@selector(commitBtnAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _commitBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
