//
//  Change_NickNameViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/12.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "Change_NickNameViewController.h"

@interface Change_NickNameViewController ()
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIView *mainView;
@property (nonatomic,strong) UITextField *nickTextField;
@property (nonatomic,strong) UIButton *commitBtn;

@end

@implementation Change_NickNameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.mainView];
    [self.view addSubview:self.commitBtn];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    
}
#pragma mark ->Action Method
- (void)commitBtnAction{
    [self.view endEditing:YES];
    if ([self.nickTextField.text isEqualToString:@""]) {
        [self showMessage:@"请填写昵称" delay:1.5];
        return;
    }
    
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken),
                                 @"nickname":self.nickTextField.text,
                                 @"truename":self.user_detail[@"truename"],
                                 @"sex":self.user_detail[@"sex"],
                                 @"height":self.user_detail[@"height"],
                                 @"weight":self.user_detail[@"weight"],
                                 @"blood":@"", //血型 1A型 2B型 3AB型 4O型 5其它
                                 @"birthday":self.user_detail[@"birthday"],
                                 @"qq":self.user_detail[@"qq"],
                                 @"weixin":@"",
                                 @"province":@"",
                                 @"city":@"",
                                 @"county":@"",
                                 @"detail_address":@"",
                                 @"signature":self.user_detail[@"signature"]
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kEditUserMsgURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self.navigationController popViewControllerAnimated:YES];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"UserViewRefresh" object:nil userInfo:nil];
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"修改昵称" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}
- (UIView *)mainView{
    if (!_mainView) {
        _mainView = [[UIView alloc] initWithFrame:CGRectMake(10 * kBL, _headView.maxY + 14 * kBL, kScreenWidth - 20 * kBL, 44 * kBL)];
        _mainView.backgroundColor = kWhiteColor;
        [_mainView dmo_setCornerRadius:8.f];
        
        UILabel *nLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 40 * kBL, 44 * kBL)];
        nLab.text = @"昵称";
        nLab.textAlignment = NSTextAlignmentRight;
        nLab.font = kFONT(14);
        [_mainView addSubview:nLab];
        
        _nickTextField = [[UITextField alloc] initWithFrame:CGRectMake(nLab.maxX + 10 * kBL, 0, _mainView.width - nLab.maxX - 10 * kBL, nLab.height)];
        _nickTextField.placeholder = @"请输入新昵称";
        _nickTextField.font = kFONT(14);
        [_mainView addSubview:_nickTextField];
        _nickTextField.text = self.nickName;
    }
    return _mainView;
}
- (UIButton *)commitBtn{
    if (!_commitBtn) {
        _commitBtn = [[UIButton alloc] initWithFrame:CGRectMake(30 * kBL, _mainView.maxY + 20 * kBL, kScreenWidth - 60 * kBL, 38 * kBL)];
        _commitBtn.backgroundColor = kRedBtnColor;
        [_commitBtn setTitle:@"保存" forState:UIControlStateNormal];
        [_commitBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        _commitBtn.titleLabel.font = kFONT(16);
        [_commitBtn dmo_setCornerRadius:19 * kBL];
        [_commitBtn addTarget:self action:@selector(commitBtnAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _commitBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
