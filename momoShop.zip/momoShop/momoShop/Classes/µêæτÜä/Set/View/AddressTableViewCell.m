//
//  AddressTableViewCell.m
//  Youzhienjoy-ios
//
//  Created by buwen zhou on 2019/6/21.
//  Copyright © 2019 mod. All rights reserved.
//

#import "AddressTableViewCell.h"

@implementation AddressTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UIView *mainView = [[UIView alloc] initWithFrame:CGRectMake(0, 10 * kBL, kScreenWidth, 92 * kBL)];
        mainView.backgroundColor = [UIColor whiteColor];
        [mainView dmo_setCornerRadius:10.f];
        [self.contentView addSubview:mainView];
        
        UIImageView *addImgV = [[UIImageView alloc] initWithFrame:CGRectMake(12 * kBL, 18 * kBL, 18 * kBL, 18 * kBL)];
        addImgV.image = [UIImage imageNamed:@"address_icon"];
        [mainView addSubview:addImgV];
        
        self.nameLab = [[UILabel alloc] initWithFrame:CGRectMake(addImgV.maxX + 8 * kBL, 8 * kBL, kScreenWidth - addImgV.maxX - 18 * kBL, 30 * kBL)];
        self.nameLab.font = kFONT(14);
        self.nameLab.textColor = k51Color;
        [mainView addSubview:self.nameLab];
        
        self.addressLab = [[UILabel alloc] initWithFrame:CGRectMake(self.nameLab.minX, self.nameLab.maxY, kScreenWidth - addImgV.maxX - 36 * kBL, 36 * kBL)];
        self.addressLab.font = kFONT(13);
        self.addressLab.textColor = k153Color;
        self.addressLab.numberOfLines = 0;
        [mainView addSubview:self.addressLab];

        self.editBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 14 * kBL, 14 * kBL)];
        [self.editBtn setImage:[UIImage imageNamed:@"address_edit"] forState:UIControlStateNormal];
        [mainView addSubview:self.editBtn];
        self.editBtn.maxX = mainView.width - 12 * kBL;
        self.editBtn.maxY = mainView.height - 24 * kBL;
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
