//
//  AddressTableViewCell.h
//  Youzhienjoy-ios
//
//  Created by buwen zhou on 2019/6/21.
//  Copyright © 2019 mod. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AddressTableViewCell : UITableViewCell
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) UILabel *addressLab;
@property (nonatomic,strong) UIButton *editBtn;

@end

NS_ASSUME_NONNULL_END
