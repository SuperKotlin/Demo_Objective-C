//
//  Order_BuyViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/28.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "Order_BuyViewController.h"

@interface Order_BuyViewController ()
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIView *topView;

@end

@implementation Order_BuyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.topView];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    
}
#pragma mark ->Action Method
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"订单支付" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}
- (UIView *)topView{
    if (!_topView) {
        _topView = [[UIView alloc] initWithFrame:CGRectMake(10 * kBL, _headView.maxY + 10 * kBL, kScreenWidth - 20 * kBL, 104 * kBL)];
        _topView.backgroundColor = kWhiteColor;
        [_topView dmo_setCornerRadius:10.f];
        
        UILabel *cxLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 14 * kBL, _topView.width, 32 * kBL)];
        cxLab.text = @"订单总价";
        cxLab.textColor = k153Color;
        cxLab.textAlignment = NSTextAlignmentCenter;
        cxLab.font = kFONT(14);
        [_topView addSubview:cxLab];
        
        UILabel *monLab = [[UILabel alloc] initWithFrame:CGRectMake(0, cxLab.maxY, _topView.width, 40 * kBL)];
        monLab.text = [NSString stringWithFormat:@"¥%@",self.allprice];
        monLab.textColor = kBlackColor;
        monLab.textAlignment = NSTextAlignmentCenter;
        monLab.font = kFONT(36);
        [_topView addSubview:monLab];
    }
    return _topView;
}

@end
