//
//  Order_BuyViewController.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/28.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Order_BuyViewController : UIViewController
@property (nonatomic,strong) NSString *order_id;
@property (nonatomic,strong) NSString *allprice;

@end

NS_ASSUME_NONNULL_END
