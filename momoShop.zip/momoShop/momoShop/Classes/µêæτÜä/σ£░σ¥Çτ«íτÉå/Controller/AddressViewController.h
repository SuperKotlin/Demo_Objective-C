//
//  AddressViewController.h
//  Youzhienjoy-ios
//
//  Created by buwen zhou on 2019/6/21.
//  Copyright © 2019 mod. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AddressViewController : UIViewController
//1 从商品提交订单跳转过来的
@property (nonatomic,strong) NSString *typeStr;

@end

NS_ASSUME_NONNULL_END
