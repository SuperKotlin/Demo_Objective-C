//
//  Address_AddEditViewController.m
//  Youzhienjoy-ios
//
//  Created by buwen zhou on 2019/6/21.
//  Copyright © 2019 mod. All rights reserved.
//

#import "Address_AddEditViewController.h"
#import "AreaPopView.h"
#import "AddressTableViewCell.h"

@interface Address_AddEditViewController ()
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) UITextField *nameTextField;
@property (nonatomic,strong) UITextField *phoneTextField;
@property (nonatomic,strong) UITextField *addressTextField;
@property (nonatomic,strong) UITextField *detailsTextField;
@property (nonatomic,strong) UIButton *defaultBtn;
@property (nonatomic,strong) UIButton *sureBtn;
@property (nonatomic,strong) NSString *provinceStr;
@property (nonatomic,strong) NSString *cityStr;
@property (nonatomic,strong) NSString *countyStr;
@property (nonatomic,strong) NSString *is_default;

@end

@implementation Address_AddEditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    self.is_default = @"Y";
    if ([self.type isEqualToString:@"edit"]) {
        [self initData];
    }
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = k249Color;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.topView];
    [self.view addSubview:self.sureBtn];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"address_id":self.address_id
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetAddressMsgURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSDictionary *addressMsg = [[obj objectForKey:@"data"] objectForKey:@"addressMsg"];
            self.provinceStr = [NSString stringWithFormat:@"%@",addressMsg[@"province"]];
            self.cityStr = [NSString stringWithFormat:@"%@",addressMsg[@"city"]];
            self.countyStr = [NSString stringWithFormat:@"%@",addressMsg[@"county"]];
            self.nameTextField.text = [NSString stringWithFormat:@"%@",addressMsg[@"consignee"]];
            self.phoneTextField.text = [NSString stringWithFormat:@"%@",addressMsg[@"contact_number"]];
            self.addressTextField.text = [NSString stringWithFormat:@"%@%@%@",self.provinceStr,self.cityStr,self.countyStr];
            self.detailsTextField.text = [NSString stringWithFormat:@"%@",addressMsg[@"detail_address"]];
            self.is_default = [NSString stringWithFormat:@"%@",addressMsg[@"is_default"]];
            
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->Action Method
- (void)ftFunBtnAction:(UIButton *)sender{
    [self.view endEditing:YES];
    switch (sender.tag - kTagStart) {
        case 2:
        {
            NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"Address" ofType:@"plist"];
            // 如果plist文件的根数据为字典
            NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:plistPath];
            
            [AreaPopView initWithBlock:^(NSString *province, NSString *city, NSString *area) {
                self.provinceStr = province;
                self.cityStr = city;
                self.countyStr = area;
                self.addressTextField.text = [NSString stringWithFormat:@"%@%@%@",province,city,area];
            } andAreaArray:dict];
        }
            break;
        default:
            break;
    }
}
- (void)navRightBtnAction{
    [self.view endEditing:YES];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"确定删除吗？" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action) {
        NSDictionary *parameters = @{
                                     kPlatform:kIOS,
                                     kVersion:kBuild,
                                     kToken:kUserDefaults_OBJECTFORKEY(kToken),
                                     @"address_id":self.address_id
                                     };
        [self showLoad];
        [[DmoNetwork dmo_network] dmo_requestWith:kDelAddressURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
            [self hideLoad];
            if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
                [self.navigationController popViewControllerAnimated:YES];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"AddressViewRefresh" object:nil userInfo:nil];
            }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
                [self toLoginVC:@""];
            }else{
                [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            }
        } failure:^(NSString * _Nonnull errMessage) {
            [self hideLoad];
            [self showMessage:kMessage_Network_Failure delay:1.5];
        } requestType:requestTypePost];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alert addAction:okAction];
    [alert addAction:cancelAction];
    [self presentViewController:alert animated:true completion:nil];
}
- (void)defaultBtnAction:(UIButton *)sender{
    if (sender.selected) {
        [_defaultBtn setImage:[UIImage imageNamed:@"address_ye"] forState:UIControlStateNormal];
        self.is_default = @"Y";
    }else{
        [_defaultBtn setImage:[UIImage imageNamed:@"address_no"] forState:UIControlStateNormal];
        self.is_default = @"N";
    }
    sender.selected = !sender.selected;
}
- (void)sureBtnAction{
    [self.view endEditing:YES];
    if ([self.nameTextField.text isEqualToString:@""]) {
        [self showMessage:@"请填写姓名" delay:1.5];
        return;
    }
    if ([self.phoneTextField.text isEqualToString:@""]) {
        [self showMessage:@"请填写电话号码" delay:1.5];
        return;
    }
    if ([self.addressTextField.text isEqualToString:@""]) {
        [self showMessage:@"请选择所在地区" delay:1.5];
        return;
    }
    if ([self.detailsTextField.text isEqualToString:@""]) {
        [self showMessage:@"请填写详细地址" delay:1.5];
        return;
    }
    
    if ([self.type isEqualToString:@"add"]) {
        [self addAddress];
    }else{
        [self editAddress];
    }
}
- (void)addAddress{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken),
                                 @"province":self.provinceStr,
                                 @"city":self.cityStr,
                                 @"county":self.countyStr,
                                 @"detail_address":self.detailsTextField.text,
                                 @"consignee":self.nameTextField.text,
                                 @"contact_number":self.phoneTextField.text,
                                 @"is_default":self.is_default
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kAddAddressURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self.navigationController popViewControllerAnimated:YES];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"AddressViewRefresh" object:nil userInfo:nil];
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
- (void)editAddress{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken),
                                 @"address_id":self.address_id,
                                 @"province":self.provinceStr,
                                 @"city":self.cityStr,
                                 @"county":self.countyStr,
                                 @"detail_address":self.detailsTextField.text,
                                 @"consignee":self.nameTextField.text,
                                 @"contact_number":self.phoneTextField.text,
                                 @"is_default":self.is_default
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kEditAddressURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self.navigationController popViewControllerAnimated:YES];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"AddressViewRefresh" object:nil userInfo:nil];
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        if ([self.type isEqualToString:@"add"]) {
            label.text = @"添加收货地址";
        }else{
            label.text = @"编辑收货地址";
        }
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIButton *navRightBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, kStatusHeight, 40 * kBL, kNavigationBarHeight)];
        navRightBtn.maxX = kScreenWidth - 4;
        [navRightBtn setTitle:@"删除" forState:UIControlStateNormal];
        [navRightBtn setTitleColor:k153Color forState:UIControlStateNormal];
        navRightBtn.titleLabel.font = kFONT(15);
        [navRightBtn addTarget:self action:@selector(navRightBtnAction) forControlEvents:UIControlEventTouchUpInside];
        if ([self.type isEqualToString:@"edit"]) {
            [_headView addSubview:navRightBtn];
        }
    }
    return _headView;
}
- (UIView *)topView{
    if (!_topView) {
        _topView = [[UIView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, 40 * kBL * 5)];
        _topView.backgroundColor = [UIColor whiteColor];
        
        NSArray *textArr = @[@"收货人",@"联系电话",@"所在地区",@"详细地址",@"设为默认"];
        for (int i = 0; i < 5; i ++) {
            UIButton *ftFunBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 40 * kBL * i, kScreenWidth, 40 * kBL)];
            ftFunBtn.tag = kTagStart + i;
            [ftFunBtn addTarget:self action:@selector(ftFunBtnAction:) forControlEvents:UIControlEventTouchUpInside];
            [_topView addSubview:ftFunBtn];
            
            UILabel *tLab = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 0, 60 * kBL, ftFunBtn.height)];
            tLab.text = textArr[i];
            tLab.font = kFONT(16);
            [ftFunBtn addSubview:tLab];
        }
        
        _nameTextField = [[UITextField alloc] initWithFrame:CGRectMake(70 * kBL, 0, kScreenWidth - 80 * kBL, 40 * kBL)];
        _nameTextField.font = kFONT(15);
        _nameTextField.textAlignment = NSTextAlignmentRight;
        _nameTextField.maxX = kScreenWidth - 10;
        _nameTextField.placeholder = @"输入姓名";
        [_topView addSubview:_nameTextField];
        
        _phoneTextField = [[UITextField alloc] initWithFrame:CGRectMake(_nameTextField.minX, _nameTextField.maxY, _nameTextField.width, _nameTextField.height)];
        _phoneTextField.font = kFONT(15);
        _phoneTextField.textAlignment = NSTextAlignmentRight;
        _phoneTextField.maxX = kScreenWidth - 10;
        _phoneTextField.placeholder = @"输入电话号码";
        _phoneTextField.keyboardType = UIKeyboardTypeDecimalPad;
        [_topView addSubview:_phoneTextField];
        
        _addressTextField = [[UITextField alloc] initWithFrame:CGRectMake(_nameTextField.minX, _phoneTextField.maxY, _nameTextField.width, _nameTextField.height)];
        _addressTextField.font = kFONT(15);
        _addressTextField.textAlignment = NSTextAlignmentRight;
        _addressTextField.maxX = kScreenWidth - 10;
        _addressTextField.placeholder = @"请选择";
        [_topView addSubview:_addressTextField];
        _addressTextField.userInteractionEnabled = NO;
        
        _detailsTextField = [[UITextField alloc] initWithFrame:CGRectMake(_nameTextField.minX, _addressTextField.maxY, _nameTextField.width, _nameTextField.height)];
        _detailsTextField.font = kFONT(15);
        _detailsTextField.textAlignment = NSTextAlignmentRight;
        _detailsTextField.maxX = kScreenWidth - 10;
        _detailsTextField.placeholder = @"输入详细地址";
        [_topView addSubview:_detailsTextField];
        
        _defaultBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 48 * kBL, 26 * kBL)];
        [_defaultBtn setImage:[UIImage imageNamed:@"address_ye"] forState:UIControlStateNormal];
        _defaultBtn.centerY = _detailsTextField.maxY + 20 * kBL;
        _defaultBtn.maxX = kScreenWidth - 8 * kBL;
        [_defaultBtn addTarget:self action:@selector(defaultBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [_topView addSubview:_defaultBtn];
    }
    return _topView;
}
- (UIButton *)sureBtn{
    if (!_sureBtn) {
        _sureBtn = [[UIButton alloc] initWithFrame:CGRectMake(18 * kBL,_topView.maxY + 22, kScreenWidth - 36 * kBL, 42 * kBL)];
        _sureBtn.backgroundColor = kDefaultColor;
        [_sureBtn setTitle:@"保存" forState:UIControlStateNormal];
        [_sureBtn dmo_setCornerRadius:10.f];
        [_sureBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        [_sureBtn addTarget:self action:@selector(sureBtnAction) forControlEvents:UIControlEventTouchUpInside];
        _sureBtn.titleLabel.font = kFONT(15);
    }
    return _sureBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
