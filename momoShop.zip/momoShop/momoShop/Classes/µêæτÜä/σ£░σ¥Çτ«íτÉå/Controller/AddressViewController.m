//
//  AddressViewController.m
//  Youzhienjoy-ios
//
//  Created by buwen zhou on 2019/6/21.
//  Copyright © 2019 mod. All rights reserved.
//

#import "AddressViewController.h"
#import "AddressTableViewCell.h"
#import "Address_AddEditViewController.h"
#import "ConfirmViewController.h"

@interface AddressViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UITableView *listTableView;
@property (nonatomic,strong) NSMutableArray *listMutArr;
@property (nonatomic,strong) UIButton *sureBtn;

@end

@implementation AddressViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(AddressViewRefresh) name:@"AddressViewRefresh" object:nil];
}
- (void)AddressViewRefresh{
    [self initData];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.listMutArr.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 102 * kBL;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    AddressTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[AddressTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = kGrayBgColor;
    
    NSDictionary *dataDict = self.listMutArr[indexPath.row];
    cell.nameLab.text = [NSString stringWithFormat:@"%@  %@",dataDict[@"consignee"],dataDict[@"contact_number"]];
    cell.addressLab.text = [NSString stringWithFormat:@"%@%@%@%@",dataDict[@"province"],dataDict[@"city"],dataDict[@"county"],dataDict[@"detail_address"]];
    
    cell.editBtn.tag = kTagStart + indexPath.row;
    [cell.editBtn addTarget:self action:@selector(editBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
}
- (void)editBtnAction:(UIButton *)sender{
    NSDictionary *dataDict = self.listMutArr[sender.tag - kTagStart];
    Address_AddEditViewController *addV = [[Address_AddEditViewController alloc] init];
    addV.type = @"edit";
    addV.address_id = [NSString stringWithFormat:@"%@",dataDict[@"id"]];
    [self.navigationController pushViewController:addV animated:YES];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([self.typeStr isEqualToString:@"1"]) {
        NSDictionary *addressDict = self.listMutArr[indexPath.row];
        ConfirmViewController *popVC = self.navigationController.viewControllers[self.navigationController.viewControllers.count - 2];
        popVC.nameLab.text = [NSString stringWithFormat:@"%@  %@",addressDict[@"consignee"],addressDict[@"contact_number"]];
        popVC.addressDetailLab.text = [NSString stringWithFormat:@"%@%@%@%@",addressDict[@"province"],addressDict[@"city"],addressDict[@"county"],addressDict[@"detail_address"]];
        popVC.addressIdStr = [NSString stringWithFormat:@"%@",addressDict[@"id"]];
        
        popVC.fullView.hidden = NO;
        popVC.nullView.hidden = YES;
        [self.navigationController popViewControllerAnimated:YES];
    }
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.listTableView];
    [self.view addSubview:self.sureBtn];
}
- (void)backViewController{
    if ([self.typeStr isEqualToString:@"1"]) {
        if (self.listMutArr.count == 0) {
            ConfirmViewController *popVC = self.navigationController.viewControllers[self.navigationController.viewControllers.count - 2];
            popVC.nameLab.text = @"";
            popVC.addressDetailLab.text = @"";
            popVC.addressIdStr = @"";
            
            popVC.fullView.hidden = YES;
            popVC.nullView.hidden = NO;
            [self.navigationController popViewControllerAnimated:YES];
        }else{
            [self.navigationController popViewControllerAnimated:YES];
        }
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}
#pragma mark ->Private Method
- (void)initData{
    self.listMutArr = [NSMutableArray array];
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetAddressListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSArray *arr = [[obj objectForKey:@"data"] objectForKey:@"list"];
            [self.listMutArr addObjectsFromArray:arr];
            [self.listTableView reloadData];
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@"UserVC"];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->Action Method
- (void)sureBtnAction{
    Address_AddEditViewController *addV = [[Address_AddEditViewController alloc] init];
    addV.type = @"add";
    [self.navigationController pushViewController:addV animated:YES];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"收货地址" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
    }
    return _headView;
}
- (UITableView *)listTableView{
    if (!_listTableView) {
        _listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - kFooterHeight - _headView.maxY - 70 * kBL) style:UITableViewStylePlain];
        _listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listTableView.backgroundColor = kGrayBgColor;
        _listTableView.delegate = self;
        _listTableView.dataSource = self;
    }
    return _listTableView;
}
- (UIButton *)sureBtn{
    if (!_sureBtn) {
        _sureBtn = [[UIButton alloc] initWithFrame:CGRectMake(18 * kBL, kScreenHeight - kFooterHeight - 57 * kBL, kScreenWidth - 36 * kBL, 42 * kBL)];
        _sureBtn.backgroundColor = kDefaultColor;
        [_sureBtn setTitle:@"添加新地址" forState:UIControlStateNormal];
        [_sureBtn dmo_setCornerRadius:10.f];
        [_sureBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        [_sureBtn addTarget:self action:@selector(sureBtnAction) forControlEvents:UIControlEventTouchUpInside];
        _sureBtn.titleLabel.font = kFONT(15);
    }
    return _sureBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
