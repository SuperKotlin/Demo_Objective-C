//
//  LoginViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/16.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "ForgotViewController.h"

@interface LoginViewController ()
@property (nonatomic,strong) UIScrollView *mainScrollView;
@property (nonatomic,strong) UIImageView *logoImgV;
@property (nonatomic,strong) UIView *contentView;
@property (nonatomic,strong) UITextField *userTextField;
@property (nonatomic,strong) UITextField *pwdTextField;
@property (nonatomic,strong) UIButton *closeBtn;
@property (nonatomic,strong) UIView *sanView;
@property (nonatomic,strong) UIButton *forgotBtn;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self getUserPwd];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
    //    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kWhiteColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.mainScrollView];
    [self.mainScrollView addSubview:self.logoImgV];
    [self.mainScrollView addSubview:self.contentView];
    [self.mainScrollView addSubview:self.sanView];
    self.mainScrollView.contentSize = CGSizeMake(kScreenWidth, self.sanView.maxY + 30);
    [self.view addSubview:self.closeBtn];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)getUserPwd{
    if ([kUserDefaults_OBJECTFORKEY(@"user_phone") isKindOfClass:[NSNull class]] || kUserDefaults_OBJECTFORKEY(@"user_phone") == nil || [[NSString stringWithFormat:@"%@",kUserDefaults_OBJECTFORKEY(@"user_phone")] isEqualToString:@""]) {
        self.userTextField.text = @"";
        self.pwdTextField.text = @"";
    }else{
        self.userTextField.text = [NSString stringWithFormat:@"%@",kUserDefaults_OBJECTFORKEY(@"user_phone")];
        self.pwdTextField.text = [NSString stringWithFormat:@"%@",kUserDefaults_OBJECTFORKEY(@"user_pwd")];
    }
}
#pragma mark ->Action Method
- (void)closeBtnAction{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)registerBtnAction{
    [self.navigationController pushViewController:[RegisterViewController new] animated:YES];
}
- (void)forgotBtnAction{
    [self.navigationController pushViewController:[ForgotViewController new] animated:YES];
}
- (void)loginBtnAction{
    [self.view endEditing:YES];
    
    if (self.userTextField.text.length == 0) {
        [self showMessage:@"请输入手机号" delay:1.5];
        return;
    }
    
    if (self.pwdTextField.text.length == 0) {
        [self showMessage:@"请输入密码" delay:1.5];
        return;
    }
    
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"account":self.userTextField.text,
                                 @"pwd":self.pwdTextField.text,
                                 @"login_type":@"ios" //登录类型，pc、wap、ios、android、miniwx
                                 };
    NSLog(@"%@",parameters);
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kLoginURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            kUserDefaults_SETOBJECT(@"Y", @"isLogin");
            kUserDefaults_SETOBJECT(obj[@"data"][@"token"], kToken);
            kUserDefaults_SETOBJECT(self.userTextField.text, @"user_phone");
            kUserDefaults_SETOBJECT(self.pwdTextField.text, @"user_pwd");
            kUserDefaults_SYNCHRONIZE;
            [self sendTongzhi];
            [self dismissViewControllerAnimated:YES completion:nil];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
//发通知
- (void)sendTongzhi{
    if ([self.refreshVC isEqualToString:@"UserVC"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"UserViewRefresh" object:nil userInfo:nil];
    }else if ([self.refreshVC isEqualToString:@"ShopCartVC"]){
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ShopCartViewRefresh" object:nil userInfo:nil];
    }else if ([self.refreshVC isEqualToString:@""]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"" object:nil userInfo:nil];
    }else if ([self.refreshVC isEqualToString:@""]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"" object:nil userInfo:nil];
    }
}
- (void)sanBtnAction:(UIButton *)sender{
    switch (sender.tag - kTagStart) {
        case 0:
        {
            
        }
            break;
        case 1:
        {
            //            if(![WXApi isWXAppInstalled]) {
            //                [self showMessage:@"您的手机还未安装微信" delay:1.5];
            //                return;
            //            }
            //
            //            SendAuthReq *req = [[SendAuthReq alloc] init];
            //            req.scope = @"snsapi_userinfo";
            //            req.state = @"ymmweixin";
            //            [WXApi sendReq:req];
        }
            break;
        case 2:
        {
            
        }
            break;
            
        default:
            break;
    }
}
#pragma mark ->setter/getter Method
- (UIScrollView *)mainScrollView{
    if (!_mainScrollView) {
        _mainScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
        _mainScrollView.backgroundColor = kWhiteColor;
        _mainScrollView.showsVerticalScrollIndicator = NO;
    }
    return _mainScrollView;
}
- (UIImageView *)logoImgV{
    if (!_logoImgV) {
        _logoImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 92, 64, 64)];
        _logoImgV.image = [UIImage imageNamed:@"logo"];
        _logoImgV.contentMode = UIViewContentModeCenter;
        _logoImgV.centerX = self.view.centerX;
    }
    return _logoImgV;
}
- (UIView *)contentView{
    if (!_contentView) {
        _contentView = [[UIView alloc] initWithFrame:CGRectMake(0, _logoImgV.maxY + 22, kScreenWidth, 214)];
        _contentView.backgroundColor = [UIColor clearColor];
        
        UIView *userView = [[UIView alloc] initWithFrame:CGRectMake(24, 0, kScreenWidth - 48, 34 * kBL)];
        [userView dmo_setCornerRadius:17 * kBL];
        [userView dmo_setBorder:1.f color:kRGB(221, 221, 221)];
        [_contentView addSubview:userView];
        
        UIImageView *uImgV = [[UIImageView alloc] initWithFrame:CGRectMake(18 * kBL, 0, 16 * kBL, 18 * kBL)];
        uImgV.image = [UIImage imageNamed:@"login_user"];
        [userView addSubview:uImgV];
        
        _userTextField = [[UITextField alloc] initWithFrame:CGRectMake(uImgV.maxX + 10 * kBL, 0, userView.width - uImgV.maxX - 10 * kBL, userView.height)];
        _userTextField.placeholder = @"请输入手机号码";
        _userTextField.textColor = k51Color;
        _userTextField.font = kFONT(15);
//        [_userTextField setValue:k153Color forKeyPath:@"_placeholderLabel.textColor"];
        _userTextField.attributedPlaceholder = [[NSMutableAttributedString alloc] initWithString:_userTextField.placeholder attributes:@{NSForegroundColorAttributeName:k153Color}];
        _userTextField.keyboardType = UIKeyboardTypePhonePad;
        [userView addSubview:_userTextField];
        uImgV.centerY = _userTextField.centerY;
        
        UIView *pwdView = [[UIView alloc] initWithFrame:CGRectMake(userView.minX, userView.maxY + 20 * kBL, userView.width, userView.height)];
        [pwdView dmo_setCornerRadius:17 * kBL];
        [pwdView dmo_setBorder:1.f color:kRGB(221, 221, 221)];
        [_contentView addSubview:pwdView];
        
        UIImageView *pwdImgV = [[UIImageView alloc] initWithFrame:CGRectMake(18 * kBL, 0, 16 * kBL, 18 * kBL)];
        pwdImgV.image = [UIImage imageNamed:@"login_pwd"];
        [pwdView addSubview:pwdImgV];
        
        _pwdTextField = [[UITextField alloc] initWithFrame:CGRectMake(pwdImgV.maxX + 10 * kBL, 0, pwdView.width - pwdImgV.maxX - 10 * kBL, pwdView.height)];
        _pwdTextField.placeholder = @"请输入密码";
        _pwdTextField.textColor = k51Color;
        _pwdTextField.font = kFONT(15);
//        [_pwdTextField setValue:k153Color forKeyPath:@"_placeholderLabel.textColor"];
        _pwdTextField.attributedPlaceholder = [[NSMutableAttributedString alloc] initWithString:_pwdTextField.placeholder attributes:@{NSForegroundColorAttributeName:k153Color}];
        _pwdTextField.secureTextEntry = YES;
        [pwdView addSubview:_pwdTextField];
        pwdImgV.centerY = _pwdTextField.centerY;
        
        UIButton *registerBtn = [[UIButton alloc] initWithFrame:CGRectMake(userView.minX + 4, pwdView.maxY + 8, 56, 32)];
        [registerBtn addTarget:self action:@selector(registerBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_contentView addSubview:registerBtn];

        UILabel *rLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, registerBtn.width, 30)];
        rLab.text = @"注册新账号";
        rLab.font = kFONT(15);
        rLab.textColor = kRedColor;
        [registerBtn addSubview:rLab];

        rLab.width = [UILabel dmo_getLabelWidthByText:rLab.text font:rLab.font];
        rLab.height = [UILabel dmo_getLabelHeightByWidth:rLab.width text:rLab.text font:rLab.font];
        rLab.maxY = registerBtn.height - 1;

        UIView *rLineV = [[UIView alloc] initWithFrame:CGRectMake(0, rLab.maxY, rLab.width, 1)];
        rLineV.backgroundColor = [UIColor whiteColor];
        [registerBtn addSubview:rLineV];
        
        _forgotBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, pwdView.maxY + 8, 66, 32)];
        [_forgotBtn addTarget:self action:@selector(forgotBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_contentView addSubview:_forgotBtn];
        
        UILabel *forgotLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _forgotBtn.width, 30)];
        forgotLab.text = @"忘记密码？";
        forgotLab.font = kFONT(15);
        forgotLab.textColor = k153Color;
        [_forgotBtn addSubview:forgotLab];
        
        forgotLab.width = [UILabel dmo_getLabelWidthByText:forgotLab.text font:forgotLab.font];
        forgotLab.height = [UILabel dmo_getLabelHeightByWidth:forgotLab.width text:forgotLab.text font:forgotLab.font];
        forgotLab.maxY = _forgotBtn.height - 1;
        
        _forgotBtn.width = forgotLab.width + 3;
        _forgotBtn.maxX = userView.maxX;
        
        UIButton *loginBtn = [[UIButton alloc] initWithFrame:CGRectMake(userView.minX, _forgotBtn.maxY + 30, userView.width, 34 * kBL)];
        loginBtn.backgroundColor = kRedColor;
        [loginBtn setTitle:@"登  录" forState:UIControlStateNormal];
        [loginBtn dmo_setCornerRadius:17 * kBL];
        loginBtn.titleLabel.font = kFONT_BOLD(16);
        [loginBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        [loginBtn addTarget:self action:@selector(loginBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_contentView addSubview:loginBtn];
        
        _contentView.height = loginBtn.maxY;
    }
    return _contentView;
}
- (UIView *)sanView{
    if (!_sanView) {
        _sanView = [[UIView alloc] initWithFrame:CGRectMake(0, _contentView.maxY + 50 * kBL, kScreenWidth, 80 * kBL)];
        
        UILabel *tLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 30 * kBL)];
        tLab.text = @"一键快捷登录";
        tLab.font = kFONT(15);
        tLab.textColor = kRGB(100, 100, 101);
        tLab.textAlignment = NSTextAlignmentCenter;
        [_sanView addSubview:tLab];
        tLab.width = [UILabel dmo_getLabelWidthByText:tLab.text font:tLab.font] + 10;
        tLab.centerX = self.view.centerX;
        
        UIView *lView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 90 * kBL, 1)];
        lView.backgroundColor = kRGB(227, 227, 227);
        [_sanView addSubview:lView];
        lView.centerY = tLab.centerY;
        lView.maxX = tLab.minX - 10;
        
        UIView *rView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 90 * kBL, 1)];
        rView.backgroundColor = kRGB(227, 227, 227);
        [_sanView addSubview:rView];
        rView.centerY = tLab.centerY;
        rView.minX = tLab.maxX + 10;
        
        NSArray *arr = @[@"",@"login_wechat",@""];
        CGFloat width = (kScreenWidth - 60) / 3.0;
        for (int i = 0; i < 3; i++) {
            UIButton *sanBtn = [[UIButton alloc] initWithFrame:CGRectMake(30 + width * i, tLab.maxY, width, 44 * kBL)];
            sanBtn.tag = kTagStart + i;
            [sanBtn setImage:[UIImage imageNamed:arr[i]] forState:UIControlStateNormal];
            [sanBtn addTarget:self action:@selector(sanBtnAction:) forControlEvents:UIControlEventTouchUpInside];
            [_sanView addSubview:sanBtn];
        }
    }
    return _sanView;
}
- (UIButton *)closeBtn{
    if (!_closeBtn) {
        _closeBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, kStatusHeight + 10, 26, 26)];
        [_closeBtn setImage:[UIImage imageNamed:@"close"] forState:UIControlStateNormal];
        [_closeBtn addTarget:self action:@selector(closeBtnAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _closeBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
