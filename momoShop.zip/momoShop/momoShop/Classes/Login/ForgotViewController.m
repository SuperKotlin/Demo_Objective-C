//
//  ForgotViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/13.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "ForgotViewController.h"

@interface ForgotViewController ()
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) UITextField *phoneTextField;
@property (nonatomic,strong) UITextField *codeTextField;
@property (nonatomic,strong) UITextField *newsTextField;
@property (nonatomic,strong) UITextField *newsTextField2;
@property (nonatomic,strong) UIButton *commitBtn;

@end

@implementation ForgotViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kWhiteColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.topView];
    [self.view addSubview:self.commitBtn];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    
}
#pragma mark ->Action Method
//获取验证码
- (void)codeBtnAction:(UIButton *)sender{
    [self.view endEditing:YES];
    if (self.phoneTextField.text.length == 0) {
        [self showMessage:@"请输入手机号码" delay:1.5];
        return;
    }
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"phone":self.phoneTextField.text
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kSendUserFindpwdURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self timeFire:sender];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
- (void)commitBtnAction{
    [self.view endEditing:YES];
    if (self.phoneTextField.text.length == 0) {
        [self showMessage:@"请输入手机号码" delay:1.5];
        return;
    }
    if (self.codeTextField.text.length == 0) {
        [self showMessage:@"请输入验证码" delay:1.5];
        return;
    }
    if (self.newsTextField.text.length == 0) {
        [self showMessage:@"请输入新密码" delay:1.5];
        return;
    }
    if (self.newsTextField2.text.length == 0) {
        [self showMessage:@"请输入重复密码" delay:1.5];
        return;
    }
    if (![self.newsTextField.text isEqualToString:self.newsTextField2.text]) {
        [self showMessage:@"两次密码不一致" delay:1.5];
        return;
    }
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"phone":self.phoneTextField.text,
                                 @"code":self.codeTextField.text,
                                 @"pwd":self.newsTextField.text
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kFindPwdByPhoneURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self.navigationController popViewControllerAnimated:YES];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"忘记密码" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
    }
    return _headView;
}
- (UIView *)topView{
    if (!_topView) {
        _topView = [[UIView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, 54 * kBL * 4)];
        
        _phoneTextField = [[UITextField alloc] initWithFrame:CGRectMake(36 * kBL, 10 * kBL, kScreenWidth - 72 * kBL, 34 * kBL)];
        _phoneTextField.font = kFONT(14);
        _phoneTextField.placeholder = @"手机号码";
        _phoneTextField.backgroundColor = kWhiteColor;
        [_phoneTextField dmo_setCornerRadius:17 * kBL];
        [_phoneTextField dmo_setTextFieldLeftPadding:_phoneTextField forWidth:10 * kBL];
        [_phoneTextField dmo_setBorder:1.f color:kGrayBgColor];
        _phoneTextField.keyboardType = UIKeyboardTypePhonePad;
        [_topView addSubview:_phoneTextField];
        
        _codeTextField = [[UITextField alloc] initWithFrame:CGRectMake(36 * kBL, _phoneTextField.maxY + 20 * kBL, kScreenWidth - 152 * kBL, 34 * kBL)];
        _codeTextField.font = kFONT(14);
        _codeTextField.placeholder = @"验证码";
        _codeTextField.backgroundColor = kWhiteColor;
        [_codeTextField dmo_setCornerRadius:17 * kBL];
        [_codeTextField dmo_setTextFieldLeftPadding:_codeTextField forWidth:10 * kBL];
        [_codeTextField dmo_setBorder:1.f color:kGrayBgColor];
        [_topView addSubview:_codeTextField];
        
        UIButton *codeBtn = [[UIButton alloc] initWithFrame:CGRectMake(_codeTextField.maxX + 3 * kBL, _codeTextField.minY, kScreenWidth - 72 * kBL - _codeTextField.width - 3 * kBL, _codeTextField.height)];
        [codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [codeBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        [codeBtn dmo_setCornerRadius:17 * kBL];
        codeBtn.titleLabel.font = kFONT(13);
        codeBtn.backgroundColor = kRedColor;
        [codeBtn addTarget:self action:@selector(codeBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [_topView addSubview:codeBtn];
        
        _newsTextField = [[UITextField alloc] initWithFrame:CGRectMake(_codeTextField.minX, _codeTextField.maxY + 20 * kBL, kScreenWidth - 72 * kBL, _codeTextField.height)];
        _newsTextField.font = kFONT(14);
        _newsTextField.placeholder = @"新密码";
        _newsTextField.backgroundColor = kWhiteColor;
        [_newsTextField dmo_setCornerRadius:17 * kBL];
        [_newsTextField dmo_setTextFieldLeftPadding:_newsTextField forWidth:10 * kBL];
        [_newsTextField setSecureTextEntry:YES];
        [_newsTextField dmo_setBorder:1.f color:kGrayBgColor];
        [_topView addSubview:_newsTextField];
        
        _newsTextField2 = [[UITextField alloc] initWithFrame:CGRectMake(_codeTextField.minX, _newsTextField.maxY + 20 * kBL, _newsTextField.width, _newsTextField.height)];
        _newsTextField2.font = kFONT(14);
        _newsTextField2.placeholder = @"重复新密码";
        _newsTextField2.backgroundColor = kWhiteColor;
        [_newsTextField2 dmo_setCornerRadius:17 * kBL];
        [_newsTextField2 dmo_setTextFieldLeftPadding:_newsTextField2 forWidth:10 * kBL];
        [_newsTextField2 setSecureTextEntry:YES];
        [_newsTextField2 dmo_setBorder:1.f color:kGrayBgColor];
        [_topView addSubview:_newsTextField2];
    }
    return _topView;
}
- (UIButton *)commitBtn{
    if (!_commitBtn) {
        _commitBtn = [[UIButton alloc] initWithFrame:CGRectMake(36 * kBL, _topView.maxY + 40 * kBL, kScreenWidth - 72 * kBL, 34 * kBL)];
        _commitBtn.backgroundColor = kRedBtnColor;
        [_commitBtn setTitle:@"找回密码" forState:UIControlStateNormal];
        [_commitBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        _commitBtn.titleLabel.font = kFONT(16);
        [_commitBtn dmo_setCornerRadius:17 * kBL];
        [_commitBtn addTarget:self action:@selector(commitBtnAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _commitBtn;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
