//
//  LoginViewController.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/16.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginViewController : UIViewController
//判断登录成功之后给哪个页面发通知
@property (nonatomic,strong) NSString *refreshVC;

@end

NS_ASSUME_NONNULL_END
