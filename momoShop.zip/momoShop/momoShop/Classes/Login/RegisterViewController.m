//
//  RegisterViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/13.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "RegisterViewController.h"
#import "UserAgreementViewController.h"

@interface RegisterViewController ()
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIImageView *logoImgV;
@property (nonatomic,strong) UIView *contentView;
@property (nonatomic,strong) UITextField *userTextField;
@property (nonatomic,strong) UITextField *codeTextField;
@property (nonatomic,strong) UITextField *pwdTextField;
@property (nonatomic,strong) UIView *delegateView;
@property (nonatomic,strong) UIButton *gBtn;

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kWhiteColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.logoImgV];
    [self.view addSubview:self.contentView];
    [self.view addSubview:self.delegateView];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    
}
#pragma mark ->Action Method
- (void)navRightBtnAction{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)gBtnAction:(UIButton *)sender{
    if (!sender.selected) {
        [sender setImage:[UIImage imageNamed:@"signup_check"] forState:UIControlStateNormal];
        self.gBtn.selected = NO;
    }else{
        [sender setImage:[UIImage imageNamed:@"signup_uncheck"] forState:UIControlStateNormal];
        self.gBtn.selected = YES;
    }
    sender.selected = !sender.selected;
}
- (void)delegatesAction{
    [self.navigationController pushViewController:[UserAgreementViewController new] animated:YES];
}
//获取验证码
- (void)codeBtnAction:(UIButton *)sender{
    [self.view endEditing:YES];
    if (self.userTextField.text.length == 0) {
        [self showMessage:@"请输入手机号码" delay:1.5];
        return;
    }
    
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"phone":self.userTextField.text
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kSendUserRegisterURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self timeFire:sender];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
- (void)loginBtnAction{
    if (self.userTextField.text.length == 0) {
        [self showMessage:@"请输入手机号码" delay:1.5];
        return;
    }
    
    if (self.codeTextField.text.length == 0) {
        [self showMessage:@"请输入验证码" delay:1.5];
        return;
    }
    
    if (self.pwdTextField.text.length == 0) {
        [self showMessage:@"请输入密码" delay:1.5];
        return;
    }
    
    if (!self.gBtn.selected) {
        [self showMessage:@"请勾选同意用户注册协议" delay:1.5];
        return;
    }
    
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"phone":self.userTextField.text,
                                 @"pwd1":self.pwdTextField.text,
                                 @"pwd2":self.pwdTextField.text,
                                 @"code":self.codeTextField.text,
                                 @"referrer_phone":@""
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kRegisterURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            [self.navigationController popViewControllerAnimated:YES];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
//        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
//        [_headView addSubview:backButton];
//
//        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
//        [_headView addSubview:lineView];
        
        UIButton *navRightBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, kStatusHeight, 50 * kBL, kNavigationBarHeight)];
        navRightBtn.maxX = kScreenWidth - 10;
        [navRightBtn setTitle:@"返回登录" forState:UIControlStateNormal];
        [navRightBtn setTitleColor:kRedColor forState:UIControlStateNormal];
        navRightBtn.titleLabel.font = kFONT(15);
        [navRightBtn addTarget:self action:@selector(navRightBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_headView addSubview:navRightBtn];
    }
    return _headView;
}
- (UIImageView *)logoImgV{
    if (!_logoImgV) {
        _logoImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, _headView.maxY + 44 * kBL, 60 * kBL, 60 * kBL)];
        _logoImgV.image = [UIImage imageNamed:@"logo"];
        _logoImgV.contentMode = UIViewContentModeCenter;
        _logoImgV.centerX = self.view.centerX;
    }
    return _logoImgV;
}
- (UIView *)contentView{
    if (!_contentView) {
        _contentView = [[UIView alloc] initWithFrame:CGRectMake(0, _logoImgV.maxY + 28 * kBL, kScreenWidth, 210 * kBL)];
        _contentView.backgroundColor = [UIColor clearColor];
        
        UIView *userView = [[UIView alloc] initWithFrame:CGRectMake(24, 0, kScreenWidth - 48, 34 * kBL)];
        [userView dmo_setCornerRadius:17 * kBL];
        [userView dmo_setBorder:1.f color:kRGB(221, 221, 221)];
        [_contentView addSubview:userView];
        
        UIImageView *uImgV = [[UIImageView alloc] initWithFrame:CGRectMake(18 * kBL, 0, 16 * kBL, 18 * kBL)];
        uImgV.image = [UIImage imageNamed:@"login_user"];
        [userView addSubview:uImgV];
        
        _userTextField = [[UITextField alloc] initWithFrame:CGRectMake(uImgV.maxX + 10 * kBL, 0, userView.width - uImgV.maxX - 10 * kBL, userView.height)];
        _userTextField.placeholder = @"请输入手机号码";
        _userTextField.textColor = k51Color;
        _userTextField.font = kFONT(15);
//        [_userTextField setValue:k153Color forKeyPath:@"_placeholderLabel.textColor"];
        _userTextField.attributedPlaceholder = [[NSMutableAttributedString alloc] initWithString:_userTextField.placeholder attributes:@{NSForegroundColorAttributeName:k153Color}];
        _userTextField.keyboardType = UIKeyboardTypePhonePad;
        [userView addSubview:_userTextField];
        uImgV.centerY = _userTextField.centerY;
        
        UIView *codeView = [[UIView alloc] initWithFrame:CGRectMake(userView.minX, userView.maxY + 20 * kBL, userView.width - 80 * kBL, userView.height)];
        [codeView dmo_setCornerRadius:17 * kBL];
        [codeView dmo_setBorder:1.f color:kRGB(221, 221, 221)];
        [_contentView addSubview:codeView];
        
        UIImageView *cImgV = [[UIImageView alloc] initWithFrame:CGRectMake(18 * kBL, 0, 16 * kBL, 18 * kBL)];
        cImgV.image = [UIImage imageNamed:@"signup_verification"];
        [codeView addSubview:cImgV];
        
        _codeTextField = [[UITextField alloc] initWithFrame:CGRectMake(cImgV.maxX + 10 * kBL, 0, userView.width - cImgV.maxX - 10 * kBL, userView.height)];
        _codeTextField.placeholder = @"请输入验证码";
        _codeTextField.textColor = k51Color;
        _codeTextField.font = kFONT(15);
//        [_codeTextField setValue:k153Color forKeyPath:@"_placeholderLabel.textColor"];
        _codeTextField.attributedPlaceholder = [[NSMutableAttributedString alloc] initWithString:_codeTextField.placeholder attributes:@{NSForegroundColorAttributeName:k153Color}];
        [codeView addSubview:_codeTextField];
        cImgV.centerY = _codeTextField.centerY;
        
        UIButton *codeBtn = [[UIButton alloc] initWithFrame:CGRectMake(codeView.maxX + 3 * kBL, codeView.minY, userView.width - codeView.width - 3 * kBL, codeView.height)];
        [codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [codeBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        [codeBtn dmo_setCornerRadius:17 * kBL];
        codeBtn.titleLabel.font = kFONT(13);
        codeBtn.backgroundColor = kRedColor;
        [codeBtn addTarget:self action:@selector(codeBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [_contentView addSubview:codeBtn];
        
        UIView *pwdView = [[UIView alloc] initWithFrame:CGRectMake(userView.minX, codeView.maxY + 20 * kBL, userView.width, userView.height)];
        [pwdView dmo_setCornerRadius:17 * kBL];
        [pwdView dmo_setBorder:1.f color:kRGB(221, 221, 221)];
        [_contentView addSubview:pwdView];
        
        UIImageView *pwdImgV = [[UIImageView alloc] initWithFrame:CGRectMake(18 * kBL, 0, 16 * kBL, 18 * kBL)];
        pwdImgV.image = [UIImage imageNamed:@"login_pwd"];
        [pwdView addSubview:pwdImgV];
        
        _pwdTextField = [[UITextField alloc] initWithFrame:CGRectMake(pwdImgV.maxX + 10 * kBL, 0, pwdView.width - pwdImgV.maxX - 10 * kBL, pwdView.height)];
        _pwdTextField.placeholder = @"请输入密码";
        _pwdTextField.textColor = k51Color;
        _pwdTextField.font = kFONT(15);
//        [_pwdTextField setValue:k153Color forKeyPath:@"_placeholderLabel.textColor"];
        _pwdTextField.attributedPlaceholder = [[NSMutableAttributedString alloc] initWithString:_pwdTextField.placeholder attributes:@{NSForegroundColorAttributeName:k153Color}];
        _pwdTextField.secureTextEntry = YES;
        [pwdView addSubview:_pwdTextField];
        pwdImgV.centerY = _pwdTextField.centerY;
        
        UIButton *loginBtn = [[UIButton alloc] initWithFrame:CGRectMake(userView.minX, pwdView.maxY + 30, userView.width, 34 * kBL)];
        loginBtn.backgroundColor = kRedColor;
        [loginBtn setTitle:@"注  册" forState:UIControlStateNormal];
        [loginBtn dmo_setCornerRadius:17 * kBL];
        loginBtn.titleLabel.font = kFONT_BOLD(16);
        [loginBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        [loginBtn addTarget:self action:@selector(loginBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_contentView addSubview:loginBtn];
        
        _contentView.height = loginBtn.maxY;
    }
    return _contentView;
}
- (UIView *)delegateView{
    if (!_delegateView) {
        _delegateView = [[UIView alloc] initWithFrame:CGRectMake(0,_contentView.maxY + 20 * kBL, kScreenWidth, 22 * kBL)];
        
        _gBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 20 * kBL, 20 * kBL)];
        [_gBtn setImage:[UIImage imageNamed:@"signup_uncheck"] forState:UIControlStateNormal];
        [_gBtn addTarget:self action:@selector(gBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [_delegateView addSubview:_gBtn];
        _gBtn.selected = NO;
        
        UILabel *lab3 = [[UILabel alloc] initWithFrame:CGRectMake(_gBtn.maxX, 3 * kBL, 30, _gBtn.height - 3 * kBL)];
        lab3.textColor = k153Color;
        lab3.text = @"我已同意用户注册协议";
        lab3.font = kFONT(12);
        [_delegateView addSubview:lab3];
        lab3.userInteractionEnabled = YES;
        lab3.width = [UILabel dmo_getLabelWidthByText:lab3.text font:lab3.font];
        lab3.height = [UILabel dmo_getLabelHeightByWidth:lab3.width text:lab3.text font:lab3.font] + 4 * kBL;
        lab3.maxY = _gBtn.maxY;
        
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(delegatesAction)];
        [lab3 addGestureRecognizer:singleTap];
        
        _delegateView.width = _gBtn.width + lab3.width;
        _delegateView.centerX = self.view.centerX;
    }
    return _delegateView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
