//
//  UserAgreementViewController.m
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/4/2.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "UserAgreementViewController.h"

@interface UserAgreementViewController ()<WKUIDelegate>
@property (nonatomic,strong) UIView *statusView;
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) WKWebView *contentWeb;

@end

@implementation UserAgreementViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
//    [self initData];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
#pragma mark ->delegate/ dataSource Method
//WKScriptMessageHandler协议方法
/// 接收到服务器跳转请求之后调用 (服务器端redirect)，不一定调用
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation{
    
}
/// 3 在收到服务器的响应头，根据response相关信息，决定是否跳转。decisionHandler必须调用，来决定是否跳转，参数WKNavigationActionPolicyCancel取消跳转，WKNavigationActionPolicyAllow允许跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
    
}
/// 1 在发送请求之前，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    
}
/// 2 页面开始加载
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    
}
/// 4 开始获取到网页内容时返回
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{
    
}
/// 5 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    [webView setNeedsLayout];
}
/// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation{
    
}
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    
}

- (WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures{
    if (!navigationAction.targetFrame.isMainFrame) {
        [webView loadRequest:navigationAction.request];
    }
    return nil;
}
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"alert" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler();
    }]];
    
    [self presentViewController:alert animated:YES completion:NULL];
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.statusView];
    [self.view addSubview:self.headView];
    [self.view addSubview:self.contentWeb];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
//    NSDictionary *parameters = @{
//                                 kPlatform:kIOS,
//                                 kVersion:kBuild,
//                                 @"article_id":@"10"
//                                 };
//    [self showLoad];
//    [[DmoNetwork dmo_network] dmo_requestWith:kGetArticleMsgURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
//        [self hideLoad];
//        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
//            NSDictionary *dataDict = [[obj objectForKey:@"data"] objectForKey:@"article_msg"];
//            NSString *dataStr = [NSString stringWithFormat:@"%@",[dataDict objectForKey:@"content"]];
//            NSString *contents = [NSString stringWithFormat:@"%@%@%@",@"<html><head><meta content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0\" name=\"viewport\"><style type=\"text/css\">img{display: inline-block;max-width: 100%}</style></head><body>",dataStr,@"</body></html>"];
//            NSLog(@"contents==%@",contents);
//            [self.contentWeb loadHTMLString:contents baseURL:nil];
//        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            //[self toLoginVC:@""];
//        }else{
//            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
//        }
//    } failure:^(NSString * _Nonnull errMessage) {
//        [self hideLoad];
//        [self showMessage:kMessage_Network_Failure delay:1.5];
//    } requestType:requestTypePost];
}
#pragma mark ->Action Method
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = [UIColor whiteColor];
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"用户协议" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}
- (WKWebView *)contentWeb{
    if (!_contentWeb) {
        _contentWeb = [[WKWebView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - _headView.maxY)];
        _contentWeb.UIDelegate = self;
        _contentWeb.scrollView.scrollEnabled = YES;
        
        //禁止长按弹出 UIMenuController 相关
        //禁止选择 css 配置相关
        NSString *css = @"body{-webkit-user-select:none;-webkit-user-drag:none;}";
        //css 选中样式取消
        NSMutableString *javascript = [NSMutableString string];
        [javascript appendString:@"var style = document.createElement('style');"];
        [javascript appendString:@"style.type = 'text/css';"];
        [javascript appendFormat:@"var cssContent = document.createTextNode('%@');", css];
        [javascript appendString:@"style.appendChild(cssContent);"];
        [javascript appendString:@"document.body.appendChild(style);"];
        [javascript appendString:@"document.documentElement.style.webkitUserSelect='none';"]; //禁止选择
        [javascript appendString:@"document.documentElement.style.webkitTouchCallout='none';"]; //禁止长按
        //javascript 注入
        WKUserScript *noneSelectScript = [[WKUserScript alloc] initWithSource:javascript injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
        WKUserContentController *userContentController = [[WKUserContentController alloc] init];
        [userContentController addUserScript:noneSelectScript];
        WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
        configuration.userContentController = userContentController;
        //控件加载
        [_contentWeb.configuration.userContentController addUserScript:noneSelectScript];
    }
    return _contentWeb;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
