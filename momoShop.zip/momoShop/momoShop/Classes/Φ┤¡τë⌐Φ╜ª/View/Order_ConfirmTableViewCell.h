//
//  Order_ConfirmTableViewCell.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/29.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShopCartModel.h"

NS_ASSUME_NONNULL_BEGIN
@protocol Order_ConfirmCellDelegate <NSObject>
- (void)btnClick:(UITableViewCell *)cell andFlag:(NSInteger)flag;

@end

@interface Order_ConfirmTableViewCell : UITableViewCell
@property (nonatomic,strong) UIImageView *picImgV;
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) UILabel *skuLab;
@property (nonatomic,strong) UILabel *priceLab;
@property (nonatomic,strong) UIButton *lessBtn;
@property (nonatomic,strong) UIButton *addBtn;
@property (nonatomic,strong) UITextField *numTextField;

@property (nonatomic,assign) id<Order_ConfirmCellDelegate> delegate;

//赋值
- (void)addTheValue:(ShopCartModel *)model;


@end

NS_ASSUME_NONNULL_END
