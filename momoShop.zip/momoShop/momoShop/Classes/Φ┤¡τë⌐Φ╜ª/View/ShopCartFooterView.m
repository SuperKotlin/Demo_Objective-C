//
//  ShopCartFooterView.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/29.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "ShopCartFooterView.h"

@implementation ShopCartFooterView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self){
        [self setupUI];
    }
    return self;
}
- (void)setupUI{
    self.backgroundColor = [UIColor whiteColor];
    self.layer.borderColor = kGrayBgColor.CGColor;
    self.layer.borderWidth = 0.5;
    
    //全选按钮
    self.allSelecteBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 60 * kBL, 40 * kBL)];
    [self.allSelecteBtn setImage:[UIImage imageNamed:@"car_normal"] forState:UIControlStateNormal];
    [self.allSelecteBtn setTitle:@" 全选" forState:UIControlStateNormal];
    [self.allSelecteBtn setTitleColor:k51Color forState:UIControlStateNormal];
    self.allSelecteBtn.titleLabel.font = kFONT(13);
    [self addSubview:self.allSelecteBtn];
    
    self.totalLab = [[UILabel alloc] initWithFrame:CGRectMake(self.allSelecteBtn.maxX, 0, kScreenWidth - self.allSelecteBtn.maxX - 110 * kBL, self.height)];
    self.totalLab.text = @"合计:¥0.00";
    self.totalLab.textColor = k51Color;
    self.totalLab.font = kFONT(14);
    [self addSubview:self.totalLab];

    //结算
    self.submitBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.totalLab.maxX, 0, 96 * kBL, 32 * kBL)];
    [self.submitBtn setBackgroundColor:kDefaultColor];
    [self.submitBtn setTitle:@"去结算(0)" forState:UIControlStateNormal];
    [self.submitBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.submitBtn.titleLabel.font = kFONT(13);
    [self.submitBtn dmo_setCornerRadius:16 * kBL];
    [self addSubview:self.submitBtn];
    self.submitBtn.centerY = self.totalLab.centerY;
    self.submitBtn.maxX = self.width - 8 * kBL;
    
    self.deleteBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 66 * kBL, 28 * kBL)];
    [self.deleteBtn setTitle:@"删除" forState:UIControlStateNormal];
    [self.deleteBtn setTitleColor:kDefaultColor forState:UIControlStateNormal];
    self.deleteBtn.titleLabel.font = kFONT(13);
    [self.deleteBtn dmo_setCornerRadius:14 * kBL];
    [self.deleteBtn dmo_setBorder:1.f color:kDefaultColor];
    [self addSubview:self.deleteBtn];
    self.deleteBtn.centerY = self.totalLab.centerY;
    self.deleteBtn.maxX = self.width - 8 * kBL;
    self.deleteBtn.hidden = YES;
    
    self.collectBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 66 * kBL, 28 * kBL)];
    [self.collectBtn setTitle:@"移入收藏" forState:UIControlStateNormal];
    [self.collectBtn setTitleColor:kGrayLabColor forState:UIControlStateNormal];
    self.collectBtn.titleLabel.font = kFONT(13);
    [self.collectBtn dmo_setCornerRadius:14 * kBL];
    [self.collectBtn dmo_setBorder:1.f color:kGrayLabColor];
    [self addSubview:self.collectBtn];
    self.collectBtn.centerY = self.deleteBtn.centerY;
    self.collectBtn.maxX = self.deleteBtn.minX - 10 * kBL;
    self.collectBtn.hidden = YES;
}

@end
