//
//  ShopCartTableViewCell.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/28.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "ShopCartTableViewCell.h"

@implementation ShopCartTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UIView *mainView = [[UIView alloc] initWithFrame:CGRectMake(0, 10 * kBL, kScreenWidth, 120 * kBL)];
        mainView.backgroundColor = [UIColor whiteColor];
        [mainView dmo_setCornerRadius:10.f];
        [self.contentView addSubview:mainView];
        
        self.checkBtn = [[UIButton alloc] initWithFrame:CGRectMake(8 * kBL, 0, 18 * kBL, 18 * kBL)];
        [self.checkBtn setImage:[UIImage imageNamed:@"car_normal"] forState:UIControlStateNormal];
        [self.checkBtn setImage:[UIImage imageNamed:@"car_pressed"] forState:UIControlStateSelected];
        [self.checkBtn addTarget:self action:@selector(selectBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        self.checkBtn.centerY = mainView.height / 2.0;
        [mainView addSubview:self.checkBtn];
        self.checkBtn.tag = kTagStart + 13;
        
        self.picImgV = [[UIImageView alloc] initWithFrame:CGRectMake(self.checkBtn.maxX + 8 * kBL, 0, 78 * kBL, 78 * kBL)];
        self.picImgV.centerY = mainView.height / 2.0;
        [mainView addSubview:self.picImgV];
        
        self.nameLab = [[UILabel alloc] initWithFrame:CGRectMake(self.picImgV.maxX + 6 * kBL, self.picImgV.minY, kScreenWidth - self.picImgV.maxX - 14 * kBL, 34 * kBL)];
        self.nameLab.font = kFONT(14);
        self.nameLab.numberOfLines = 0;
        self.nameLab.textColor = k51Color;
        [mainView addSubview:self.nameLab];
        
        self.skuLab = [[UILabel alloc] initWithFrame:CGRectMake(self.nameLab.minX, self.nameLab.maxY, self.nameLab.width, 20 * kBL)];
        self.skuLab.font = kFONT(12);
        self.skuLab.textColor = k153Color;
        [mainView addSubview:self.skuLab];
        
        self.priceLab = [[UILabel alloc] initWithFrame:CGRectMake(self.nameLab.minX, self.skuLab.maxY, self.nameLab.width - 74 * kBL, 22 * kBL)];
        self.priceLab.font = kFONT(16);
        self.priceLab.textColor = kDefaultColor;
        [mainView addSubview:self.priceLab];
        
        UIView *numView = [[UIView alloc] initWithFrame:CGRectMake(self.priceLab.maxX, 0, 74 * kBL, 22 * kBL)];
        numView.centerY = self.priceLab.centerY;
        [mainView addSubview:numView];
        
        self.lessBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 20 * kBL, 20 * kBL)];
        [self.lessBtn setImage:[UIImage imageNamed:@"cart_less"] forState:UIControlStateNormal];
        self.lessBtn.centerY = numView.height / 2.0;
        [self.lessBtn addTarget:self action:@selector(lessBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [numView addSubview:self.lessBtn];
        self.lessBtn.tag = kTagStart + 11;
        
        _numTextField = [[UITextField alloc] initWithFrame:CGRectMake(self.lessBtn.maxX, 0, 34 * kBL, self.lessBtn.height)];
        _numTextField.font = kFONT(13);
        _numTextField.textAlignment = NSTextAlignmentCenter;
        _numTextField.backgroundColor = k244Color;
        _numTextField.userInteractionEnabled = NO;
        [numView addSubview:_numTextField];
        _numTextField.centerY = self.lessBtn.centerY;
        
        self.addBtn = [[UIButton alloc] initWithFrame:CGRectMake(_numTextField.maxX, 0, self.lessBtn.width, self.lessBtn.height)];
        [self.addBtn setImage:[UIImage imageNamed:@"cart_add"] forState:UIControlStateNormal];
        self.addBtn.centerY = self.lessBtn.centerY;
        [self.addBtn addTarget:self action:@selector(addBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [numView addSubview:self.addBtn];
        self.addBtn.tag = kTagStart + 12;
    }
    return self;
}
- (void)addTheValue:(ShopCartModel *)model{
    [self.picImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,model.img]] placeholderImage:[UIImage imageNamed:@""]];
    self.nameLab.text = [NSString stringWithFormat:@"%@",model.goods_name];

    NSArray *sku_arr = model.sku_arr;
    if (sku_arr.count == 0) {
        self.skuLab.text = @"";
    }else{
        NSArray *attribute_nameArr = [sku_arr valueForKey:@"value"];
        self.skuLab.text = [NSString stringWithFormat:@"%@",[attribute_nameArr componentsJoinedByString:@";"]];
    }
    self.priceLab.text = [NSString stringWithFormat:@"¥%@",model.price];
    self.numTextField.text = [NSString stringWithFormat:@"%ld",(long)model.goods_num];
    
    if (model.selectState){
        self.selectState = YES;
        [self.checkBtn setImage:[UIImage imageNamed:@"car_pressed"] forState:UIControlStateNormal];
    }else{
        self.selectState = NO;
        [self.checkBtn setImage:[UIImage imageNamed:@"car_normal"] forState:UIControlStateNormal];
    }
}
//勾选
- (void)selectBtnAction:(UIButton *)sender{
    [self.delegate btnClick:self andFlag:(sender.tag - kTagStart)];
}
//减
- (void)lessBtnAction:(UIButton *)sender{
    [self.delegate btnClick:self andFlag:(sender.tag - kTagStart)];
}
//加
- (void)addBtnAction:(UIButton *)sender{
    [self.delegate btnClick:self andFlag:(sender.tag - kTagStart)];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

