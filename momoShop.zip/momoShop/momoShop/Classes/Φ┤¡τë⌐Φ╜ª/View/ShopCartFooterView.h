//
//  ShopCartFooterView.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/29.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ShopCartFooterView : UIView
@property (nonatomic,strong) UIButton *allSelecteBtn;
@property (nonatomic,strong) UILabel *totalLab;//总价
@property (nonatomic,strong) UIButton *submitBtn;//结算

@property (nonatomic,strong) UIButton *collectBtn; //移入收藏
@property (nonatomic,strong) UIButton *deleteBtn; //删除

@end

NS_ASSUME_NONNULL_END
