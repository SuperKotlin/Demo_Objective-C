//
//  ShopCartTableViewCell.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/28.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShopCartModel.h"

NS_ASSUME_NONNULL_BEGIN
@protocol ShopCartCellDelegate <NSObject>
- (void)btnClick:(UITableViewCell *)cell andFlag:(NSInteger)flag;

@end

@interface ShopCartTableViewCell : UITableViewCell
@property (nonatomic,strong) UIButton *checkBtn;
@property (nonatomic,strong) UIImageView *picImgV;
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) UILabel *skuLab;
@property (nonatomic,strong) UILabel *priceLab;
@property (nonatomic,strong) UIButton *lessBtn;
@property (nonatomic,strong) UIButton *addBtn;
@property (nonatomic,strong) UITextField *numTextField;

@property (nonatomic,assign) BOOL selectState; //选中状态
@property (nonatomic,assign) id<ShopCartCellDelegate> delegate;

//赋值
- (void)addTheValue:(ShopCartModel *)model;



@end

NS_ASSUME_NONNULL_END
