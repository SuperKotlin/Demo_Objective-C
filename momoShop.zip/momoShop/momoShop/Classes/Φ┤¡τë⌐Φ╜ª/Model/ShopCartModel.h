//
//  ShopCartModel.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/28.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ShopCartModel : NSObject
@property (nonatomic,copy) NSString *item_id;
@property (nonatomic,copy) NSString *goods_id;
@property (nonatomic,copy) NSString *goods_name;
@property (nonatomic,assign) NSInteger goods_num;
@property (nonatomic,copy) NSString *goods_sku;
@property (nonatomic,copy) NSString *deduction_point;
@property (nonatomic,copy) NSString *give_point;
@property (nonatomic,copy) NSString *img;
@property (nonatomic,copy) NSString *inventory;
@property (nonatomic,copy) NSString *postage;
@property (nonatomic,copy) NSString *price;
@property (nonatomic,copy) NSString *tmp_img;
@property (nonatomic,copy) NSArray *sku_arr;
@property (nonatomic,assign) BOOL selectState;//是否选中状态
//@property (nonatomic,copy) NSString *;
//@property (nonatomic,copy) NSString *;
//@property (nonatomic,copy) NSString *;
//@property (nonatomic,copy) NSString *;
//@property (nonatomic,copy) NSString *;
//@property (nonatomic,copy) NSString *;

@end

NS_ASSUME_NONNULL_END
