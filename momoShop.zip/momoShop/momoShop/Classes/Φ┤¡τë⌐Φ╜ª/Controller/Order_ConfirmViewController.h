//
//  Order_ConfirmViewController.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/29.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Order_ConfirmViewController : UIViewController
@property (nonatomic,strong) NSArray *selectArr;

@property (nonatomic,strong) UIView *fullView;
@property (nonatomic,strong) UIView *nullView;
@property (nonatomic,strong) UILabel *addressDetailLab;
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) NSString *addressIdStr;

@end

NS_ASSUME_NONNULL_END
