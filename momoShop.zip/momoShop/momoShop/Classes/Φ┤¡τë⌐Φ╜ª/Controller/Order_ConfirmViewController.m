//
//  Order_ConfirmViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/29.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "Order_ConfirmViewController.h"
#import "AddressViewController.h"
#import "Order_ConfirmTableViewCell.h"
#import "Order_BuyViewController.h"

@interface Order_ConfirmViewController ()<UITableViewDataSource,UITableViewDelegate,Order_ConfirmCellDelegate>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIScrollView *mScrollView;
@property (nonatomic,strong) UIButton *addressBtn;
@property (nonatomic,strong) UITableView *listTableView;
@property (nonatomic,strong) NSMutableArray *listMutArr;
@property (nonatomic,strong) UIView *centerView;
@property (nonatomic,strong) UIView *moneyView;
@property (nonatomic,strong) UILabel *fapiaoLab;
@property (nonatomic,strong) UILabel *quanLab;
@property (nonatomic,strong) UILabel *pointLab;
@property (nonatomic,strong) UILabel *moneyLab;
@property (nonatomic,strong) UILabel *postageLab;
@property (nonatomic,strong) UIView *footerView;
@property (nonatomic,strong) UILabel *totalLab;
@property (nonatomic,assign) CGFloat allPrice;

@end

@implementation Order_ConfirmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self getAddressData];
    [self initData];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.listMutArr.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 130 * kBL;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    Order_ConfirmTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[Order_ConfirmTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = kGrayBgColor;
    
    cell.delegate = self;
    [cell addTheValue:self.listMutArr[indexPath.row]];
    
    return cell;
}
/**
 *  实现加减按钮点击代理事件
 *  @param cell 当前单元格
 *  @param flag 按钮标识，11 为减按钮，12为加按钮
 */
- (void)btnClick:(UITableViewCell *)cell andFlag:(NSInteger)flag{
    NSIndexPath *index = [self.listTableView indexPathForCell:cell];
    switch (flag) {
        case 11:{
            //做减法 先获取到当期行数据源内容，改变数据源内容，刷新表格
            ShopCartModel *model = self.listMutArr[index.row];
            if (model.goods_num > 1){
                model.goods_num --;
            }else{
                [self showMessage:@"已是最小数量" delay:1.5];
            }
            [self.listTableView reloadRowsAtIndexPaths:@[index] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
            break;
        case 12:{
            //做加法
            ShopCartModel *model = self.listMutArr[index.row];
            if (model.goods_num >= [model.inventory intValue]) {
                [self showMessage:@"库存不足" delay:1.5];
            }else{
                model.goods_num ++;
            }
            [self.listTableView reloadRowsAtIndexPaths:@[index] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
            break;
        default:
            break;
    }
    //计算总价
    [self totalPrice];
}
- (void)totalPrice{
    self.allPrice = 0;
    CGFloat postage = 0;
    //遍历整个数据源，然后判断如果是选中的商品，就计算价格（单价 * 商品数量）
    for (int i = 0; i < self.listMutArr.count; i++){
        ShopCartModel *model = [self.listMutArr objectAtIndex:i];
        self.allPrice += (model.goods_num * [model.price floatValue]);
        postage += (model.goods_num * [model.postage floatValue]);
    }
    //计算邮费
    _postageLab.text = [NSString stringWithFormat:@"+¥%.2f",postage];
    
    //计算总价
    _moneyLab.text = [NSString stringWithFormat:@"¥%.2f",self.allPrice];
    _totalLab.text = [NSString stringWithFormat:@"¥%.2f",self.allPrice];
    
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:_totalLab.text];
    [str addAttribute:NSFontAttributeName value:kFONT(12) range:NSMakeRange(0, 1)];
    _totalLab.attributedText = str;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.mScrollView];
    [self.mScrollView addSubview:self.addressBtn];
    [self.mScrollView addSubview:self.listTableView];
    [self.mScrollView addSubview:self.centerView];
    [self.mScrollView addSubview:self.moneyView];
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, self.moneyView.maxY);
    [self.view addSubview:self.footerView];
}
- (void)backViewController{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ShopCartListRefresh" object:nil userInfo:nil];
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)getAddressData{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetAddressListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSArray *array = [[obj objectForKey:@"data"] objectForKey:@"list"];
            if (array.count == 0) {
                self.nullView.hidden = NO;
                self.addressIdStr = @"";
            }else{
                self.nullView.hidden = YES;
                for (int i = 0; i < array.count; i++) {
                    NSString *isdefault = [NSString stringWithFormat:@"%@",array[i][@"is_default"]];
                    if ([isdefault isEqualToString:@"Y"]) {
                        self.nameLab.text = [NSString stringWithFormat:@"%@   %@",array[i][@"consignee"],array[i][@"contact_number"]];
                        NSString *pcaStr = [NSString stringWithFormat:@"%@%@%@",array[i][@"province"],array[i][@"city"],array[i][@"county"]];
                        self.addressDetailLab.text = [NSString stringWithFormat:@"%@%@",pcaStr,array[i][@"detail_address"]];
                        self.addressIdStr = [NSString stringWithFormat:@"%@",array[i][@"id"]];
                    }
                }
            }
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
- (void)initData{
    self.listMutArr = [NSMutableArray arrayWithArray:self.selectArr];
    [self.listTableView reloadData];
    
    self.listTableView.height = self.listMutArr.count * 130 * kBL;
    self.centerView.minY = self.listTableView.maxY + 6 * kBL;
    self.moneyView.minY = self.centerView.maxY + 6 * kBL;
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, self.moneyView.maxY + 6 * kBL);
    
    //计算总价
    [self totalPrice];
}
#pragma mark ->Action Method
- (void)addressBtnAction{
    AddressViewController *addV = [[AddressViewController alloc] init];
    addV.typeStr = @"1";
    [self.navigationController pushViewController:addV animated:YES];
}
- (void)funBtnAction:(UIButton *)sender{
    switch (sender.tag - kTagStart) {
        case 0:
        {
            
        }
            break;
        case 1:
        {
            
        }
            break;
        case 2:
        {
            
        }
            break;
            
        default:
            break;
    }
}
- (void)chargeBtnAction{
    NSMutableArray *tempArr = [NSMutableArray array];
    for (int i = 0; i < self.listMutArr.count; i++){
        ShopCartModel *model = [self.listMutArr objectAtIndex:i];
        NSDictionary *dic = @{
                              @"shopcart_id":model.item_id,
                              @"goods_num":[NSString stringWithFormat:@"%ld",model.goods_num]
                              };
        [tempArr addObject:dic];
    }
    NSDictionary *parameters;
    if (tempArr.count == 0) {
        parameters = @{
                       kPlatform:kIOS,
                       kVersion:kBuild,
                       kToken:kUserDefaults_OBJECTFORKEY(kToken),
                       @"address_id":self.addressIdStr,
                       @"deduction_point":@"",
                       @"remark":@""
                       };
    }else{
        parameters = @{
                       kPlatform:kIOS,
                       kVersion:kBuild,
                       kToken:kUserDefaults_OBJECTFORKEY(kToken),
                       @"goodslist":[tempArr ToJsonString],
                       @"address_id":self.addressIdStr,
                       @"deduction_point":@"",
                       @"remark":@""
                       };
    }
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kOrderByShopcartURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            Order_BuyViewController *byV = [[Order_BuyViewController alloc] init];
            byV.order_id = [NSString stringWithFormat:@"%@",[obj[@"data"] objectForKey:@"order_id"]];
            byV.allprice = [NSString stringWithFormat:@"%@",[obj[@"data"] objectForKey:@"allprice"]];
            [self.navigationController pushViewController:byV animated:YES];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"ShopCartViewRefresh" object:nil userInfo:nil];
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"提交订单" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}
- (UIScrollView *)mScrollView{
    if (!_mScrollView) {
        _mScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - _headView.maxY - kFooterHeight - 44 * kBL)];
        _mScrollView.backgroundColor = kGrayBgColor;
    }
    return _mScrollView;
}
- (UIButton *)addressBtn{
    if (!_addressBtn) {
        _addressBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 90 * kBL)];
        _addressBtn.backgroundColor = [UIColor whiteColor];
        [_addressBtn addTarget:self action:@selector(addressBtnAction) forControlEvents:UIControlEventTouchUpInside];
        
        UIImageView *addImgV = [[UIImageView alloc] initWithFrame:CGRectMake(12 * kBL, 0, 18 * kBL, 18 * kBL)];
        addImgV.image = [UIImage imageNamed:@"address_icon"];
        addImgV.centerY = _addressBtn.height / 2.0;
        [_addressBtn addSubview:addImgV];
        
        UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 5 * kBL, 7 * kBL)];
        rImgV.image = [UIImage imageNamed:@"right"];
        rImgV.centerY = _addressBtn.height / 2.0;
        [_addressBtn addSubview:rImgV];
        rImgV.maxX = kScreenWidth - 12 * kBL;
        
        _fullView = [[UIView alloc] initWithFrame:CGRectMake(addImgV.maxX, 0, kScreenWidth - addImgV.maxX - 12 * kBL, 90 * kBL)];
        [_addressBtn addSubview:_fullView];
        _fullView.userInteractionEnabled = NO;
        
        _addressDetailLab = [[UILabel alloc] initWithFrame:CGRectMake(8 * kBL, 8 * kBL, _fullView.width - 16 * kBL, 44 * kBL)];
        _addressDetailLab.textColor = [UIColor blackColor];
        _addressDetailLab.font = kFONT_BOLD(15);
        _addressDetailLab.numberOfLines = 0;
        [_fullView addSubview:_addressDetailLab];
        
        _nameLab = [[UILabel alloc] initWithFrame:CGRectMake(_addressDetailLab.minX, _addressDetailLab.maxY, _addressDetailLab.width, 22 * kBL)];
        _nameLab.textColor = k153Color;
        _nameLab.font = kFONT(13);
        [_fullView addSubview:_nameLab];
        
        _nullView = [[UIView alloc] initWithFrame:CGRectMake(addImgV.maxX, 0, kScreenWidth - addImgV.maxX - 12 * kBL, 90 * kBL)];
        [_addressBtn addSubview:_nullView];
        _nullView.userInteractionEnabled = NO;
        _nullView.hidden = YES;
        
        UILabel *nilAddressLabel = [[UILabel alloc] initWithFrame:CGRectMake(6 * kBL, 0, kScreenWidth, 16 * kBL)];
        nilAddressLabel.font = kFONT(13);
        nilAddressLabel.text = @"您还没有添加收货地址，去添加";
        [_nullView addSubview:nilAddressLabel];
        nilAddressLabel.centerY = _nullView.height / 2.0;
    }
    return _addressBtn;
}
- (UITableView *)listTableView{
    if (!_listTableView) {
        _listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, _addressBtn.maxY, kScreenWidth, 0) style:UITableViewStylePlain];
        _listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listTableView.backgroundColor = [UIColor whiteColor];
        _listTableView.delegate = self;
        _listTableView.dataSource = self;
        _listTableView.scrollEnabled = NO;
        _listTableView.showsVerticalScrollIndicator = NO;
    }
    return _listTableView;
}
- (UIView *)centerView{
    if (!_centerView) {
        _centerView = [[UIView alloc] initWithFrame:CGRectMake(0, _listTableView.maxY + 6 * kBL, kScreenWidth, 96 * kBL)];
        _centerView.backgroundColor = [UIColor whiteColor];
        
        NSArray *tArr = @[@"发票",@"优惠券",@"积分"];
        for (int i = 0; i < 3; i ++) {
            UIButton *funBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 12 * kBL + 24 * kBL * i, kScreenWidth, 24 * kBL)];
            funBtn.tag = kTagStart + i;
            [funBtn addTarget:self action:@selector(funBtnAction:) forControlEvents:UIControlEventTouchUpInside];
            [_centerView addSubview:funBtn];
            
            UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 0, 110 * kBL, funBtn.height)];
            leftLabel.font = kFONT(14);
            leftLabel.text = tArr[i];
            leftLabel.textColor = k51Color;
            [funBtn addSubview:leftLabel];
            
            UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 5 * kBL, 7 * kBL)];
            rImgV.image = [UIImage imageNamed:@"right"];
            rImgV.maxX = kScreenWidth - 10 * kBL;
            rImgV.centerY = leftLabel.centerY;
            [funBtn addSubview:rImgV];
        }
        
        _fapiaoLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 12 * kBL, 120 * kBL, 24 * kBL)];
        _fapiaoLab.font = kFONT(14);
        _fapiaoLab.text = @"个人";
        _fapiaoLab.textColor = k51Color;
        _fapiaoLab.maxX = kScreenWidth - 20 * kBL;
        _fapiaoLab.textAlignment = NSTextAlignmentRight;
        [_centerView addSubview:_fapiaoLab];
        
        _quanLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _fapiaoLab.maxY, 120 * kBL, 24 * kBL)];
        _quanLab.font = kFONT(14);
        _quanLab.text = @"无可用";
        _quanLab.textColor = k51Color;
        _quanLab.maxX = kScreenWidth - 20 * kBL;
        _quanLab.textAlignment = NSTextAlignmentRight;
        [_centerView addSubview:_quanLab];
        
        _pointLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _quanLab.maxY, 120 * kBL, 24 * kBL)];
        _pointLab.font = kFONT(14);
        _pointLab.text = @"无可用";
        _pointLab.textColor = k51Color;
        _pointLab.maxX = kScreenWidth - 20 * kBL;
        _pointLab.textAlignment = NSTextAlignmentRight;
        [_centerView addSubview:_pointLab];
    }
    return _centerView;
}
- (UIView *)moneyView{
    if (!_moneyView) {
        _moneyView = [[UIView alloc] initWithFrame:CGRectMake(0, _centerView.maxY + 6 * kBL, kScreenWidth, 24 * kBL + 24 * kBL * 2)];
        _moneyView.backgroundColor = [UIColor whiteColor];
        
        NSArray *tArr = @[@"商品金额",@"运费"];
        for (int i = 0; i < 2; i ++) {
            UIButton *funBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 12 * kBL + 24 * kBL * i, kScreenWidth, 24 * kBL)];
            funBtn.tag = kTagStart + i;
            [_moneyView addSubview:funBtn];
            
            UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 0, 110 * kBL, funBtn.height)];
            leftLabel.font = kFONT(14);
            leftLabel.text = tArr[i];
            leftLabel.textColor = k51Color;
            [funBtn addSubview:leftLabel];
        }
        _moneyLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 12 * kBL,kScreenWidth - 130 * kBL, 24 * kBL)];
        _moneyLab.font = kFONT(14);
        _moneyLab.textColor = k51Color;
        _moneyLab.maxX = kScreenWidth - 10 * kBL;
        _moneyLab.textAlignment = NSTextAlignmentRight;
        [_moneyView addSubview:_moneyLab];
        
        _postageLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _moneyLab.maxY,kScreenWidth - 130 * kBL, 24 * kBL)];
        _postageLab.font = kFONT(14);
        _postageLab.textColor = k51Color;
        _postageLab.maxX = kScreenWidth - 10 * kBL;
        _postageLab.textAlignment = NSTextAlignmentRight;
        [_moneyView addSubview:_postageLab];
    }
    return _moneyView;
}
- (UIView *)footerView{
    if (!_footerView) {
        _footerView = [[UIView alloc] initWithFrame:CGRectMake(0, kScreenHeight - 44 * kBL - kFooterHeight, kScreenWidth, 44 * kBL)];
        _footerView.backgroundColor = [UIColor whiteColor];
        
        _totalLab = [[UILabel alloc] initWithFrame:CGRectMake(12 * kBL, 0, kScreenWidth - 120 * kBL, _footerView.height)];
        _totalLab.font = kFONT(17);
        _totalLab.textColor = kDefaultColor;
        [_footerView addSubview:_totalLab];
        
        UIButton *ruleBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 98 * kBL, 34 * kBL)];
        [ruleBtn setTitle:@"立即支付" forState:UIControlStateNormal];
        [ruleBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        ruleBtn.titleLabel.font = kFONT(15);
        ruleBtn.backgroundColor = kDefaultColor;
        [ruleBtn dmo_setCornerRadius:17 * kBL];
        [ruleBtn addTarget:self action:@selector(chargeBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_footerView addSubview:ruleBtn];
        ruleBtn.centerY = _footerView.height / 2.0;
        ruleBtn.maxX = kScreenWidth - 10 * kBL;
    }
    return _footerView;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
