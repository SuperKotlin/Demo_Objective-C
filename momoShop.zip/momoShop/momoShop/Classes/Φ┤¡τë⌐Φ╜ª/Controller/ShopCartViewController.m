//
//  ShopCartViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/5.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "ShopCartViewController.h"
#import "ShopCartTableViewCell.h"
#import "ShopCartModel.h"
#import "ShopCartFooterView.h"
#import "Order_ConfirmViewController.h"

@interface ShopCartViewController ()<UITableViewDataSource,UITableViewDelegate,ShopCartCellDelegate>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIButton *manaButton;
//空
@property (nonatomic,strong) UIView *nilView;
@property (nonatomic,strong) UIScrollView *mScrollView;
//有数据
@property (nonatomic,strong) UIView *fullView;
@property (nonatomic,strong) UITableView *listTableView;
@property (nonatomic,strong) NSMutableArray *listMutArr;
@property (nonatomic,strong) ShopCartFooterView *scfooterView;
@property (nonatomic,strong) NSMutableArray *selectMutArray;
@property (nonatomic,assign) CGFloat allPrice;

@end

@implementation ShopCartViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
    self.allPrice = 0;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ShopCartViewRefresh) name:@"ShopCartViewRefresh" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ShopCartListRefresh) name:@"ShopCartListRefresh" object:nil];
}
- (void)ShopCartViewRefresh{
    [self resetPriceData];
    [self initData];
}
- (void)resetPriceData{
    self.allPrice = 0;
    for (int i = 0; i < self.listMutArr.count; i++){
        ShopCartModel *model = [self.listMutArr objectAtIndex:i];
        model.selectState = NO;
    }
    //计算总价
    [self totalPrice];
    [self.scfooterView.allSelecteBtn setImage:[UIImage imageNamed:@"car_normal"] forState:UIControlStateNormal];
    self.scfooterView.allSelecteBtn.selected = NO;
}
- (void)ShopCartListRefresh{
    [self.listTableView reloadData];
    //计算总价
    [self totalPrice];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.listMutArr.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 130 * kBL;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    ShopCartTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[ShopCartTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = kGrayBgColor;
    
    cell.delegate = self;
    [cell addTheValue:self.listMutArr[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.nilView];
    [self.nilView addSubview:self.mScrollView];
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, kScreenHeight - kHeaderHeight - kTabBarHeight);
    [self.view addSubview:self.fullView];
    [self.fullView addSubview:self.listTableView];
    [self.fullView addSubview:self.scfooterView];
    self.fullView.hidden = YES;
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        
    }else{
        self.listMutArr = [NSMutableArray array];
        NSDictionary *parameters = @{
                                     kPlatform:kIOS,
                                     kVersion:kBuild,
                                     kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                     };
        [self showLoad];
        [[DmoNetwork dmo_network] dmo_requestWith:kGetShopcartListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
            [self hideLoad];
            if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                NSArray *arr = [[obj objectForKey:@"data"] objectForKey:@"list"];
                if (arr.count == 0) {
                    self.nilView.hidden = NO;
                    self.fullView.hidden = YES;
                }else{
                    self.nilView.hidden = YES;
                    self.fullView.hidden = NO;
                }
                
                for (NSDictionary *comDict in arr) {
                    ShopCartModel *model = [[ShopCartModel alloc] init];
                    model.item_id = comDict[@"id"];
                    model.goods_id = comDict[@"goods_id"];
                    model.goods_name = comDict[@"goods_name"];
                    model.goods_num = [[NSString stringWithFormat:@"%@",comDict[@"goods_num"]] intValue];
                    model.goods_sku = comDict[@"goods_sku"];
                    model.deduction_point = comDict[@"deduction_point"];
                    model.give_point = comDict[@"give_point"];
                    model.img = comDict[@"img"];
                    model.inventory = comDict[@"inventory"];
                    if ([self isNil:comDict[@"postage"]]) {
                        model.postage = @"0";
                    }else{
                        model.postage = comDict[@"postage"];
                    }
                    model.price = comDict[@"price"];
                    model.tmp_img = comDict[@"tmp_img"];
                    model.sku_arr = comDict[@"sku_arr"];
                    model.selectState = NO;
                    [self.listMutArr addObject:model];
                }
                [self.listTableView reloadData];
                
            }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
                [self toLoginVC:@"ShopCartVC"];
            }else{
                [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            }
            [self.listTableView.mj_header endRefreshing];
            [self resetPriceData];
        } failure:^(NSString * _Nonnull errMessage) {
            [self hideLoad];
            [self showMessage:kMessage_Network_Failure delay:1.5];
            [self.listTableView.mj_header endRefreshing];
        } requestType:requestTypePost];
    }
}
#pragma mark ->Action Method
- (void)gBtnAction{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NOTIFICATION_CHANGE_TABBAR" object:@(0)];
}
//编辑、完成
- (void)manaButtonAction:(UIButton *)sender{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"ShopCartVC"];
    }else{
        if (!sender.selected) {
            self.scfooterView.submitBtn.hidden = YES;
            self.scfooterView.totalLab.hidden = YES;
            self.scfooterView.collectBtn.hidden = NO;
            self.scfooterView.deleteBtn.hidden = NO;
        }else{
            self.scfooterView.submitBtn.hidden = NO;
            self.scfooterView.totalLab.hidden = NO;
            self.scfooterView.collectBtn.hidden = YES;
            self.scfooterView.deleteBtn.hidden = YES;
        }
        sender.selected = !sender.selected;
    }
}
#pragma mark -- 实现加减按钮点击代理事件
/**
 *  实现加减按钮点击代理事件
 *  @param cell 当前单元格
 *  @param flag 按钮标识，11 为减按钮，12为加按钮
 */
- (void)btnClick:(UITableViewCell *)cell andFlag:(NSInteger)flag{
    NSIndexPath *index = [self.listTableView indexPathForCell:cell];
    switch (flag) {
        case 11:{
            //做减法 先获取到当期行数据源内容，改变数据源内容，刷新表格
            ShopCartModel *model = self.listMutArr[index.row];
            if (model.goods_num > 1){
                model.goods_num --;
            }else{
                [self showMessage:@"已是最小数量" delay:1.5];
            }
            [self.listTableView reloadRowsAtIndexPaths:@[index] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
            break;
        case 12:{
            //做加法
            ShopCartModel *model = self.listMutArr[index.row];
            if (model.goods_num >= [model.inventory intValue]) {
                [self showMessage:@"库存不足" delay:1.5];
            }else{
                model.goods_num ++;
            }
            [self.listTableView reloadRowsAtIndexPaths:@[index] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
            break;
        case 13:{
            //先获取到当期行数据源内容，改变数据源内容，刷新表格
            ShopCartModel *model = self.listMutArr[index.row];
            if (model.selectState)            {
                model.selectState = NO;
            }else {
                model.selectState = YES;
            }
            
            //判断是否都选中了
            NSMutableArray *seMutArr = [NSMutableArray array];
            for (int i = 0; i < self.listMutArr.count; i++){
                ShopCartModel *model = [self.listMutArr objectAtIndex:i];
                if (model.selectState == YES) {
                    [seMutArr addObject:@"y"];
                }
            }
            
            if (seMutArr.count == self.listMutArr.count) {
                //说明全都选了
                [self.scfooterView.allSelecteBtn setImage:[UIImage imageNamed:@"car_pressed"] forState:UIControlStateNormal];
                self.scfooterView.allSelecteBtn.selected = YES;
            }else{
                //说明有未选的
                [self.scfooterView.allSelecteBtn setImage:[UIImage imageNamed:@"car_normal"] forState:UIControlStateNormal];
                self.scfooterView.allSelecteBtn.selected = NO;
            }
            
            [self.listTableView reloadRowsAtIndexPaths:@[index] withRowAnimation:UITableViewRowAnimationAutomatic];
            
            break;
        }
        default:
            break;
    }
    //计算总价
    [self totalPrice];
}
#pragma mark -- 计算价格
- (void)totalPrice{
    self.selectMutArray = [NSMutableArray array];
    //遍历整个数据源，然后判断如果是选中的商品，就计算价格（单价 * 商品数量）
    for (int i = 0; i < self.listMutArr.count; i++){
        ShopCartModel *model = [self.listMutArr objectAtIndex:i];
        if (model.selectState){
            self.allPrice += (model.goods_num * [model.price floatValue]);
            [self.selectMutArray addObject:model];
        }
    }
    //给总价文本赋值
    self.scfooterView.totalLab.text = [NSString stringWithFormat:@"合计:¥%.2f",self.allPrice];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:self.scfooterView.totalLab.text];
    [str addAttribute:NSForegroundColorAttributeName value:k51Color range:NSMakeRange(0, 3)];
    self.scfooterView.totalLab.attributedText = str;
    [self.scfooterView.submitBtn setTitle:[NSString stringWithFormat:@"去结算(%ld)",self.selectMutArray.count] forState:UIControlStateNormal];
    //每次算完要重置为0，因为每次的都是全部循环算一遍
    self.allPrice = 0;
}
//全选
- (void)goAllSelect:(UIButton *)sender{
    //判断是否选中，是改成否，否改成是，改变图片状态
    sender.selected = !sender.selected;
    if (sender.selected){
        [sender setImage:[UIImage imageNamed:@"car_pressed"] forState:UIControlStateNormal];
    }else{
        [sender setImage:[UIImage imageNamed:@"car_normal"] forState:UIControlStateNormal];
    }
    //改变单元格选中状态
    for (int i = 0; i < self.listMutArr.count; i++){
        ShopCartModel *model = [self.listMutArr objectAtIndex:i];
        model.selectState = sender.selected;
    }
    //计算价格
    [self totalPrice];
    //刷新表格
    [self.listTableView reloadData];
}
//移入收藏
- (void)collectBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"ShopCartVC"];
    }else{
        
    }
}
//删除
- (void)deleteBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"ShopCartVC"];
    }else{
        
    }
}
//去结算
- (void)goStatement{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@"ShopCartVC"];
    }else{
        NSString *p = [self.scfooterView.totalLab.text substringFromIndex:4];
        NSLog(@"p-%@",p);
        if ([p intValue] > 0) {
            NSLog(@"self.selectMutArray==%@",self.selectMutArray);
            Order_ConfirmViewController *cVC = [[Order_ConfirmViewController alloc] init];
            cVC.selectArr = self.selectMutArray;
            [self.navigationController pushViewController:cVC animated:YES];
        }
    }
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"购物车" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
        
        _manaButton = [[UIButton alloc]initWithFrame:CGRectMake(0, kStatusHeight, 50 * kBL, kNavigationBarHeight)];
        [_manaButton setTitle:@"编辑" forState:UIControlStateNormal];
        [_manaButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _manaButton.titleLabel.font = kFONT(15);
        _manaButton.maxX = kScreenWidth - 2 * kBL;
        [_manaButton addTarget:self action:@selector(manaButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [_headView addSubview:_manaButton];
    }
    return _headView;
}
- (UIView *)nilView{
    if (!_nilView) {
        _nilView = [[UIView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - _headView.maxY - kTabBarHeight)];
        _nilView.backgroundColor = kWhiteColor;
    }
    return _nilView;
}
- (UIScrollView *)mScrollView{
    if (!_mScrollView) {
        _mScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, _nilView.height)];
        _mScrollView.backgroundColor = kWhiteColor;
        
        UIImageView *cImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 70 * kBL, kScreenWidth, 70 * kBL)];
        cImgV.image = [UIImage imageNamed:@"cart_icon_nil"];
        cImgV.contentMode = UIViewContentModeCenter;
        [_mScrollView addSubview:cImgV];
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, cImgV.maxY, kScreenWidth, 38 * kBL) text:@"购物车还是空的" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = k153Color;
        [_mScrollView addSubview:label];
        
        UIButton *gBtn = [[UIButton alloc] initWithFrame:CGRectMake(70 * kBL, label.maxY + 10 * kBL, kScreenWidth - 140 * kBL, 34 * kBL)];
        gBtn.backgroundColor = kDefaultColor;
        [gBtn setTitle:@"去逛逛" forState:UIControlStateNormal];
        [gBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        gBtn.titleLabel.font = kFONT(16);
        [gBtn dmo_setCornerRadius:17 * kBL];
        [gBtn addTarget:self action:@selector(gBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_mScrollView addSubview:gBtn];
    }
    return _mScrollView;
}
- (UIView *)fullView{
    if (!_fullView) {
        _fullView = [[UIView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - _headView.maxY - kTabBarHeight)];
        _fullView.backgroundColor = kWhiteColor;
    }
    return _fullView;
}
- (UITableView *)listTableView{
    if (!_listTableView) {
        _listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, _fullView.height - 40 * kBL) style:UITableViewStylePlain];
        _listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listTableView.backgroundColor = kGrayBgColor;
        _listTableView.delegate = self;
        _listTableView.dataSource = self;
        
        UIView *grayView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 10 * kBL)];
        grayView.backgroundColor = kGrayBgColor;
        _listTableView.tableFooterView = grayView;
        
        if (@available(iOS 11.0, *)) {
            _listTableView.estimatedRowHeight = 0;
            _listTableView.estimatedSectionFooterHeight = 0;
            _listTableView.estimatedSectionHeaderHeight = 0;
        }
        
        WS(ws);
        _listTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [ws initData];
        }];
    }
    return _listTableView;
}
- (ShopCartFooterView *)scfooterView{
    if (!_scfooterView) {
        _scfooterView = [[ShopCartFooterView alloc] initWithFrame:CGRectMake(0, _fullView.height - 40 * kBL, kScreenWidth, 40 * kBL)];
        [_scfooterView.submitBtn addTarget:self action:@selector(goStatement) forControlEvents:UIControlEventTouchUpInside];
        [_scfooterView.allSelecteBtn addTarget:self action:@selector(goAllSelect:) forControlEvents:UIControlEventTouchUpInside];
        [_scfooterView.collectBtn addTarget:self action:@selector(collectBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_scfooterView.deleteBtn addTarget:self action:@selector(deleteBtnAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _scfooterView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
