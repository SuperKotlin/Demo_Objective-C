//
//  GoodsDetailsViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/19.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "GoodsDetailsViewController.h"
#import "XQCarousel.h"
#import "DWQSelectView.h"
#import "DWQSelectAttributes.h"
#import "ConfirmViewController.h"

@interface GoodsDetailsViewController ()<UIScrollViewDelegate,WKUIDelegate,XQCarouselDelegate,SelectAttributesDelegate>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIScrollView *mScrollView;
@property (nonatomic,strong) XQCarousel *picCarousel;
@property (nonatomic,strong) UIView *indexView;
@property (nonatomic,strong) UILabel *indexLab;
@property (nonatomic,strong) NSMutableArray *imglistArr;
@property (nonatomic,strong) NSString *allNUm;
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) UILabel *priceLab;
@property (nonatomic,strong) UIView *skuView;
@property (nonatomic,strong) UILabel *skuLab;
@property (nonatomic,strong) UIView *promotionView;
@property (nonatomic,strong) UIView *detailsView;
//底部
@property (nonatomic,strong) UIView *footerView;
@property (nonatomic,strong) UIButton *collBtn;
@property (nonatomic,strong) UIImageView *collImgV;
@property (nonatomic,strong) UILabel *collLab;
@property (nonatomic,strong) WKWebView *contentWeb;
//规格属性选择控件
@property (nonatomic,strong) DWQSelectView *selectView;
@property (nonatomic,strong) DWQSelectAttributes *selectAttributes;

@property (nonatomic,strong) NSDictionary *dataDict;
@property (nonatomic,strong) NSMutableArray *sku_arr;
@property (nonatomic,strong) NSString *inventoryStr; //库存
@property (nonatomic,strong) NSMutableArray *skulist;
@property (nonatomic,strong) NSMutableArray *selectArr;
@property (nonatomic,strong) NSMutableArray *goods_skuArr;
@property (nonatomic,strong) NSString *goods_num;
@property (nonatomic,strong) NSString *postage; //邮费

@end

@implementation GoodsDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
    [self isCollectData];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    //    return UIStatusBarStyleDefault;
    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView.contentOffset.y > kHeaderHeight) {
        [UIView animateWithDuration:2 delay:0.5 options:UIViewAnimationOptionAutoreverse animations:^{
            
        } completion:^(BOOL finished) {
            self.headView.backgroundColor = kDefaultColor;
        }];
    }else{
        [UIView animateWithDuration:2 delay:0.5 options:UIViewAnimationOptionAutoreverse animations:^{
            
        } completion:^(BOOL finished) {
            self.headView.backgroundColor = [UIColor clearColor];
        }];
    }
}
//属性点击
- (void)selectBtnTitle:(NSString *)title tags:(NSInteger)tags btnTag:(NSInteger)btnTag{
    NSArray *value_list = [self.sku_arr[tags] objectForKey:@"value_list"];
    NSString *btnName = [NSString stringWithFormat:@"%@",value_list[btnTag]];
    NSString *attribute_id = [NSString stringWithFormat:@"%@",[self.sku_arr[tags] objectForKey:@"attribute_id"]];
    NSLog(@"btnName=%@,attribute_id=%@",btnName,attribute_id);
    
    NSDictionary *selectDict = @{@"attribute_id":attribute_id,@"value":btnName};
    [self.selectArr replaceObjectAtIndex:tags withObject:selectDict];
    NSLog(@"self.selectArr==%@",self.selectArr);
    
    NSMutableArray *attribute_idArr = [NSMutableArray arrayWithArray:[self.selectArr valueForKey:@"attribute_id"]];
    NSLog(@"attribute_idArr==%@,count==%ld",attribute_idArr,attribute_idArr.count);
    //把attribute_id为空的过滤掉
    for (int i=0; i<attribute_idArr.count; i++) {
        NSString *str = attribute_idArr[i];
        if ([str isEqualToString:@""]) {
            [attribute_idArr removeObjectAtIndex:i];
            i--;
        }
    }
    NSLog(@"attribute_idArr22====%@",attribute_idArr);
    
    //只有属性都选择了，才去匹配图片价格等(匹配的规则是：skulist中是否存在你选择的attribute_id以及value)
    if (attribute_idArr.count == self.sku_arr.count) {
        NSString *asd = [self orderJsonKeys:[self.selectArr valueForKey:@"attribute_id"] andObjects:[self.selectArr valueForKey:@"value"]];
        NSLog(@"asd==%@",asd);
        for (NSDictionary *temp in self.skulist) {
            if ([[NSString stringWithFormat:@"%@",temp[@"sku"]] isEqualToString:asd]) {
                NSLog(@"t==%@",[NSString stringWithFormat:@"%@",temp[@"sku"]]);
                NSLog(@"asd22==%@",asd);
                self.selectView.priceLab.text = [NSString stringWithFormat:@"¥%@",[NSString stringWithFormat:@"%@",[temp objectForKey:@"price"]]];
                self.selectView.inventoryLab.text = [NSString stringWithFormat:@"库存%@",[NSString stringWithFormat:@"%@",[temp objectForKey:@"inventory"]]];
                self.inventoryStr = [NSString stringWithFormat:@"%@",[temp objectForKey:@"inventory"]];
                if ([self isNil:temp[@"img"]]) {
                    [self.selectView.headImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,self.dataDict[@"goodsMsg"][@"img"]]] placeholderImage:[UIImage imageNamed:@"goods_default"]];
                }else{
                    [self.selectView.headImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,[NSString stringWithFormat:@"%@",[temp objectForKey:@"img"]]]] placeholderImage:[UIImage imageNamed:@"goods_default"]];
                }
            }
        }
        
        //展示已选择的属性规格
        NSString *sk = [[self.selectArr valueForKey:@"value"] componentsJoinedByString:[NSString stringWithFormat:@"%@%@",@"'",@"'"]];
        NSLog(@"sk===%@",sk);
        self.selectView.skuLab.text = [NSString stringWithFormat:@"已选%@%@%@",@"'",sk,@"'"];
        self.skuLab.text = [NSString stringWithFormat:@"%@%@%@",@"'",sk,@"'"];
        self.goods_skuArr = [NSMutableArray array];
        [self.goods_skuArr addObjectsFromArray:self.selectArr];
    }
}
/**
 * 按顺序拼接json串
 * keys        key的数组
 * objects     object的数组
 */
- (NSString *)orderJsonKeys:(NSArray *)keys andObjects:(NSArray *)objects{
    NSMutableString *mutableString = [NSMutableString string];
    if (keys.count > 0) {
        for (NSInteger i = 0; i < keys.count; i++) {
            [mutableString appendString:@"{"];
            if (i == keys.count-1) {
                [mutableString appendFormat:@"\"%@\":%@,", @"attribute_id", keys[i]];
                [mutableString appendFormat:@"\"%@\":\"%@\"", @"value", objects[i]];
            } else {
                [mutableString appendFormat:@"\"%@\":%@,", @"attribute_id", keys[i]];
                [mutableString appendFormat:@"\"%@\":\"%@\"", @"value", objects[i]];
            }
            [mutableString appendString:@"},"];
        }
    }
    
    NSString *orderJsonString = [NSString stringWithString:mutableString];
    NSString *temp = [orderJsonString substringToIndex:[orderJsonString length] - 1];
    NSString *result = [NSString stringWithFormat:@"[%@]",temp];
    
    return result;
}
#pragma mark  - KVO回调
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    //更具内容的高重置webView视图的高度
    NSLog(@"Height is changed! new=%@", [change valueForKey:NSKeyValueChangeNewKey]);
    //    NSLog(@"tianxia :%@",NSStringFromCGSize(self.contentWeb.contentSize));
    CGFloat newHeight = self.contentWeb.scrollView.contentSize.height;
    self.contentWeb.height = newHeight;
    self.detailsView.height = self.contentWeb.maxY;
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, self.detailsView.maxY);
}
- (void)didScrollToIndex:(NSInteger)index{
    self.indexLab.text = [NSString stringWithFormat:@"%ld/%@",index + 1,self.allNUm];
}
- (void)dealloc{
    [self.contentWeb.scrollView removeObserver:self forKeyPath:@"contentSize"];
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.mScrollView];
    [self.mScrollView addSubview:self.picCarousel];
    [self.mScrollView addSubview:self.indexView];
    [self.mScrollView addSubview:self.topView];
    [self.mScrollView addSubview:self.promotionView];
    [self.mScrollView addSubview:self.skuView];
    [self.mScrollView addSubview:self.detailsView];
    [self.detailsView addSubview:self.contentWeb];
    
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, kScreenHeight * 3);
    [self.view addSubview:self.footerView];
    [self.view addSubview:self.headView];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    self.imglistArr = [NSMutableArray array];
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"goods_id":self.goods_id
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetGoodsMsgURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            self.dataDict = obj[@"data"];
            NSDictionary *goodsMsg = [[obj objectForKey:@"data"] objectForKey:@"goodsMsg"];
            //轮播图
            NSArray *imglist = [[obj objectForKey:@"data"] objectForKey:@"imglist"];
            [self.imglistArr addObjectsFromArray:imglist];
            NSMutableArray *tempMutArray = [NSMutableArray array];
            for (NSDictionary *bannerDic in self.imglistArr) {
                [tempMutArray addObject:@{@"type":@"1",@"url":[NSString stringWithFormat:@"%@%@",kBaseURL,bannerDic[@"img"]]}];
            }
            
            if (![self isNil:goodsMsg[@"video"]]) {
                [tempMutArray insertObject:@{@"type":@"0",@"url":[NSString stringWithFormat:@"%@%@",kBaseURL,goodsMsg[@"video"]]} atIndex:0];
            }
            self.picCarousel.contentArray = tempMutArray;
            
            self.allNUm = [NSString stringWithFormat:@"%ld",tempMutArray.count];
            self.indexLab.text = [NSString stringWithFormat:@"1/%@",self.allNUm];
            
            self.nameLab.text = [NSString stringWithFormat:@"%@",[goodsMsg objectForKey:@"goods_name"]];
            
            NSString *price = [NSString stringWithFormat:@"%@",goodsMsg[@"price"]];
            self.priceLab.text = [NSString stringWithFormat:@"¥%@",price];
            NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:self.priceLab.text];
            [str addAttribute:NSFontAttributeName value:kFONT(12) range:NSMakeRange(0,1)];
            self.priceLab.attributedText = str;
            
            NSString *dataStr = [NSString stringWithFormat:@"%@",[goodsMsg objectForKey:@"content"]];
            NSString *contents = [NSString stringWithFormat:@"%@%@%@",@"<html><head><meta content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0\" name=\"viewport\"><style type=\"text/css\">img{display: inline-block;max-width: 100%}</style></head><body>",dataStr,@"</body></html>"];
            NSLog(@"contents==%@",contents);
            [self.contentWeb loadHTMLString:contents baseURL:nil];
            
            NSString *collection = [NSString stringWithFormat:@"%@",goodsMsg[@"collection"]];
            if ([collection isEqualToString:@"1"]) {
                self.collImgV.image = [UIImage imageNamed:@"collect_pre"];
                self.collLab.text = @"已收藏";
            }else if ([collection isEqualToString:@"2"]){
                self.collImgV.image = [UIImage imageNamed:@"collect_nor"];
                self.collLab.text = @"收藏";
            }
            //商品sku
            self.sku_arr = [NSMutableArray array];
            if ([[goodsMsg objectForKey:@"sku_arr"] isKindOfClass:[NSArray class]]) {
                NSArray *skuArr = [goodsMsg objectForKey:@"sku_arr"];
                if (skuArr.count > 0) {
                    [self.sku_arr addObjectsFromArray:skuArr];
                }
            }
            self.skulist = [NSMutableArray array];
            if ([[self.dataDict objectForKey:@"skulist"] isKindOfClass:[NSArray class]]) {
                NSArray *skulistArr = [self.dataDict objectForKey:@"skulist"];
                if (skulistArr.count > 0) {
                    [self.skulist addObjectsFromArray:skulistArr];
                }
            }
            [self initSelectArr];
            
            self.inventoryStr = [NSString stringWithFormat:@"%@",goodsMsg[@"inventory"]];
            if ([self isNil:goodsMsg[@"postage"]]) {
                self.postage = @"";
            }else{
                self.postage = [NSString stringWithFormat:@"%@",goodsMsg[@"postage"]];
            }
            
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
//重置选择的数组
- (void)initSelectArr{
    self.goods_num = @"1";
    self.goods_skuArr = [NSMutableArray array];
    self.selectArr = [NSMutableArray array];
    NSArray *titleArr = [self.sku_arr valueForKey:@"attribute_name"];
    for (int i = 0; i < titleArr.count; i ++) {
        [self.selectArr addObject:@{@"attribute_id":@"",@"value":@""}];
    }
}
//是否收藏
- (void)isCollectData{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        self.collImgV.image = [UIImage imageNamed:@"collect_nor"];
        self.collLab.text = @"收藏";
    }else{
        NSDictionary *parameters = @{
                                     kPlatform:kIOS,
                                     kVersion:kBuild,
                                     @"goods_id":self.goods_id,
                                     kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                     };
        [self showLoad];
        [[DmoNetwork dmo_network] dmo_requestWith:kIs_collectURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
            [self hideLoad];
            if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                NSString *is_collect = [[obj objectForKey:@"data"] objectForKey:@"is_collect"];
                if ([is_collect isEqualToString:@"Y"]) {
                    self.collImgV.image = [UIImage imageNamed:@"collect_pre"];
                    self.collLab.text = @"已收藏";
                    self.collBtn.selected = YES;
                }else if ([is_collect isEqualToString:@"N"]){
                    self.collImgV.image = [UIImage imageNamed:@"collect_nor"];
                    self.collLab.text = @"收藏";
                    self.collBtn.selected = NO;
                }
            }else{
                [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            }
        } failure:^(NSString * _Nonnull errMessage) {
            [self hideLoad];
            [self showMessage:kMessage_Network_Failure delay:1.5];
        } requestType:requestTypePost];
    }
}
//收藏
- (void)collectionData{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken),
                                 @"goods_id":self.goods_id
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kCollectURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            self.collImgV.image = [UIImage imageNamed:@"collect_pre"];
            self.collLab.text = @"已收藏";
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
//取消收藏
- (void)cancelCollectionData{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken),
                                 @"goods_id":self.goods_id
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kCancelCollectURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            self.collImgV.image = [UIImage imageNamed:@"collect_nor"];
            self.collLab.text = @"收藏";
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->Action Method
- (void)proBtnAction{
    
}
- (void)skuBtnAction{
    [self initSelectView];
}
- (void)initSelectView{
    [self initSelectArr];
    self.selectView = [[DWQSelectView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    self.selectView.priceLab.text = [NSString stringWithFormat:@"¥%@",self.dataDict[@"goodsMsg"][@"price"]];
    self.selectView.nameLab.text = [NSString stringWithFormat:@"%@",self.dataDict[@"goodsMsg"][@"goods_name"]];;
    self.selectView.inventoryLab.text = [NSString stringWithFormat:@"库存%@",self.dataDict[@"goodsMsg"][@"inventory"]];
    [self.selectView.headImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,self.dataDict[@"goodsMsg"][@"img"]]] placeholderImage:[UIImage imageNamed:@"goods_default"]];
    [self.view addSubview:self.selectView];
    
    if (self.sku_arr.count == 0) {
        self.selectView.numView.minY = 0;
        self.selectView.mainscrollview.contentSize = CGSizeMake(0, self.selectView.numView.maxY);
        self.selectView.skuLab.text = @"";
        self.skuLab.text = self.selectView.skuLab.text;
    }else{
        NSArray *titleArr = [self.sku_arr valueForKey:@"attribute_name"];
        self.selectView.skuLab.text = [NSString stringWithFormat:@"请选择%@",[titleArr componentsJoinedByString:@" "]];
        self.skuLab.text = self.selectView.skuLab.text;
        NSArray *attributesArray = [self.sku_arr valueForKey:@"value_list"];
        CGFloat maxY = 0;
        CGFloat height = 0;
        for (int i = 0; i < self.sku_arr.count; i ++){
            self.selectAttributes = [[DWQSelectAttributes alloc] initWithTitle:titleArr[i] attributesArray:attributesArray[i] andFrame:CGRectMake(0, maxY, kScreenWidth, 40)];
            maxY = CGRectGetMaxY(self.selectAttributes.frame);
            height += self.selectAttributes.height;
            self.selectAttributes.tags = kTagStart + i;
            self.selectAttributes.delegate = self;
            [self.selectView.mainscrollview addSubview:self.selectAttributes];
        }
        NSLog(@"mainscrollview.height===%f",height);
        self.selectView.numView.minY = height + 10 * kBL;
        self.selectView.mainscrollview.contentSize = CGSizeMake(0, self.selectView.numView.maxY + 10 * kBL);
    }
    //取消按钮
    [self.selectView.cancelBtn addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    //加入购物车
    [self.selectView.cartBtn addTarget:self action:@selector(addBtnAction) forControlEvents:UIControlEventTouchUpInside];
    //立即购买
    [self.selectView.buyBtn addTarget:self action:@selector(buyBtnAction) forControlEvents:UIControlEventTouchUpInside];
    //减
    [self.selectView.lessButton addTarget:self action:@selector(lessButtonAction) forControlEvents:UIControlEventTouchUpInside];
    //加
    [self.selectView.addButton addTarget:self action:@selector(addButtonAction) forControlEvents:UIControlEventTouchUpInside];
    //点击黑色透明视图choseView会消失
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismiss)];
    [self.selectView.alphaView addGestureRecognizer:tap];
}
//点击半透明部分或者取消按钮，弹出视图消失
- (void)dismiss{
    [UIView animateWithDuration: 0.35 animations: ^{
        [self.selectView removeFromSuperview];
    } completion: nil];
}
- (void)lessButtonAction{
    int count;
    count = [self.selectView.numTextField.text intValue];
    if (count < 2) {
        [self showMessage:@"已是最小数量" delay:1.5];
    }else{
        count --;
    }
    
    self.selectView.numTextField.text = [NSString stringWithFormat:@"%d",count];
    self.goods_num = self.selectView.numTextField.text;
}
- (void)addButtonAction{
    int count;
    count = [self.selectView.numTextField.text intValue];
    if ([self.selectView.numTextField.text intValue] >= [self.inventoryStr intValue]) {
        [self showMessage:@"库存不足" delay:1.5];
    }else{
        count ++;
    }
    
    self.selectView.numTextField.text = [NSString stringWithFormat:@"%d",count];
    self.goods_num = self.selectView.numTextField.text;
}
- (void)collBtnAction:(UIButton *)sender{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@""];
    }else{
        if (sender.selected) {
            [self cancelCollectionData];
        }else{
            [self collectionData];
        }
        sender.selected = !sender.selected;
    }
}
- (void)carBtnAction{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NOTIFICATION_CHANGE_TABBAR" object:@(3)];
    [self.navigationController popToRootViewControllerAnimated:YES];
}
//加入购物车
- (void)addBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@""];
    }else{
        NSLog(@"self.goods_skuArr==%@",self.goods_skuArr);
        if (self.goods_skuArr.count != self.sku_arr.count) {
            [self showMessage:@"规格搭配不完全，请选择规格" delay:1.5];
        }else{
            NSDictionary *parameters;
            if (self.goods_skuArr.count == 0) {
                parameters = @{
                               kPlatform:kIOS,
                               kVersion:kBuild,
                               kToken:kUserDefaults_OBJECTFORKEY(kToken),
                               @"goods_id":self.goods_id,
                               @"goods_num":self.goods_num
                               };
            }else{
                NSString *asd = [self orderJsonKeys:[self.goods_skuArr valueForKey:@"attribute_id"] andObjects:[self.goods_skuArr valueForKey:@"value"]];
                NSLog(@"asd==%@",asd);
                parameters = @{
                               kPlatform:kIOS,
                               kVersion:kBuild,
                               kToken:kUserDefaults_OBJECTFORKEY(kToken),
                               @"goods_id":self.goods_id,
                               @"goods_num":self.goods_num,
                               @"goods_sku":asd
                               };
            }
            [self showLoad];
            [[DmoNetwork dmo_network] dmo_requestWith:kShopcart_addURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
                [self hideLoad];
                if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                    [self showMessage:@"添加成功，在购物车等亲~" delay:1.5];
                    [self dismiss];
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"ShopCartViewRefresh" object:nil userInfo:nil];
                }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
                    [self toLoginVC:@""];
                }else{
                    [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
                }
            } failure:^(NSString * _Nonnull errMessage) {
                [self hideLoad];
                [self showMessage:kMessage_Network_Failure delay:1.5];
            } requestType:requestTypePost];
            
        }
    }
}
//购买
- (void)buyBtnAction{
    if ([kUserDefaults_OBJECTFORKEY(@"isLogin") isEqualToString:@"N"]) {
        [self toLoginVC:@""];
    }else{
        NSLog(@"self.goods_skuArr==%@",self.goods_skuArr);
        if (self.goods_skuArr.count != self.sku_arr.count) {
            [self showMessage:@"规格搭配不完全，请选择规格" delay:1.5];
        }else{
            ConfirmViewController *conV = [[ConfirmViewController alloc] init];
            conV.goods_id = self.goods_id;
            conV.infoDict = @{
                             @"img":[NSURL URLWithString:[NSString stringWithFormat:@"%@",self.dataDict[@"goodsMsg"][@"img"]]],
                             @"goods_name":[NSString stringWithFormat:@"%@",self.dataDict[@"goodsMsg"][@"goods_name"]],
                             @"sku_str":[[self.goods_skuArr valueForKey:@"value"] componentsJoinedByString:@","],
                             @"price":[NSString stringWithFormat:@"%@",self.dataDict[@"goodsMsg"][@"price"]],
                             @"goods_num":self.goods_num,
                             @"postage":self.postage,
                             @"inventory":self.inventoryStr
                             };
            if (self.goods_skuArr.count == 0) {
                conV.goods_sku = @"";
            }else{
                conV.goods_sku = [self orderJsonKeys:[self.goods_skuArr valueForKey:@"attribute_id"] andObjects:[self.goods_skuArr valueForKey:@"value"]];
            }
            [self.navigationController pushViewController:conV animated:YES];
            [self dismiss];
        }
    }
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = [UIColor clearColor];
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"商品详情" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor whiteColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(6, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"goods_back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
    }
    return _headView;
}
- (UIScrollView *)mScrollView{
    if (!_mScrollView) {
        _mScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight - kFooterHeight - 42 * kBL)];
        _mScrollView.backgroundColor = kGrayBgColor;
        _mScrollView.delegate = self;
        if (@available(iOS 11.0, *)){
            _mScrollView.contentInset = UIEdgeInsetsMake(-kStatusHeight, 0, 0, 0);
        }
    }
    return _mScrollView;
}
- (XQCarousel *)picCarousel{
    if (!_picCarousel) {
        _picCarousel = [XQCarousel scrollViewFrame:CGRectMake(0, 0, kScreenWidth, 320 * kBL) imageStringGroup:nil];
        _picCarousel.delegate = self;
    }
    return _picCarousel;
}
- (UIView *)indexView{
    if (!_indexView) {
        _indexView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 42 * kBL, 22 * kBL)];
        _indexView.backgroundColor = kRGB(242, 244, 245);
        _indexView.maxY = _picCarousel.height - 16 * kBL;
        _indexView.maxX = kScreenWidth;
        
        UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:_indexView.bounds byRoundingCorners:UIRectCornerTopLeft | UIRectCornerBottomLeft   cornerRadii:CGSizeMake(15 * kBL, 15 * kBL)];
        CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
        maskLayer.frame = _indexView.bounds;
        maskLayer.path = maskPath.CGPath;
        _indexView.layer.mask = maskLayer;
        
        _indexLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _indexView.width, _indexView.height)];
        _indexLab.textColor = k153Color;
        _indexLab.font = kFONT(13);
        _indexLab.textAlignment = NSTextAlignmentCenter;
        _indexLab.text = @"0/0";
        [_indexView addSubview:_indexLab];
    }
    return _indexView;
}
- (UIView *)topView{
    if (!_topView) {
        _topView = [[UIView alloc] initWithFrame:CGRectMake(0, _picCarousel.maxY, kScreenWidth, 94 * kBL)];
        _topView.backgroundColor = kWhiteColor;
        
        _nameLab = [[UILabel alloc] initWithFrame:CGRectMake(6, 0, kScreenWidth - 12, 38 * kBL)];
        _nameLab.font = kFONT(15);
        _nameLab.textColor = kBlackColor;
        _nameLab.numberOfLines = 0;
        [_topView addSubview:_nameLab];

        _priceLab = [[UILabel alloc] initWithFrame:CGRectMake(_nameLab.minX, _nameLab.maxY, kScreenWidth / 2.0 + 20, 16 * kBL)];
        _priceLab.font = kFONT(15);
        _priceLab.textColor = kRedColor;
        [_topView addSubview:_priceLab];
    }
    return _topView;
}
- (UIView *)promotionView{
    if (!_promotionView) {
        _promotionView = [[UIView alloc] initWithFrame:CGRectMake(0, _topView.maxY + 10 * kBL, kScreenWidth, 50 * kBL)];
        _promotionView.backgroundColor = kWhiteColor;
        
        UILabel *cxLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 40 * kBL, 26 * kBL)];
        cxLab.text = @"促销";
        cxLab.textColor = kBlackColor;
        cxLab.textAlignment = NSTextAlignmentRight;
        cxLab.font = kFONT_BOLD(15);
        [_promotionView addSubview:cxLab];
        
        UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 5 * kBL, 10 * kBL)];
        rImgV.image = [UIImage imageNamed:@"order_next"];
        rImgV.maxX = kScreenWidth - 12 * kBL;
        [_promotionView addSubview:rImgV];
        rImgV.centerY = _promotionView.height / 2.0;
        
        UIButton *proBtn = [[UIButton alloc] initWithFrame:CGRectMake(cxLab.maxX, 0, kScreenWidth - cxLab.maxX, _promotionView.height)];
        [proBtn addTarget:self action:@selector(proBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_promotionView addSubview:proBtn];
    }
    return _promotionView;
}
- (UIView *)skuView{
    if (!_skuView) {
        _skuView = [[UIView alloc] initWithFrame:CGRectMake(0, _promotionView.maxY + 10 * kBL, kScreenWidth, 50 * kBL)];
        _skuView.backgroundColor = kWhiteColor;
        
        UILabel *cxLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 40 * kBL, _skuView.height)];
        cxLab.text = @"已选";
        cxLab.textColor = kBlackColor;
        cxLab.textAlignment = NSTextAlignmentRight;
        cxLab.font = kFONT_BOLD(15);
        [_skuView addSubview:cxLab];
        
        _skuLab = [[UILabel alloc] initWithFrame:CGRectMake(cxLab.maxX + 6 * kBL, 0, kScreenWidth - cxLab.maxX - 30 * kBL, _skuView.height)];
        _skuLab.font = kFONT(14);
        _skuLab.textColor = k153Color;
        _skuLab.text = @"规格";
        _skuLab.numberOfLines = 0;
        [_skuView addSubview:_skuLab];
        
        UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 5 * kBL, 10 * kBL)];
        rImgV.image = [UIImage imageNamed:@"order_next"];
        rImgV.maxX = kScreenWidth - 12 * kBL;
        [_skuView addSubview:rImgV];
        rImgV.centerY = _skuLab.centerY;
        
        UIButton *skuBtn = [[UIButton alloc] initWithFrame:CGRectMake(cxLab.maxX, 0, kScreenWidth - cxLab.maxX, _skuView.height)];
        [skuBtn addTarget:self action:@selector(skuBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_skuView addSubview:skuBtn];
    }
    return _skuView;
}
- (UIView *)detailsView{
    if (!_detailsView) {
        _detailsView = [[UIView alloc] initWithFrame:CGRectMake(0, _skuView.maxY + 10 * kBL, kScreenWidth, 50 * kBL)];
        _detailsView.backgroundColor = kWhiteColor;
        
        UILabel *cxLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 10 * kBL, kScreenWidth, 40 * kBL)];
        cxLab.text = @"商 / 品 / 详 / 情";
        cxLab.textColor = kBlackColor;
        cxLab.textAlignment = NSTextAlignmentCenter;
        cxLab.font = kFONT_BOLD(20);
        [_detailsView addSubview:cxLab];
        
        NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:cxLab.text];
        [str addAttribute:NSForegroundColorAttributeName value:k153Color range:NSMakeRange(2, 1)];
        [str addAttribute:NSFontAttributeName value:kFONT(12) range:NSMakeRange(2, 1)];
        [str addAttribute:NSForegroundColorAttributeName value:k153Color range:NSMakeRange(6, 1)];
        [str addAttribute:NSFontAttributeName value:kFONT(12) range:NSMakeRange(6, 1)];
        [str addAttribute:NSForegroundColorAttributeName value:k153Color range:NSMakeRange(10, 1)];
        [str addAttribute:NSFontAttributeName value:kFONT(12) range:NSMakeRange(10, 1)];
        cxLab.attributedText = str;
        
        UILabel *fLab = [[UILabel alloc] initWithFrame:CGRectMake(0, cxLab.maxY, kScreenWidth, 10 * kBL)];
        fLab.text = @"COMMDDITY INFORMATION";
        fLab.textColor = k153Color;
        fLab.textAlignment = NSTextAlignmentCenter;
        fLab.font = kFONT(10);
        [_detailsView addSubview:fLab];
    }
    return _detailsView;
}
- (WKWebView *)contentWeb{
    if (!_contentWeb) {
        _contentWeb = [[WKWebView alloc] initWithFrame:CGRectMake(0, 60 * kBL, kScreenWidth, 0)];
        _contentWeb.UIDelegate = self;
        _contentWeb.scrollView.bounces = NO;
        _contentWeb.userInteractionEnabled = NO;
        [_contentWeb.scrollView addObserver:self forKeyPath:@"contentSize"
                                    options:NSKeyValueObservingOptionNew context:nil];
        
        //禁止长按弹出 UIMenuController 相关
        //禁止选择 css 配置相关
        NSString *css = @"body{-webkit-user-select:none;-webkit-user-drag:none;}";
        //css 选中样式取消
        NSMutableString *javascript = [NSMutableString string];
        [javascript appendString:@"var style = document.createElement('style');"];
        [javascript appendString:@"style.type = 'text/css';"];
        [javascript appendFormat:@"var cssContent = document.createTextNode('%@');", css];
        [javascript appendString:@"style.appendChild(cssContent);"];
        [javascript appendString:@"document.body.appendChild(style);"];
        [javascript appendString:@"document.documentElement.style.webkitUserSelect='none';"]; //禁止选择
        [javascript appendString:@"document.documentElement.style.webkitTouchCallout='none';"]; //禁止长按
        //javascript 注入
        WKUserScript *noneSelectScript = [[WKUserScript alloc] initWithSource:javascript injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
        WKUserContentController *userContentController = [[WKUserContentController alloc] init];
        [userContentController addUserScript:noneSelectScript];
        WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
        configuration.userContentController = userContentController;
        //控件加载
        [_contentWeb.configuration.userContentController addUserScript:noneSelectScript];
    }
    return _contentWeb;
}
- (UIView *)footerView{
    if (!_footerView) {
        _footerView = [[UIView alloc] initWithFrame:CGRectMake(0, kScreenHeight - kFooterHeight - 42 * kBL, kScreenWidth, 42 * kBL)];
        _footerView.backgroundColor = kWhiteColor;
        
        _collBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 56 * kBL, _footerView.height)];
        [_collBtn addTarget:self action:@selector(collBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [_footerView addSubview:_collBtn];
        
        _collImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 6 * kBL, 18 * kBL, 16 * kBL)];
        _collImgV.image = [UIImage imageNamed:@"collect_nor"];
        _collImgV.centerX = _collBtn.width / 2.0;
        [_collBtn addSubview:_collImgV];
        
        _collLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _collImgV.maxY, _collBtn.width, 16 * kBL)];
        _collLab.text = @"收藏";
        _collLab.textAlignment = NSTextAlignmentCenter;
        _collLab.font = kFONT(11);
        _collLab.textColor = k153Color;
        [_collBtn addSubview:_collLab];
        
        UIButton *carBtn = [[UIButton alloc] initWithFrame:CGRectMake(_collBtn.maxX, 0, 56 * kBL, _footerView.height)];
        [carBtn addTarget:self action:@selector(carBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_footerView addSubview:carBtn];
        
        UIImageView *carImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 6 * kBL, 18 * kBL, 16 * kBL)];
        carImgV.image = [UIImage imageNamed:@"goods_shopcart"];
        carImgV.centerX = carBtn.width / 2.0;
        [carBtn addSubview:carImgV];
        
        UILabel *carLab = [[UILabel alloc] initWithFrame:CGRectMake(0, carImgV.maxY, carBtn.width, 16 * kBL)];
        carLab.text = @"购物车";
        carLab.textAlignment = NSTextAlignmentCenter;
        carLab.font = kFONT(11);
        carLab.textColor = k153Color;
        [carBtn addSubview:carLab];
        
        CGFloat width = (kScreenWidth - carBtn.maxX - 30 * kBL) / 2.0;
        UIButton *addBtn = [[UIButton alloc] initWithFrame:CGRectMake(carBtn.maxX + 10 * kBL, 0, width, 32 * kBL)];
        [addBtn setBackgroundImage:[UIImage imageNamed:@"goods_shopcart_add"] forState:UIControlStateNormal];
        [addBtn setTitle:@"加入购物车" forState:UIControlStateNormal];
        [addBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        addBtn.titleLabel.font = kFONT(15);
        [addBtn addTarget:self action:@selector(addBtnAction) forControlEvents:UIControlEventTouchUpInside];
        addBtn.centerY = _footerView.height / 2.0;
        [_footerView addSubview:addBtn];
        
        UIButton *buyBtn = [[UIButton alloc] initWithFrame:CGRectMake(addBtn.maxX + 10 * kBL, 0, width, 32 * kBL)];
        [buyBtn setBackgroundImage:[UIImage imageNamed:@"goods_buy"] forState:UIControlStateNormal];
        [buyBtn setTitle:@"立即购买" forState:UIControlStateNormal];
        [buyBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        buyBtn.titleLabel.font = kFONT(15);
        [buyBtn addTarget:self action:@selector(buyBtnAction) forControlEvents:UIControlEventTouchUpInside];
        buyBtn.centerY = addBtn.centerY;
        [_footerView addSubview:buyBtn];
    }
    return _footerView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
