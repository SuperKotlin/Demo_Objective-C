//
//  Home_FunCollectionViewCell.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/6.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Home_FunCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *funcImgView;
@property (nonatomic,strong) UILabel *funcLabel;

@end

NS_ASSUME_NONNULL_END
