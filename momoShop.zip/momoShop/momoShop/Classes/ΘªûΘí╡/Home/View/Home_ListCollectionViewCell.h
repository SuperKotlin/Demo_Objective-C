//
//  Home_ListCollectionViewCell.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/6.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Home_ListCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *picImgV;
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) UILabel *priceLab;
@property (nonatomic,strong) UILabel *countLab;

@end

NS_ASSUME_NONNULL_END
