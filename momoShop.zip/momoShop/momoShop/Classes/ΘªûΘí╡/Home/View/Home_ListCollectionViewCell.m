//
//  Home_ListCollectionViewCell.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/6.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "Home_ListCollectionViewCell.h"

@implementation Home_ListCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.picImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth / 2.0, 158 * kBL)];
        [self.contentView addSubview:self.picImgV];
        
        self.nameLab = [[UILabel alloc] initWithFrame:CGRectMake(0, self.picImgV.maxY, self.picImgV.width, 34 * kBL)];
        self.nameLab.font = kFONT(13);
        self.nameLab.textColor = k153Color;
        self.nameLab.numberOfLines = 0;
        [self.contentView addSubview:self.nameLab];
        
        self.priceLab = [[UILabel alloc] initWithFrame:CGRectMake(0, self.nameLab.maxY, self.picImgV.width / 2.0, 22 * kBL)];
        self.priceLab.font = kFONT(14);
        self.priceLab.textColor = kRedColor;
        [self.contentView addSubview:self.priceLab];
        
        self.countLab = [[UILabel alloc] initWithFrame:CGRectMake(self.priceLab.maxX, self.nameLab.maxY, self.picImgV.width / 2.0, 22 * kBL)];
        self.countLab.font = kFONT(13);
        self.countLab.textColor = k204Color;
        self.countLab.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:self.countLab];
    }
    return self;
}

@end
