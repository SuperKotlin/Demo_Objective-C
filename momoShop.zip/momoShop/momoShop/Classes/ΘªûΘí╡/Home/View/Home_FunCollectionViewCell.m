//
//  Home_FunCollectionViewCell.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/6.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "Home_FunCollectionViewCell.h"

@implementation Home_FunCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        CGFloat width = kScreenWidth / 5;
        
        UIView *mainView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, width, 130 / 2.0 * kBL)];
        [self.contentView addSubview:mainView];
        
        self.funcImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 4 * kBL, 36 * kBL, 36 * kBL)];
        self.funcImgView.centerX = mainView.width / 2.0;
        [mainView addSubview:self.funcImgView];
        
        self.funcLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, self.funcImgView.maxY, width, 20 * kBL)];
        self.funcLabel.font = kFONT(14);
        self.funcLabel.textColor = k153Color;
        self.funcLabel.textAlignment = NSTextAlignmentCenter;
        [mainView addSubview:self.funcLabel];
    }
    return self;
}


@end
