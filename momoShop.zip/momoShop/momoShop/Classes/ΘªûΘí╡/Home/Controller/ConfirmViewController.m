//
//  ConfirmViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/28.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "ConfirmViewController.h"
#import "AddressViewController.h"
#import "Order_BuyViewController.h"

@interface ConfirmViewController ()
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIButton *addressBtn;
@property (nonatomic,strong) UIView *goodsView;
@property (nonatomic,strong) UIView *centerView;
@property (nonatomic,strong) UIView *moneyView;
@property (nonatomic,strong) UIView *footerView;
@property (nonatomic,strong) UITextField *numTextField;
@property (nonatomic,strong) UILabel *fapiaoLab;
@property (nonatomic,strong) UILabel *quanLab;
@property (nonatomic,strong) UILabel *pointLab;
@property (nonatomic,strong) UILabel *moneyLab;
@property (nonatomic,strong) UILabel *postageLab;
@property (nonatomic,strong) UILabel *totalLab;

@end

@implementation ConfirmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self getAddressData];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
//    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.addressBtn];
    [self.view addSubview:self.goodsView];
    [self.view addSubview:self.centerView];
    [self.view addSubview:self.moneyView];
    [self.view addSubview:self.footerView];
    NSString *n = [NSString stringWithFormat:@"%@",self.infoDict[@"goods_num"]];
    [self setPriceTotal:n];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)getAddressData{
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 kToken:kUserDefaults_OBJECTFORKEY(kToken)
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetAddressListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSArray *array = [[obj objectForKey:@"data"] objectForKey:@"list"];
            if (array.count == 0) {
                self.nullView.hidden = NO;
                self.addressIdStr = @"";
            }else{
                self.nullView.hidden = YES;
                for (int i = 0; i < array.count; i++) {
                    NSString *isdefault = [NSString stringWithFormat:@"%@",array[i][@"is_default"]];
                    if ([isdefault isEqualToString:@"Y"]) {
                        self.nameLab.text = [NSString stringWithFormat:@"%@   %@",array[i][@"consignee"],array[i][@"contact_number"]];
                        NSString *pcaStr = [NSString stringWithFormat:@"%@%@%@",array[i][@"province"],array[i][@"city"],array[i][@"county"]];
                        self.addressDetailLab.text = [NSString stringWithFormat:@"%@%@",pcaStr,array[i][@"detail_address"]];
                        self.addressIdStr = [NSString stringWithFormat:@"%@",array[i][@"id"]];
                    }
                }
            }
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->Action Method
- (void)addressBtnAction{
    AddressViewController *addV = [[AddressViewController alloc] init];
    addV.typeStr = @"1";
    [self.navigationController pushViewController:addV animated:YES];
}
- (void)lessButtonAction{
    int count;
    count = [self.numTextField.text intValue];
    if (count < 2) {
        [self showMessage:@"已是最小数量" delay:1.5];
    }else{
        count --;
    }
    
    self.numTextField.text = [NSString stringWithFormat:@"%d",count];
    [self setPriceTotal:self.numTextField.text];
}
- (void)addButtonAction{
    int count;
    count = [self.numTextField.text intValue];
    if ([self.numTextField.text intValue] >= [[NSString stringWithFormat:@"%@",self.infoDict[@"inventory"]] intValue]) {
        [self showMessage:@"库存不足" delay:1.5];
    }else{
        count ++;
    }
    
    self.numTextField.text = [NSString stringWithFormat:@"%d",count];
    [self setPriceTotal:self.numTextField.text];
}
//计算价格
- (void)setPriceTotal:(NSString *)num{
    NSString *p = [NSString stringWithFormat:@"%@",self.infoDict[@"price"]];
    //计算邮费
    NSString *postage = [NSString stringWithFormat:@"%@",self.infoDict[@"postage"]];
    CGFloat ps = [postage floatValue] * [num floatValue];
    _postageLab.text = [NSString stringWithFormat:@"+¥%.2f",ps];
    
    //计算总价
    CGFloat all = [p floatValue] * [num intValue];
    _moneyLab.text = [NSString stringWithFormat:@"¥%.2f",all];
    _totalLab.text = [NSString stringWithFormat:@"¥%.2f",all];
    
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:_totalLab.text];
    [str addAttribute:NSFontAttributeName value:kFONT(12) range:NSMakeRange(0, 1)];
    _totalLab.attributedText = str;
}
- (void)funBtnAction:(UIButton *)sender{
    switch (sender.tag - kTagStart) {
        case 0:
        {
            
        }
            break;
        case 1:
        {
            
        }
            break;
        case 2:
        {
            
        }
            break;
            
        default:
            break;
    }
}
- (void)chargeBtnAction{
//    Order_BuyViewController *byV = [[Order_BuyViewController alloc] init];
//    byV.order_id = @"";
//    byV.allprice = @"1982";
//    [self.navigationController pushViewController:byV animated:YES];
//    return;
    
    NSDictionary *parameters;
    if ([self.goods_sku isEqualToString:@""]) {
        parameters = @{
                       kPlatform:kIOS,
                       kVersion:kBuild,
                       kToken:kUserDefaults_OBJECTFORKEY(kToken),
                       @"goods_id":self.goods_id,
                       @"num":self.numTextField.text,
                       @"deduction_point":@"",
                       @"address_id":self.addressIdStr,
                       @"remark":@""
                       };
    }else{
        parameters = @{
                       kPlatform:kIOS,
                       kVersion:kBuild,
                       kToken:kUserDefaults_OBJECTFORKEY(kToken),
                       @"goods_id":self.goods_id,
                       @"goods_sku":self.goods_sku,
                       @"num":self.numTextField.text,
                       @"deduction_point":@"",
                       @"address_id":self.addressIdStr,
                       @"remark":@""
                       };
    }
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kOrder_buyURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            Order_BuyViewController *byV = [[Order_BuyViewController alloc] init];
            byV.order_id = [NSString stringWithFormat:@"%@",[obj[@"data"] objectForKey:@"order_id"]];
            byV.allprice = [NSString stringWithFormat:@"%@",[obj[@"data"] objectForKey:@"allprice"]];
            [self.navigationController pushViewController:byV animated:YES];
        }else if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"105"]){
            [self toLoginVC:@""];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UILabel *label = [UILabel dmo_labelWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth - 35 * 2, kNavigationBarHeight) text:@"提交订单" textAlignment:NSTextAlignmentCenter font:kFONT(17)];
        label.centerX = kScreenWidth / 2.0;
        label.textColor = [UIColor blackColor];
        [_headView addSubview:label];
        
        UIButton *backButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, kStatusHeight, 35, kNavigationBarHeight) type:UIButtonTypeCustom title:nil titleColor:nil imageName:@"back" action:@selector(backViewController) target:self];
        [_headView addSubview:backButton];
        
        UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, _headView.height - 1, kScreenWidth, 1) backgroundColor:kGrayBgColor];
        [_headView addSubview:lineView];
    }
    return _headView;
}
- (UIButton *)addressBtn{
    if (!_addressBtn) {
        _addressBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, 90 * kBL)];
        _addressBtn.backgroundColor = [UIColor whiteColor];
        [_addressBtn addTarget:self action:@selector(addressBtnAction) forControlEvents:UIControlEventTouchUpInside];
        
        UIImageView *addImgV = [[UIImageView alloc] initWithFrame:CGRectMake(12 * kBL, 0, 18 * kBL, 18 * kBL)];
        addImgV.image = [UIImage imageNamed:@"address_icon"];
        addImgV.centerY = _addressBtn.height / 2.0;
        [_addressBtn addSubview:addImgV];
        
        UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 5 * kBL, 7 * kBL)];
        rImgV.image = [UIImage imageNamed:@"right"];
        rImgV.centerY = _addressBtn.height / 2.0;
        [_addressBtn addSubview:rImgV];
        rImgV.maxX = kScreenWidth - 12 * kBL;
        
        _fullView = [[UIView alloc] initWithFrame:CGRectMake(addImgV.maxX, 0, kScreenWidth - addImgV.maxX - 12 * kBL, 90 * kBL)];
        [_addressBtn addSubview:_fullView];
        _fullView.userInteractionEnabled = NO;
        
        _addressDetailLab = [[UILabel alloc] initWithFrame:CGRectMake(8 * kBL, 8 * kBL, _fullView.width - 16 * kBL, 44 * kBL)];
        _addressDetailLab.textColor = [UIColor blackColor];
        _addressDetailLab.font = kFONT_BOLD(15);
        _addressDetailLab.numberOfLines = 0;
        [_fullView addSubview:_addressDetailLab];
        
        _nameLab = [[UILabel alloc] initWithFrame:CGRectMake(_addressDetailLab.minX, _addressDetailLab.maxY, _addressDetailLab.width, 22 * kBL)];
        _nameLab.textColor = k153Color;
        _nameLab.font = kFONT(13);
        [_fullView addSubview:_nameLab];
        
        _nullView = [[UIView alloc] initWithFrame:CGRectMake(addImgV.maxX, 0, kScreenWidth - addImgV.maxX - 12 * kBL, 90 * kBL)];
        [_addressBtn addSubview:_nullView];
        _nullView.userInteractionEnabled = NO;
        _nullView.hidden = YES;
        
        UILabel *nilAddressLabel = [[UILabel alloc] initWithFrame:CGRectMake(6 * kBL, 0, kScreenWidth, 16 * kBL)];
        nilAddressLabel.font = kFONT(13);
        nilAddressLabel.text = @"您还没有添加收货地址，去添加";
        [_nullView addSubview:nilAddressLabel];
        nilAddressLabel.centerY = _nullView.height / 2.0;
    }
    return _addressBtn;
}
- (UIView *)goodsView{
    if (!_goodsView) {
        _goodsView = [[UIView alloc] initWithFrame:CGRectMake(0, _addressBtn.maxY + 6 * kBL, kScreenWidth, 110 * kBL)];
        _goodsView.backgroundColor = [UIColor whiteColor];
        
        UIImageView *picImgView = [[UIImageView alloc] initWithFrame:CGRectMake(12 * kBL, 0, 78 * kBL, 78 * kBL)];
        picImgView.centerY = _goodsView.height / 2.0;
        [_goodsView addSubview:picImgView];
        
        UILabel *nameLab = [[UILabel alloc] initWithFrame:CGRectMake(picImgView.maxX + 6 * kBL, picImgView.minY, kScreenWidth - picImgView.maxX - 18 * kBL, 34 * kBL)];
        nameLab.font = kFONT(14);
        nameLab.numberOfLines = 0;
        nameLab.textColor = k51Color;
        [_goodsView addSubview:nameLab];
        
        UILabel *skuLab = [[UILabel alloc] initWithFrame:CGRectMake(nameLab.minX, nameLab.maxY, nameLab.width, 20 * kBL)];
        skuLab.font = kFONT(12);
        skuLab.textColor = k153Color;
        [_goodsView addSubview:skuLab];
        
        UILabel *priceLab = [[UILabel alloc] initWithFrame:CGRectMake(nameLab.minX, skuLab.maxY, nameLab.width - 74 * kBL, 22 * kBL)];
        priceLab.font = kFONT(16);
        priceLab.textColor = kDefaultColor;
        [_goodsView addSubview:priceLab];
        
        UIView *numView = [[UIView alloc] initWithFrame:CGRectMake(priceLab.maxX, 0, 74 * kBL, 22 * kBL)];
        numView.centerY = priceLab.centerY;
        [_goodsView addSubview:numView];
        
        UIButton *lessButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 20 * kBL, 20 * kBL)];
        [lessButton setImage:[UIImage imageNamed:@"cart_less"] forState:UIControlStateNormal];
        lessButton.centerY = numView.height / 2.0;
        [lessButton addTarget:self action:@selector(lessButtonAction) forControlEvents:UIControlEventTouchUpInside];
        [numView addSubview:lessButton];
        
        _numTextField = [[UITextField alloc] initWithFrame:CGRectMake(lessButton.maxX, 0, 34 * kBL, lessButton.height)];
        _numTextField.font = kFONT(13);
        _numTextField.textAlignment = NSTextAlignmentCenter;
        _numTextField.backgroundColor = k244Color;
        _numTextField.userInteractionEnabled = NO;
        [numView addSubview:_numTextField];
        _numTextField.centerY = lessButton.centerY;
        
        UIButton *addButton = [[UIButton alloc] initWithFrame:CGRectMake(_numTextField.maxX, 0, lessButton.width, lessButton.height)];
        [addButton setImage:[UIImage imageNamed:@"cart_add"] forState:UIControlStateNormal];
        addButton.centerY = lessButton.centerY;
        [addButton addTarget:self action:@selector(addButtonAction) forControlEvents:UIControlEventTouchUpInside];
        [numView addSubview:addButton];
        
        [picImgView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,self.infoDict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
        nameLab.text = [NSString stringWithFormat:@"%@",self.infoDict[@"goods_name"]];
        skuLab.text = [NSString stringWithFormat:@"%@",self.infoDict[@"sku_str"]];
        priceLab.text = [NSString stringWithFormat:@"¥%@",self.infoDict[@"price"]];
        _numTextField.text = [NSString stringWithFormat:@"%@",self.infoDict[@"goods_num"]];
    }
    return _goodsView;
}
- (UIView *)centerView{
    if (!_centerView) {
        _centerView = [[UIView alloc] initWithFrame:CGRectMake(0, _goodsView.maxY + 6 * kBL, kScreenWidth, 96 * kBL)];
        _centerView.backgroundColor = [UIColor whiteColor];
        
        NSArray *tArr = @[@"发票",@"优惠券",@"积分"];
        for (int i = 0; i < 3; i ++) {
            UIButton *funBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 12 * kBL + 24 * kBL * i, kScreenWidth, 24 * kBL)];
            funBtn.tag = kTagStart + i;
            [funBtn addTarget:self action:@selector(funBtnAction:) forControlEvents:UIControlEventTouchUpInside];
            [_centerView addSubview:funBtn];
            
            UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 0, 110 * kBL, funBtn.height)];
            leftLabel.font = kFONT(14);
            leftLabel.text = tArr[i];
            leftLabel.textColor = k51Color;
            [funBtn addSubview:leftLabel];
            
            UIImageView *rImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 5 * kBL, 7 * kBL)];
            rImgV.image = [UIImage imageNamed:@"right"];
            rImgV.maxX = kScreenWidth - 10 * kBL;
            rImgV.centerY = leftLabel.centerY;
            [funBtn addSubview:rImgV];
        }
        
        _fapiaoLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 12 * kBL, 120 * kBL, 24 * kBL)];
        _fapiaoLab.font = kFONT(14);
        _fapiaoLab.text = @"个人";
        _fapiaoLab.textColor = k51Color;
        _fapiaoLab.maxX = kScreenWidth - 20 * kBL;
        _fapiaoLab.textAlignment = NSTextAlignmentRight;
        [_centerView addSubview:_fapiaoLab];
        
        _quanLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _fapiaoLab.maxY, 120 * kBL, 24 * kBL)];
        _quanLab.font = kFONT(14);
        _quanLab.text = @"无可用";
        _quanLab.textColor = k51Color;
        _quanLab.maxX = kScreenWidth - 20 * kBL;
        _quanLab.textAlignment = NSTextAlignmentRight;
        [_centerView addSubview:_quanLab];
        
        _pointLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _quanLab.maxY, 120 * kBL, 24 * kBL)];
        _pointLab.font = kFONT(14);
        _pointLab.text = @"无可用";
        _pointLab.textColor = k51Color;
        _pointLab.maxX = kScreenWidth - 20 * kBL;
        _pointLab.textAlignment = NSTextAlignmentRight;
        [_centerView addSubview:_pointLab];
    }
    return _centerView;
}
- (UIView *)moneyView{
    if (!_moneyView) {
        _moneyView = [[UIView alloc] initWithFrame:CGRectMake(0, _centerView.maxY + 6 * kBL, kScreenWidth, 24 * kBL + 24 * kBL * 2)];
        _moneyView.backgroundColor = [UIColor whiteColor];
        
        NSArray *tArr = @[@"商品金额",@"运费"];
        for (int i = 0; i < 2; i ++) {
            UIButton *funBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 12 * kBL + 24 * kBL * i, kScreenWidth, 24 * kBL)];
            funBtn.tag = kTagStart + i;
            [_moneyView addSubview:funBtn];
            
            UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kBL, 0, 110 * kBL, funBtn.height)];
            leftLabel.font = kFONT(14);
            leftLabel.text = tArr[i];
            leftLabel.textColor = k51Color;
            [funBtn addSubview:leftLabel];
        }
        _moneyLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 12 * kBL,kScreenWidth - 130 * kBL, 24 * kBL)];
        _moneyLab.font = kFONT(14);
        _moneyLab.textColor = k51Color;
        _moneyLab.maxX = kScreenWidth - 10 * kBL;
        _moneyLab.textAlignment = NSTextAlignmentRight;
        [_moneyView addSubview:_moneyLab];
        
        _postageLab = [[UILabel alloc] initWithFrame:CGRectMake(0, _moneyLab.maxY,kScreenWidth - 130 * kBL, 24 * kBL)];
        _postageLab.font = kFONT(14);
        _postageLab.textColor = k51Color;
        _postageLab.maxX = kScreenWidth - 10 * kBL;
        _postageLab.textAlignment = NSTextAlignmentRight;
        [_moneyView addSubview:_postageLab];
    }
    return _moneyView;
}
- (UIView *)footerView{
    if (!_footerView) {
        _footerView = [[UIView alloc] initWithFrame:CGRectMake(0, kScreenHeight - 44 * kBL - kFooterHeight, kScreenWidth, 44 * kBL)];
        _footerView.backgroundColor = [UIColor whiteColor];
        
        _totalLab = [[UILabel alloc] initWithFrame:CGRectMake(12 * kBL, 0, kScreenWidth - 120 * kBL, _footerView.height)];
        _totalLab.font = kFONT(17);
        _totalLab.textColor = kDefaultColor;
        [_footerView addSubview:_totalLab];
        
        UIButton *ruleBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 98 * kBL, 34 * kBL)];
        [ruleBtn setTitle:@"立即支付" forState:UIControlStateNormal];
        [ruleBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        ruleBtn.titleLabel.font = kFONT(15);
        ruleBtn.backgroundColor = kDefaultColor;
        [ruleBtn dmo_setCornerRadius:17 * kBL];
        [ruleBtn addTarget:self action:@selector(chargeBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_footerView addSubview:ruleBtn];
        ruleBtn.centerY = _footerView.height / 2.0;
        ruleBtn.maxX = kScreenWidth - 10 * kBL;
    }
    return _footerView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
