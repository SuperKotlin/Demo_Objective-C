//
//  HomeViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/5.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "HomeViewController.h"
#import "SDCycleScrollView.h"
#import "Home_FunCollectionViewCell.h"
#import "Home_ListCollectionViewCell.h"
#import "GoodsDetailsViewController.h" //商品详情

@interface HomeViewController ()<SDCycleScrollViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIScrollView *mScrollView;
//banner
@property (nonatomic,strong) SDCycleScrollView *picScrollView;
@property (nonatomic,strong) NSMutableArray *bannerMutArr;
//功能
@property (nonatomic,strong) UIView *funcView;
@property (nonatomic,strong) UICollectionView *funCollectionView;
@property (nonatomic,strong) NSMutableArray *funMutArr;
//列表
@property (nonatomic,strong) UIView *liView;
@property (nonatomic,strong) UICollectionView *listCollectionView;
@property (nonatomic,strong) NSMutableArray *listMutArr;
@property (nonatomic,assign) BOOL isRefresh;/**< 刷新还是加载*/
@property (nonatomic,assign) NSInteger pageNum;/**< 页数*/

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    //    return UIStatusBarStyleDefault;
    return UIStatusBarStyleLightContent;
}
#pragma mark ->delegate/ dataSource Method
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    
}
#pragma mark - collectionview代理方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (collectionView == self.funCollectionView) {
        return self.funMutArr.count;
    }
    return self.listMutArr.count;
}
#pragma mark - cell显示的内容
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (collectionView == self.funCollectionView) {
        Home_FunCollectionViewCell *cell = (Home_FunCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
        if (cell == nil) {
            
        }
        
        NSDictionary *dataDict = self.funMutArr[indexPath.row];
        cell.funcLabel.text = [NSString stringWithFormat:@"%@",dataDict[@"cat_name"]];
        [cell.funcImgView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,dataDict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
        
        return cell;
    }
    
    Home_ListCollectionViewCell *cell = (Home_ListCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    if (cell == nil) {
        
    }
    
    NSDictionary *dataDict = self.listMutArr[indexPath.row];
    [cell.picImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,dataDict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
    cell.nameLab.text = [NSString stringWithFormat:@"%@",dataDict[@"goods_name"]];
    cell.priceLab.text = [NSString stringWithFormat:@"¥%@",dataDict[@"price"]];
    cell.countLab.text = [NSString stringWithFormat:@"%@人已买",dataDict[@"sales_volume"]];
    
    return cell;
}
#pragma mark - cell选择点击
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (collectionView == self.funCollectionView) {
//        NSDictionary *dataDict = self.funMutArr[indexPath.row];
        
    }else{
        NSDictionary *dataDict = self.listMutArr[indexPath.row];
        GoodsDetailsViewController *dV = [[GoodsDetailsViewController alloc] init];
        dV.goods_id = [NSString stringWithFormat:@"%@",dataDict[@"goods_id"]];
        [self.navigationController pushViewController:dV animated:YES];
    }
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.mScrollView];
    [self.mScrollView addSubview:self.picScrollView];
    [self.mScrollView addSubview:self.funcView];
    [self.mScrollView addSubview:self.liView];
    [self.mScrollView addSubview:self.listCollectionView];
    self.mScrollView.contentSize = CGSizeMake(kScreenWidth, kScreenHeight - kHeaderHeight - kTabBarHeight);
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    [self getBannerData];
    [self getParentCatListData];
    [self loadNewData];
}
- (void)getBannerData{
    self.bannerMutArr = [NSMutableArray array];
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"cat_id":@"4"
                                 };
    NSLog(@"%@",parameters);
//    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetBannerListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
//        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self.bannerMutArr addObjectsFromArray:[[obj objectForKey:@"data"] objectForKey:@"list"]];
            NSMutableArray *tempMutArray = [NSMutableArray array];
            for (NSDictionary *bannerDic in self.bannerMutArr) {
                [tempMutArray addObject:[NSString stringWithFormat:@"%@%@",kBaseURL,bannerDic[@"img"]]];
            }
            self.picScrollView.imageURLStringsGroup = tempMutArray;
        }else{
            //            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]]];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
- (void)getParentCatListData{
//    [self showLoad];
    self.funMutArr = [NSMutableArray array];
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild
                                 };
    [[DmoNetwork dmo_network] dmo_requestWith:kGetParentCatListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
//        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSArray *arr = [[obj objectForKey:@"data"] objectForKey:@"list"];
            if (arr.count > 10) {
                [self.funMutArr addObjectsFromArray:[arr subarrayWithRange:NSMakeRange(0, 10)]];
            }else{
                [self.funMutArr addObjectsFromArray:arr];
            }
            [self.funCollectionView reloadData];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
// 刷新
- (void)loadNewData {
    self.isRefresh = YES;
    [self requestData];
}
// 加载更多
- (void)loadMoreData {
    self.isRefresh = NO;
    [self requestData];
}
- (void)requestData{
    WS(ws);
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[kPlatform] = kIOS;
    parameters[kVersion] = kBuild;
    parameters[@"cat_id"] = @""; //商品分类ID
    parameters[@"goods_name"] = @""; //商品名称
    parameters[@"price1"] = @""; //价格区间搜索-起始价格
    parameters[@"price2"] = @""; //价格区间搜索-截止价格
    parameters[@"is_top"] = @""; //是否推荐/置顶 Y是 N否
    parameters[@"is_sale"] = @""; //是否特价 Y是 N否
    parameters[@"per"] = @"20";
    parameters[@"orderby"] = @""; //排序方式 synthesize按综合排序（默认） sales按销量排序  price1按价格从低到高排序  price2按价格从高到低排序  new按上架时间排序
    if (self.isRefresh) {
        self.pageNum = 1;
        parameters[@"p"] = [NSString stringWithFormat:@"%ld",(long)self.pageNum];
        self.listMutArr = [NSMutableArray array];
        [ws showLoad];
        [[DmoNetwork dmo_network] dmo_requestWith:kGetGoodsListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
            [ws hideLoad];
            if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                NSArray *arr = [[obj objectForKey:@"data"] objectForKey:@"list"];
                if (arr.count == 0) {
                    [self showMessage:kMessage_NoMoreData delay:1.5];
                }else{
                    [self.listMutArr addObjectsFromArray:arr];
                }
                [self.listCollectionView reloadData];
                
                if (self.listMutArr.count % 2 == 0) {
                    self.listCollectionView.height = self.listMutArr.count / 2 * 226 * kBL;
                }else{
                    self.listCollectionView.height = (self.listMutArr.count / 2 + 1) * 226 * kBL;
                }
                self.mScrollView.contentSize = CGSizeMake(kScreenWidth, self.listCollectionView.maxY);
            }else{
                [ws showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            }
            [ws.mScrollView.mj_header endRefreshing];
        } failure:^(NSString * _Nonnull errMessage) {
            [ws hideLoad];
            [ws showMessage:kMessage_Network_Failure delay:1.5];
            [ws.mScrollView.mj_header endRefreshing];
        } requestType:requestTypePost];
    }else{
        self.pageNum ++;
        parameters[@"p"] = [NSString stringWithFormat:@"%ld",(long)self.pageNum];
        [ws showLoad];
        [[DmoNetwork dmo_network] dmo_requestWith:kGetGoodsListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
            [ws hideLoad];
            if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
                NSArray *arr = [[obj objectForKey:@"data"] objectForKey:@"list"];
                if (arr.count == 0) {
                    [self showMessage:kMessage_NoMoreData delay:1.5];
                }else{
                    [self.listMutArr addObjectsFromArray:arr];
                }
                [self.listCollectionView reloadData];
                if (self.listMutArr.count % 2 == 0) {
                    self.listCollectionView.height = self.listMutArr.count / 2 * 226 * kBL;
                }else{
                    self.listCollectionView.height = (self.listMutArr.count / 2 + 1) * 226 * kBL;
                }
                self.mScrollView.contentSize = CGSizeMake(kScreenWidth, self.listCollectionView.maxY);
            }else{
                [ws showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
            }
            [ws.mScrollView.mj_footer endRefreshing];
        } failure:^(NSString * _Nonnull errMessage) {
            [ws hideLoad];
            [ws showMessage:kMessage_Network_Failure delay:1.5];
            [ws.mScrollView.mj_footer endRefreshing];
        } requestType:requestTypePost];
    }
}
#pragma mark ->Action Method
//搜索
- (void)searchBtnAction{
    
}
- (void)leftBtnAction{
    
}
- (void)rightBtnAction{
    
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kDefaultColor;
        
        UIButton *leftBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 36 * kBL, kNavigationBarHeight)];
        [leftBtn setImage:[UIImage imageNamed:@"home_saoyisao"] forState:UIControlStateNormal];
        [leftBtn addTarget:self action:@selector(leftBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_headView addSubview:leftBtn];
        
        UIButton *searchBtn = [[UIButton alloc] initWithFrame:CGRectMake(leftBtn.maxX, kStatusHeight + 5 * kBL, kScreenWidth - leftBtn.maxX * 2, kNavigationBarHeight - 10 * kBL)];
        searchBtn.backgroundColor = kRGB(253,119,120);
        [searchBtn dmo_setCornerRadius:(kNavigationBarHeight - 10 * kBL) / 2.0];
        [searchBtn addTarget:self action:@selector(searchBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [_headView addSubview:searchBtn];
        
        UIImageView *sImgV = [[UIImageView alloc] initWithFrame:CGRectMake(8 * kBL, 0, 13 * kBL, 13 * kBL)];
        sImgV.image = [UIImage imageNamed:@"home_search"];
        sImgV.centerY = searchBtn.height / 2.0;
        [searchBtn addSubview:sImgV];
        
        UILabel *sLab = [UILabel dmo_labelWithFrame:CGRectMake(sImgV.maxX + 4 * kBL, 0, searchBtn.width - sImgV.maxX, searchBtn.height) text:@"请输入您想要搜索的内容" textAlignment:NSTextAlignmentLeft font:kFONT(14)];
        sLab.textColor = kWhiteColor;
        [searchBtn addSubview:sLab];
        
        UIButton *rightBtn = [[UIButton alloc] initWithFrame:CGRectMake(searchBtn.maxX, 0, 36 * kBL, kNavigationBarHeight)];
        [rightBtn setImage:[UIImage imageNamed:@"home_message"] forState:UIControlStateNormal];
        [_headView addSubview:rightBtn];
        [rightBtn addTarget:self action:@selector(rightBtnAction) forControlEvents:UIControlEventTouchUpInside];
        
        leftBtn.centerY = searchBtn.centerY;
        rightBtn.centerY = searchBtn.centerY;
    }
    return _headView;
}
- (UIScrollView *)mScrollView{
    if (!_mScrollView) {
        _mScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, _headView.maxY, kScreenWidth, kScreenHeight - _headView.maxY - kTabBarHeight)];
        _mScrollView.backgroundColor = kWhiteColor;
        
        WS(ws);
        _mScrollView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [ws loadNewData];
        }];
        
        MJRefreshAutoNormalFooter *footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
        // 禁止自动加载
        footer.automaticallyRefresh = NO;
        // 设置footer
        _mScrollView.mj_footer = footer;
    }
    return _mScrollView;
}
- (SDCycleScrollView *)picScrollView{
    if (_picScrollView == nil) {
        _picScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, kScreenWidth, 144 * kBL) imageNamesGroup:nil];
        _picScrollView.delegate = self;
        _picScrollView.bannerImageViewContentMode = UIViewContentModeScaleAspectFill;
        _picScrollView.autoScrollTimeInterval = 4.0;
        _picScrollView.pageControlBottomOffset = 4.0;
        _picScrollView.currentPageDotColor = kRedColor;
        _picScrollView.backgroundColor = kWhiteColor;
        _picScrollView.placeholderImage = [UIImage imageNamed:@""];
    }
    return _picScrollView;
}
- (UIView *)funcView{
    if (!_funcView) {
        _funcView = [[UIView alloc] initWithFrame:CGRectMake(0, _picScrollView.maxY - 6 * kBL, kScreenWidth, 140 * kBL)];
        _funcView.backgroundColor = [UIColor whiteColor];
        
        UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:_funcView.bounds byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(10, 10)];
        CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
        maskLayer.frame = _funcView.bounds;
        maskLayer.path = maskPath.CGPath;
        _funcView.layer.mask = maskLayer;
        
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 0;
        layout.itemSize = CGSizeMake(kScreenWidth / 5, (_funcView.height - 10 * kBL) / 2.0);
        
        _funCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 10 * kBL, kScreenWidth, _funcView.height - 10 * kBL) collectionViewLayout:layout];
        _funCollectionView.backgroundColor = [UIColor whiteColor];
        _funCollectionView.dataSource = self;
        _funCollectionView.delegate = self;
        _funCollectionView.scrollEnabled = NO;
        _funCollectionView.showsVerticalScrollIndicator = NO;
        [_funCollectionView registerClass:[Home_FunCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
        [_funcView addSubview:_funCollectionView];
    }
    return _funcView;
}
- (UIView *)liView{
    if (!_liView) {
        _liView = [[UIView alloc] initWithFrame:CGRectMake(0, _funcView.maxY, kScreenWidth, 30 * kBL)];
        _liView.backgroundColor = [UIColor whiteColor];
        
        UILabel *sLab = [UILabel dmo_labelWithFrame:CGRectMake(4 * kBL, 0, kScreenWidth, _liView.height) text:@"|精品推荐" textAlignment:NSTextAlignmentLeft font:kFONT(14)];
        sLab.textColor = kRedColor;
        [_liView addSubview:sLab];
    }
    return _liView;
}
- (UICollectionView *)listCollectionView{
    if (!_listCollectionView) {
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 0;
        layout.itemSize = CGSizeMake((kScreenWidth - 3) / 2, 226 * kBL);
        
        _listCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, _liView.maxY, kScreenWidth, 0) collectionViewLayout:layout];
        _listCollectionView.backgroundColor = [UIColor whiteColor];
        _listCollectionView.dataSource = self;
        _listCollectionView.delegate = self;
        _listCollectionView.scrollEnabled = NO;
        _listCollectionView.showsVerticalScrollIndicator = NO;
        [_listCollectionView registerClass:[Home_ListCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    }
    return _listCollectionView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
