//
//  ConfirmViewController.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/6/28.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ConfirmViewController : UIViewController
@property (nonatomic,copy) NSString *goods_id;
@property (nonatomic,strong) NSDictionary *infoDict;
@property (nonatomic,strong) NSString *goods_sku;

@property (nonatomic,strong) UIView *fullView;
@property (nonatomic,strong) UIView *nullView;
@property (nonatomic,strong) UILabel *addressDetailLab;
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) NSString *addressIdStr;

@end

NS_ASSUME_NONNULL_END
