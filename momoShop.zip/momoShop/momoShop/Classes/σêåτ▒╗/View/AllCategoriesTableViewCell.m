//
//  AllCategoriesTableViewCell.m
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/4/8.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "AllCategoriesTableViewCell.h"

@implementation AllCategoriesTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.redView = [[UIImageView alloc] initWithFrame:CGRectMake(3, 0, 3, 10 * kBL)];
        self.redView.backgroundColor = kRGB(230,1,19);
        [self.contentView addSubview:self.redView];
        
        self.titleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 70 * kBL, 36 * kBL)];
        self.titleLab.font = kFONT(14);
        self.titleLab.textColor = kRGBA(44,44,44,1);
        self.titleLab.textAlignment = NSTextAlignmentCenter;
        self.titleLab.numberOfLines = 0;
        [self.contentView addSubview:self.titleLab];
        self.redView.centerY = self.titleLab.centerY;
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, self.titleLab.maxY, self.redView.width, 1)];
        lineView.backgroundColor = kGrayBgColor;
        [self.contentView addSubview:lineView];
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
