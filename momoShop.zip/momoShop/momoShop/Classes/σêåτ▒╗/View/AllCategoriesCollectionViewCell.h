//
//  AllCategoriesCollectionViewCell.h
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/4/8.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AllCategoriesCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *picImgV;
@property (nonatomic,strong) UILabel *titleLab;

@end

NS_ASSUME_NONNULL_END
