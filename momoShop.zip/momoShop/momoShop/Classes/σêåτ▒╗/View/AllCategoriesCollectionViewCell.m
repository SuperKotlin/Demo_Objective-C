//
//  AllCategoriesCollectionViewCell.m
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/4/8.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "AllCategoriesCollectionViewCell.h"

@implementation AllCategoriesCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        UIView *mainView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
        mainView.backgroundColor = kGrayBgColor;
        [self.contentView addSubview:mainView];
        
        self.picImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, mainView.width - 16, 62 * kBL)];
        self.picImgV.centerX = mainView.width / 2.0;
        [self.picImgV dmo_setCornerRadius:3.f];
        [mainView addSubview:self.picImgV];
        
        self.titleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, self.picImgV.maxY, mainView.width, 22 * kBL)];
        self.titleLab.font = kFONT(14);
        self.titleLab.textAlignment = NSTextAlignmentCenter;
        [mainView addSubview:self.titleLab];
    }
    return self;
}

@end
