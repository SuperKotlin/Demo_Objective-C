//
//  MallViewController.m
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/5.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "CategoryViewController.h"
#import "AllCategoriesTableViewCell.h"
#import "AllCategoriesCollectionViewCell.h"

@interface CategoryViewController ()<UITableViewDataSource,UITableViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UITableView *listTableView;
@property (nonatomic,strong) NSMutableArray *listMutArr;
@property (nonatomic,assign) NSInteger selectIndex;
@property (nonatomic,strong) UICollectionView *listCollectionView;
@property (nonatomic,strong) NSMutableArray *listCollMutArr;
@property (nonatomic,strong) UILabel *tLab;
@property (nonatomic,strong) NSString *pid;

@end

@implementation CategoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    self.selectIndex = 0;
    [self initData];
}
#pragma mark ->System Method
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
#pragma mark ->delegate/ dataSource Method
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.listMutArr.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 37 * kBL;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    AllCategoriesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[AllCategoriesTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (self.selectIndex == indexPath.row) {
        cell.redView.hidden = NO;
        cell.backgroundColor = kGrayBgColor;
        cell.titleLab.textColor = kRedColor;
    }else{
        cell.redView.hidden = YES;
        cell.backgroundColor = [UIColor whiteColor];
        cell.titleLab.textColor = kRGB(102,102,102);
    }
    
    NSDictionary *dataDict = self.listMutArr[indexPath.row];
    cell.titleLab.text = [NSString stringWithFormat:@"%@",dataDict[@"cat_name"]];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dataDict = self.listMutArr[indexPath.row];
    self.selectIndex = indexPath.row;
    [self.listTableView reloadData];
    self.tLab.text = [NSString stringWithFormat:@"%@",dataDict[@"cat_name"]];
    
    self.pid = [NSString stringWithFormat:@"%@",[self.listMutArr[indexPath.row] objectForKey:@"cat_id"]];
    [self getSubData:self.pid];
}
#pragma mark - collectionview代理方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.listCollMutArr.count;
}
#pragma mark - cell显示的内容
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    AllCategoriesCollectionViewCell *cell = (AllCategoriesCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    if (cell == nil) {
        
    }
    NSDictionary *dataDict = self.listCollMutArr[indexPath.row];
    cell.titleLab.text = [NSString stringWithFormat:@"%@",dataDict[@"cat_name"]];
    [cell.picImgV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,dataDict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
    
    return cell;
}
#pragma mark - cell选择点击
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
//    NSDictionary *dataDict = self.listCollMutArr[indexPath.row];
//    NSString *cat_id = [NSString stringWithFormat:@"%@",dataDict[@"cat_id"]];
}
#pragma mark ->Super Method
#pragma mark ->Public Method
- (void)initUI{
    self.view.backgroundColor = kGrayBgColor;
    self.navigationController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    [self.view addSubview:self.listTableView];
    [self.view addSubview:self.tLab];
    [self.view addSubview:self.listCollectionView];
}
- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark ->Private Method
- (void)initData{
    self.listMutArr = [NSMutableArray array];
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetParentCatListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSArray *arr = [[obj objectForKey:@"data"] objectForKey:@"list"];
            [self.listMutArr addObjectsFromArray:arr];
            [self.listTableView reloadData];
            
            if (self.listMutArr.count > 0) {
                NSDictionary *dataDict = self.listMutArr[0];
                self.tLab.text = [NSString stringWithFormat:@"%@",dataDict[@"cat_name"]];
                self.pid = [NSString stringWithFormat:@"%@",[self.listMutArr[0] objectForKey:@"cat_id"]];
                [self getSubData:self.pid];
            }
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
- (void)getSubData:(NSString *)pid{
    self.listCollMutArr = [NSMutableArray array];
    NSDictionary *parameters = @{
                                 kPlatform:kIOS,
                                 kVersion:kBuild,
                                 @"pid":pid
                                 };
    [self showLoad];
    [[DmoNetwork dmo_network] dmo_requestWith:kGetSubCatListURL parameters:parameters success:^(NSDictionary * _Nonnull obj) {
        [self hideLoad];
        if ([[NSString stringWithFormat:@"%@",[obj objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSArray *arr = [[obj objectForKey:@"data"] objectForKey:@"list"];
            [self.listCollMutArr addObjectsFromArray:arr];
            [self.listCollectionView reloadData];
        }else{
            [self showMessage:[NSString stringWithFormat:@"%@",obj[kMessage]] delay:1.5];
        }
    } failure:^(NSString * _Nonnull errMessage) {
        [self hideLoad];
        [self showMessage:kMessage_Network_Failure delay:1.5];
    } requestType:requestTypePost];
}
#pragma mark ->Action Method
- (void)sBtnAction{
    
}
#pragma mark ->setter/getter Method
- (UIView *)headView{
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kHeaderHeight)];
        _headView.backgroundColor = kWhiteColor;
        
        UIView *nView = [[UIView alloc] initWithFrame:CGRectMake(0, kStatusHeight, kScreenWidth, kNavigationBarHeight)];
        [_headView addSubview:nView];
        
        UIButton *sBtn = [[UIButton alloc] initWithFrame:CGRectMake(14 * kBL, 0, kScreenWidth - 28 * kBL, 26 * kBL)];
        sBtn.backgroundColor = kGrayBgColor;
        [sBtn dmo_setCornerRadius:8.f];
        [sBtn setTitle:@"  小龙虾" forState:UIControlStateNormal];
        [sBtn setTitleColor:k153Color forState:UIControlStateNormal];
        sBtn.titleLabel.font = kFONT(14);
        [sBtn setImage:[UIImage imageNamed:@"fenlei_search"] forState:UIControlStateNormal];
        [sBtn addTarget:self action:@selector(sBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [nView addSubview:sBtn];
        sBtn.centerY = nView.height / 2.0;
    }
    return _headView;
}
- (UITableView *)listTableView{
    if (!_listTableView) {
        _listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, _headView.maxY, 70 * kScreenWidth / 320, kScreenHeight - _headView.maxY - kTabBarHeight) style:UITableViewStylePlain];
        _listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _listTableView.backgroundColor = kWhiteColor;
        _listTableView.delegate = self;
        _listTableView.dataSource = self;
        _listTableView.bounces = NO;
        _listTableView.showsVerticalScrollIndicator = NO;
    }
    return _listTableView;
}
- (UILabel *)tLab{
    if (!_tLab) {
        _tLab = [[UILabel alloc] initWithFrame:CGRectMake(_listTableView.maxX + 6 * kBL, _headView.maxY, kScreenWidth - _listTableView.maxX, 28 * kBL)];
        _tLab.font = kFONT(14);
        _tLab.textColor = k51Color;
    }
    return _tLab;
}
- (UICollectionView *)listCollectionView{
    if (_listCollectionView == nil) {
        CGFloat width = kScreenWidth - _listTableView.maxX;
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 0;
        layout.itemSize = CGSizeMake(width / 3, 88 * kScreenWidth / 320);
        _listCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(_listTableView.maxX, _tLab.maxY, kScreenWidth - _listTableView.maxX, _listTableView.height - _tLab.height) collectionViewLayout:layout];
        _listCollectionView.backgroundColor = kGrayBgColor;
        _listCollectionView.dataSource = self;
        _listCollectionView.delegate = self;
        _listCollectionView.showsVerticalScrollIndicator = NO;
        [_listCollectionView registerClass:[AllCategoriesCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    }
    return _listCollectionView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
