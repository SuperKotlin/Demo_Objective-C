//
//  UIImage+Common.h
//
//  Created by dmo on 15/6/30.
//  Copyright (c) 2015年 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Dmo_Common)

/**
 *    @brief 颜色
 */
+ (UIImage *)dmo_imageWithColor:(UIColor *)color;

/**
 *    @brief 颜色，大小
 */
+ (UIImage *)dmo_imageWithColor:(UIColor *)color andSize:(CGSize)size;

/**
 *    @brief 大小
 */
+ (UIImage *)dmo_scaleToSize:(UIImage *)img size:(CGSize)size;

/**
 *    @brief 旋转
 */
+ (UIImage*)dmo_imageFromImage:(UIImage*)image inRect:(CGRect)rect transform:(CGAffineTransform)transform;


@end
