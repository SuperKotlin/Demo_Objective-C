//
//  NSObject+NSDate_Common.h
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/4/10.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (NSDate_Common)
- (NSString *)dmo_getWeek:(NSString *)time;

@end

NS_ASSUME_NONNULL_END
