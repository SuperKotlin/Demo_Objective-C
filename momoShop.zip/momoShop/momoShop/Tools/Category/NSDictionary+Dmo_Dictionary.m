//
//  NSDictionary+Dmo_Dictionary.m
//  normal
//
//  Created by dmooo on 2019/2/13.
//  Copyright © 2019年 dm. All rights reserved.
//

#import "NSDictionary+Dmo_Dictionary.h"

@implementation NSDictionary (Dmo_Dictionary)
#pragma mark - 返回字典的数量
- (NSInteger)dmo_dictionaryNumber:(NSDictionary *)dictionary{
    NSInteger number = 0;
    for (NSString *str in [dictionary allValues]) {
        NSLog(@"%@",str);
        number++;
    }
    return number;
}


@end
