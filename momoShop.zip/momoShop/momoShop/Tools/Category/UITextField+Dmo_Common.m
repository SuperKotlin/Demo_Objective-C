//
//  UITextField+Dmo_Common.m
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/4/3.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "UITextField+Dmo_Common.h"

@implementation UITextField (Dmo_Common)
- (void)dmo_setTextFieldLeftPadding:(UITextField *)textField forWidth:(CGFloat)leftWidth{
    CGRect frame = textField.frame;
    frame.size.width = leftWidth;
    UIView *leftview = [[UIView alloc] initWithFrame:frame];
    textField.leftViewMode = UITextFieldViewModeAlways;
    textField.leftView = leftview;
}

@end
