//
//  NSObject+Common.h
//  pd384-ios
//
//  Created by dmo on 16/6/4.
//  Copyright © 2016年 dmo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Dmo_Common)

#pragma mark - NSArray或NSDictionary转成JSON各式
- (NSString *)ToJsonString;

#pragma mark - 判断字典的一个key值是否为nil
- (BOOL)dictionaryKeyNilJudge:(id)dicData;

- (BOOL)dictionaryKeyNil:(id)dicData;

#pragma mark - 返回字典的数量
- (NSInteger)dictionaryNumber:(NSDictionary *)dictionary;

#pragma mark - 判断有几位小数
-(int)numberOfDecimalPlaces:(double)num;

#pragma mark - 根据小数点位数返回String
- (NSString *)stringOfDecimalPoint:(double)number;

@end
