 //
//  UIViewController+Common.m
//
//  Created by dmo on 15/5/13.
//  Copyright (c) 2015年 dmo. All rights reserved.
//
//
//  自定义返回按钮
//  自定义标题颜色
//  集成了HUD（弹框提示）
//

#import "UIViewController+Dmo_Common.h"
#import <objc/runtime.h>
#import "AppDelegate.h"

/* This key is used to dynamically create an instance variable
 * within the MBProgressHUD category using objc_setAssociatedObject
 */

@interface UIViewController ()

@end


@implementation UIViewController (Common)

- (void)showMessage:(NSString *)message withView:(UIView *)view delay:(NSTimeInterval)delay
{
    UIView *showview =  [[UIView alloc]init];
    showview.backgroundColor = kRGBA(0, 0, 0, 0.8);
    showview.frame = CGRectZero;
    
    showview.alpha = 1.0f;
    showview.layer.cornerRadius = 5.0f;
    showview.layer.masksToBounds = YES;
    [view addSubview:showview];
    
    UILabel *label = [[UILabel alloc]init];
    //CGSize labelSize = [message sizeWithFont:[UIFont systemFontOfSize:17] constrainedToSize:CGSizeMake(290, 9000)];
    NSDictionary *attribute = @{NSFontAttributeName : [UIFont systemFontOfSize:15]};
    CGSize labelSize = [message boundingRectWithSize:CGSizeMake(290, 9000) options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin attributes:attribute context:nil].size;
    label.frame = CGRectMake(10, 5, labelSize.width, labelSize.height);
    label.text = message;
    label.numberOfLines = 0;
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:15];
    [showview addSubview:label];
    //提示框的位置
    showview.frame = CGRectMake(0, 0, labelSize.width+21*2, labelSize.height+21*1.3);
    showview.center =CGPointMake(kScreenWidth/2, kScreenHeight/2 + 100);
    label.center = CGPointMake(showview.frame.size.width/2, showview.frame.size.height/2);
    
    [UIView animateWithDuration:0.5 delay:delay options:UIViewAnimationOptionCurveEaseInOut animations:^{
        showview.alpha = 0;
        
    } completion:^(BOOL finished) {
        [showview removeFromSuperview];
        
    }];
}

- (void)showMessage:(NSString *)message delay:(NSTimeInterval)delay{
    UIWindow * window = [UIApplication sharedApplication].keyWindow;
    [self showMessage:message withView:window delay:delay];
}

//
- (void)timeFire:(UIButton *)sender
{
    __block int timeout = 59; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    dispatch_source_set_event_handler(_timer, ^{
        if(timeout<=0){ //倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                [sender setTitle:@"获取验证码" forState:UIControlStateNormal];
                sender.enabled = YES;
            });
        }else{
            int seconds = timeout % 60;
            NSString *strTime = [NSString stringWithFormat:@"%.2d", seconds];
            dispatch_async(dispatch_get_main_queue(), ^{
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationDuration:1];
                [sender setTitle:[NSString stringWithFormat:@"重新发送(%@)",strTime] forState:UIControlStateNormal];
                sender.titleLabel.font = kFONT(13);
                [UIView commitAnimations];
                sender.enabled = NO;
            });
            timeout--;
        }
    });
    dispatch_resume(_timer);
}
- (void)showLoad{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
}
- (void)hideLoad{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}
#pragma mark - 实现多图片上传
- (void)startMultiPartUploadTaskWithURL:(NSString *)url
                           imagesArray:(NSArray *)images
                     parameterOfimages:(NSString *)parameter
                        parametersDict:(NSDictionary *)parameters
                      compressionRatio:(float)ratio
                          succeedBlock:(void (^)(NSDictionary *dict))succeedBlock
                           failedBlock:(void (^)(NSError *error))failedBlock{
    if (images.count == 0) {
        NSLog(@"图片数组计数为零");
        return;
    }
    for (int i = 0; i < images.count; i++) {
        if (![images[i] isKindOfClass:[UIImage class]]) {
            NSLog(@"images中第%d个元素不是UIImage对象",i+1);
        }
    }
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/html", @"text/plain", @"text/javascript", nil];
    [manager POST:url parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        int i = 0;
        //根据当前系统时间生成图片名称
        NSDate *date = [NSDate date];
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"yyyy年MM月dd日"];
        NSString *dateString = [formatter stringFromDate:date];
        
        for (UIImage *image in images) {
            NSString *fileName = [NSString stringWithFormat:@"%@%d.png",dateString,i];
            NSData *imageData;
            if (ratio > 0.0f && ratio < 1.0f) {
                imageData = UIImageJPEGRepresentation(image, ratio);
            }else{
                imageData = UIImageJPEGRepresentation(image, 1.0f);
            }
            [formData appendPartWithFileData:imageData name:parameter fileName:fileName mimeType:@"image/jpg/png/jpeg"];
        }
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        succeedBlock(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (error) {
            failedBlock(error);
            
            NSLog(@"%@",error);
        }
    }];
}
- (BOOL)isNil:(id)key{
    if (key == nil || [key isKindOfClass:[NSNull class]] || [[NSString stringWithFormat:@"%@",key] isEqualToString:@""] || [[NSString stringWithFormat:@"%@",key] isEqualToString:@"null"] || [[NSString stringWithFormat:@"%@",key] isEqualToString:@"<null>"]) {
        return YES;
    }else{
        return NO;
    }
}
- (void)toLoginVC:(NSString *)vc{
    LoginViewController *loginVC = [[LoginViewController alloc] init];
    loginVC.refreshVC = vc;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:loginVC];
    [self.navigationController presentViewController:nav animated:YES completion:nil];
}

@end
