//
//  NSArray+Dmo_Array.h
//  normal
//
//  Created by dmooo on 2019/2/13.
//  Copyright © 2019年 dm. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSArray (Dmo_Array)
/**
 * 字符串以某种规律转化为数组
* @param string 需要转换的字符串
 * @param c 分隔符
 */
- (NSArray *)dmo_String:(NSString*)string ToStringWith:(NSString*)c;

@end

NS_ASSUME_NONNULL_END
