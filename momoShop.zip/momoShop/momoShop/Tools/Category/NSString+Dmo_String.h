//
//  NSString+Dmo_String.h
//  normal
//
//  Created by dmooo on 2019/2/13.
//  Copyright © 2019年 dm. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Dmo_String)

/**
 *判断字符串是否以某个字符串开头
 *@param string 需要判断的字符串
 */
- (BOOL)dmo_isBeginString:(NSString *)string;

/**
 *判断字符串是否以某个字符串结尾
 *@param string 需要判断的字符串
 */
- (BOOL)dmo_isEndString:(NSString *)string;

/**
 *新字符串替换老字符串
 *@param oldString 需要被替换的字符串
 *@param newString 替换上去的字符串
 */
- (NSString *)dmo_replacelOld:(NSString *)oldString withNew:(NSString *)newString;

/**
 *去掉字符串中的空格
 */
- (NSString *)dmo_removeWhiteSpacesFromString;

/**
 * NSArray或NSDictionary转成JSON格式
 */
- (NSString *)dmo_ToJsonString;

/**
 * 数组以某种规律转化为字符串
 * @param array 需要转换的数组
 * @param string 分隔符
 */
- (NSString *)dmo_Array:(NSArray*)array ToString:(NSString *)string;

/**
 * 手机号验证
 */
- (BOOL)dmo_isValidateMobile:(NSString *)mobile;

/**
 * 正则匹配邮箱
 */
- (BOOL)dmo_isValidEmail;

/**
 * 正则匹配银行卡
 */
+ (BOOL)dmo_validateCardNumber:(NSString *)cardNumber;

/**
 * 正则匹配身份证
 */
+ (BOOL)dmo_validateIdentityCard:(NSString *)identityCard;

/**
 * 正则匹配用户名
 */
+ (BOOL)dmo_validateUserName:(NSString *)name;

/**
 * 正则匹配姓名
 */
+ (BOOL)dmo_validateName:(NSString *)name;

/**
 * 正则匹配车牌号码
 */
+ (BOOL)dmo_validateCarNo:(NSString*)carNo;

/**
 * 判断整形
 */
+ (BOOL)dmo_validateInt:(NSString *)string;

/**
 * 判断为空
 */
+ (BOOL)dmo_isBlankString:(NSString *)string;

/**
 * 判断为空
 */
+ (NSString *)dmo_timestampToString:(NSString *)timeStampString;

/**
 * 计算文字高度，可以处理计算带行间距的
 */
- (CGSize)boundingRectWithSize:(CGSize)size font:(UIFont*)font lineSpacing:(CGFloat)lineSpacing;


@end

NS_ASSUME_NONNULL_END
