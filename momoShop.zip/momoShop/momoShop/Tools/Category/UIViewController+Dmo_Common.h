//
//  UIViewController+Common.h
//
//  Created by dmo on 15/5/13.
//  Copyright (c) 2015年 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MBProgressHUD/MBProgressHUD.h>

@interface UIViewController (Common)
#pragma mark -- 缓用按钮
- (void)timeFire:(UIButton *)button;
- (void)showMessage:(NSString *)message delay:(NSTimeInterval)delay;
//显示加载
- (void)showLoad;
- (void)hideLoad;
#pragma mark - 实现多图片上传
- (void)startMultiPartUploadTaskWithURL:(NSString *)url
                           imagesArray:(NSArray *)images
                     parameterOfimages:(NSString *)parameter
                        parametersDict:(NSDictionary *)parameters
                      compressionRatio:(float)ratio
                          succeedBlock:(void (^)(NSDictionary *dict))succeedBlock
                           failedBlock:(void (^)(NSError *))failedBlock;
//判断字段是不是不存在，为null，为"<null>"
- (BOOL)isNil:(id)key;
- (void)toLoginVC:(NSString *)vc;

@end
