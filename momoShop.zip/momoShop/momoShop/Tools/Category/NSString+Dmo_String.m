//
//  NSString+Dmo_String.m
//  normal
//
//  Created by dmooo on 2019/2/13.
//  Copyright © 2019年 dm. All rights reserved.
//

#import "NSString+Dmo_String.h"

@implementation NSString (Dmo_String)
#pragma mark - 判断字符串是否以某个字符串开头
- (BOOL)dmo_isBeginString:(NSString *)string {
    return ([self hasPrefix:string]) ? YES : NO;
}
#pragma mark - 判断字符串是否以某个字符串结尾
- (BOOL)dmo_isEndString:(NSString *)string {
    return ([self hasSuffix:string]) ? YES : NO;
}
#pragma mark - 新字符串替换老字符串
- (NSString *)dmo_replacelOld:(NSString *)oldString withNew:(NSString *)newString {
    return [self stringByReplacingOccurrencesOfString:oldString withString:newString];
}
#pragma mark - 去掉字符串中的空格
- (NSString *)dmo_removeWhiteSpacesFromString {
    NSString *trimmedString = [self stringByTrimmingCharactersInSet:
                               [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return trimmedString;
}

#pragma mark - NSArray或NSDictionary转成JSON格式
- (NSString *)dmo_ToJsonString {
    NSString *jsonString = @"{}";
    
    if ( [self isKindOfClass:[NSArray class]]
        || [self isKindOfClass:[NSMutableArray class]]
        || [self isKindOfClass:[NSDictionary class]]
        || [self isKindOfClass:[NSMutableDictionary class]]) {
        
        NSError *error;
        //        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self
        //                                                           options:(NSJSONWritingOptions)    (false ? NSJSONWritingPrettyPrinted : 0)
        //                                                             error:&error];
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self
                                                           options:0
                                                             error:&error];
        if (jsonData){
            jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        }
    }
    return jsonString;
}
#pragma mark - 数组以某种规律转化为字符串
- (NSString *)dmo_Array:(NSArray*)array ToString:(NSString *)string{
    NSString *str = [array componentsJoinedByString:[NSString stringWithFormat:@"%@",string]];
    return str;
}
#pragma mark - 手机号验证
- (BOOL)dmo_isValidateMobile:(NSString *)mobile{
    NSString *phoneRegex = @"^[1][3-8]\\d{9}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
    BOOL res1 = [regextestmobile evaluateWithObject:mobile];
    if (res1){
        return YES;
    }else{
        return NO;
    }
}
#pragma mark - 邮箱验证
- (BOOL)dmo_isValidEmail {
    NSString *regex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTestPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [emailTestPredicate evaluateWithObject:self];
}
#pragma mark - 银行卡
+ (BOOL)dmo_validateCardNumber:(NSString *)cardNumber{
    if ([cardNumber isEqual:@""]) {
        return 0;
    }else
    {
        NSString *digitsOnly = @"";
        char c;
        for (int i = 0; i < cardNumber.length; i++)
            
        {
            c = [cardNumber characterAtIndex:i];
            if (isdigit(c))
            {
                digitsOnly =[digitsOnly stringByAppendingFormat:@"%c",c];
            }
        }
        int sum = 0;
        int digit = 0;
        int addend = 0;
        BOOL timesTwo = false;
        for (long i = digitsOnly.length - 1; i >= 0; i--)
        {
            digit = [digitsOnly characterAtIndex:i] - '0';
            if (timesTwo)
            {
                addend = digit * 2;
                if (addend > 9) {
                    addend -= 9;
                }
            }
            else {
                addend = digit;
            }
            sum += addend;
            timesTwo = !timesTwo;
        }
        int modulus = sum % 10;
        return modulus == 0;
    }
}
#pragma mark - 身份证
+ (BOOL)dmo_validateIdentityCard:(NSString *)identityCard{
    BOOL flag;
    if (identityCard.length <= 0) {
        flag = NO;
        return flag;
    }
    NSString *regex2 = @"^(\\d{14}|\\d{17})(\\d|[xX])$";
    NSPredicate *identityCardPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex2];
    return [identityCardPredicate evaluateWithObject:identityCard];
}
#pragma mark - 用户名
+ (BOOL)dmo_validateUserName:(NSString *)name{
    if (![name isEqualToString:@""]) {
        return 1;
    }
    return 0;
    //    NSString *      regex = @"^[a-zA-Z][a-zA-Z0-9]{5,7}$";
    //    NSPredicate *   pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    //
    //    return [pred evaluateWithObject:name];
}
#pragma mark - 验证姓名
+ (BOOL)dmo_validateName:(NSString *)name{
    if (![name isEqualToString:@""]) {
        NSString *      regex = @"(^[\u4E00-\u9FA5]*$)";
        NSPredicate *   pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
        
        return [pred evaluateWithObject:name];
    }
    return 0;
}
#pragma mark - 车牌号码
+ (BOOL)dmo_validateCarNo:(NSString*)carNo{
    NSString *carRegex = @"^[\u4e00-\u9fa5]{1}[A-Z]{1}[A-Z_0-9]{5}$";
    NSPredicate *carTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",carRegex];
    NSLog(@"carTest is %@",carTest);
    return [carTest evaluateWithObject:carNo];
}
#pragma mark - 整形判断
+ (BOOL)dmo_validateInt:(NSString *)string{
    NSScanner* scan = [NSScanner scannerWithString:string];
    int val;
    return [scan scanInt:&val] && [scan isAtEnd];
}
#pragma mark - 判断字符串为空
+ (BOOL)dmo_isBlankString:(NSString *)string {
    if (string == nil || string == NULL) {
        return YES;
    }
    if ([string isKindOfClass:[NSNull class]]) {
        return YES;
    }
    //    if ([[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0) {
    //        return YES;
    //    }
    return NO;
}
//
+ (NSString *)dmo_timestampToString:(NSString *)timeStampString{
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:[timeStampString doubleValue]];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *string = [dateFormat stringFromDate:confromTimesp];
    return string;
}

/**
 * 计算文字高度，可以处理计算带行间距的
 */
- (CGSize)boundingRectWithSize:(CGSize)size font:(UIFont*)font lineSpacing:(CGFloat)lineSpacing{
    NSMutableAttributedString *attributeString = [[NSMutableAttributedString alloc] initWithString:self];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = lineSpacing;
    [attributeString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, self.length)];
    [attributeString addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, self.length)];
    NSStringDrawingOptions options = NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading;
    CGRect rect = [attributeString boundingRectWithSize:size options:options context:nil];
    
    //    NSLog(@"size:%@", NSStringFromCGSize(rect.size));
    
    //文本的高度减去字体高度小于等于行间距，判断为当前只有1行
    if ((rect.size.height - font.lineHeight) <= paragraphStyle.lineSpacing) {
        if ([self containChinese:self]) {  //如果包含中文
            rect = CGRectMake(rect.origin.x, rect.origin.y, rect.size.width, rect.size.height-paragraphStyle.lineSpacing);
        }
    }
    
    return rect.size;
}

//判断如果包含中文
- (BOOL)containChinese:(NSString *)str {
    for(int i=0; i< [str length];i++){ int a = [str characterAtIndex:i];
        if( a > 0x4e00 && a < 0x9fff){
            return YES;
        }
    }
    return NO;
}
/**
 *  计算最大行数文字高度,可以处理计算带行间距的
 */
- (CGFloat)boundingRectWithSize:(CGSize)size font:(UIFont*)font lineSpacing:(CGFloat)lineSpacing maxLines:(NSInteger)maxLines{
    
    if (maxLines <= 0) {
        return 0;
    }
    
    CGFloat maxHeight = font.lineHeight * maxLines + lineSpacing * (maxLines - 1);
    
    CGSize orginalSize = [self boundingRectWithSize:size font:font lineSpacing:lineSpacing];
    
    if ( orginalSize.height >= maxHeight ) {
        return maxHeight;
    }else{
        return orginalSize.height;
    }
}

/**
 *  计算是否超过一行   用于给Label 赋值attribute text的时候 超过一行设置lineSpace
 */
- (BOOL)isMoreThanOneLineWithSize:(CGSize)size font:(UIFont *)font lineSpaceing:(CGFloat)lineSpacing{
    
    if ( [self boundingRectWithSize:size font:font lineSpacing:lineSpacing].height > font.lineHeight  ) {
        return YES;
    }else{
        return NO;
    }
}


@end
