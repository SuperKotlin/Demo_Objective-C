//
//  UIImageView+Common.h
//  zhonghuaxun-chuanzhu-ios
//
//  Created by dmo on 16/3/17.
//  Copyright © 2016年 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (Dmo_Common)

/**
 *    @brief 获取类对象
 */
+ (UIImageView *)dmo_imageViewWithFrame:(CGRect)frame imageName:(NSString *)imageName;

@end
