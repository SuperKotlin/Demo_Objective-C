//
//  NSArray+Dmo_Array.m
//  normal
//
//  Created by dmooo on 2019/2/13.
//  Copyright © 2019年 dm. All rights reserved.
//

#import "NSArray+Dmo_Array.h"

@implementation NSArray (Dmo_Array)
#pragma mark - 字符串以某种规律转化为数组
- (NSArray *)dmo_String:(NSString*)string ToStringWith:(NSString*)c {
    NSArray  *array = [string componentsSeparatedByString:[NSString stringWithFormat:@"%@",c]];
    return array;
}
@end
