//
//  UIView+Common.h
//
//  Created by dmo on 15/6/23.
//  Copyright (c) 2015年 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Dmo_Common)

/**
 *	@brief	方向结构体
 *
 */
typedef NS_ENUM(NSInteger, Direction) {
    DirectionLeft,
    DirectionRight,
    DirectionBottom,
    DirectionTop
};

#pragma mark - Corner radius
/**
 *	@brief 设置不同方位的圆角
 */
- (void)dmo_roundCorners:(UIRectCorner)corners radius:(CGFloat)radius;

/**
 *	@brief 设置上边（左上和右上）方位的圆角
 *
 */
- (void)dmo_roundTopCornersRadius:(CGFloat)radius;

/**
 *	@brief 设置下边（左下和右下）方位的圆角
 */
- (void)dmo_roundBottomCornersRadius:(CGFloat)radius;

/**
 *	@brief 设置4个拐角的圆角
 */
- (void)dmo_setCornerRadius:(CGFloat)size;

/**
 *	@brief 设置圆角 默认宽度为UIView高度的一半
 */
- (void)dmo_setCornerRadiusHalfHeight;

/**
 *   @brief 获取类对象
 */
+ (UIView *)dmo_viewWithFrame:(CGRect)frame backgroundColor:(UIColor *)backgroundColor;

#pragma mark - Border
/**
 *	@brief 设置边框
 */
- (void)dmo_setBorder:(CGFloat)width color:(UIColor *)color;

#pragma mark - Shadow
/**
 *	@brief 设置设置阴影
 */
- (void)dmo_setShadow:(CGSize)offset radius:(CGFloat)radius color:(UIColor *)color opacity:(CGFloat)opacity;

/**
 *   @brief 给View设置渐变色
 */
- (void)dmo_setCAGradientLayerForView:(UIView *)view cornerRadius:(CGFloat)cornerRadius;

/**
 *   @brief 给view画分割线
 */
- (void)dmo_addSeparatorLine:(Direction)direction withBorderWidth:(CGFloat)borderWidth withBackgroundColor:(UIColor *)backgroundColor;

@end
