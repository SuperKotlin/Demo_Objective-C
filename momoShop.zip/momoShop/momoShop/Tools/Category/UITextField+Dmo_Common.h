//
//  UITextField+Dmo_Common.h
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/4/3.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITextField (Dmo_Common)
/** 文本输入框离左边有距离
 *    @brief leftWidth 距离
 */
- (void)dmo_setTextFieldLeftPadding:(UITextField *)textField forWidth:(CGFloat)leftWidth;

@end

NS_ASSUME_NONNULL_END
