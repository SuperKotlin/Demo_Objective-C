//
//  NSDictionary+Dmo_Dictionary.h
//  normal
//
//  Created by dmooo on 2019/2/13.
//  Copyright © 2019年 dm. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (Dmo_Dictionary)

/**
 *    @brief 返回字典的数量
 */
- (NSInteger)dmo_dictionaryNumber:(NSDictionary *)dictionary;




@end

NS_ASSUME_NONNULL_END
