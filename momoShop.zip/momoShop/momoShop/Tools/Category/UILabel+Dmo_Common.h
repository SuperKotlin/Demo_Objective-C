//
//  UILabel+Common.h
//
//  Created by dmo on 15/8/5.
//  Copyright (c) 2015年 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Dmo_Common)

- (CGSize)contentSizeForWidth:(CGFloat)width;
- (CGSize)contentSize;
- (BOOL)isTruncated;

/**
 *	@brief 设置label属性
 *
 */
- (void)dmo_setAttributeWithText:(NSString *)text withFont:(UIFont *)font withTextColor:(UIColor *)textColor withBackgroudColor:(UIColor *)backgroundColor;

/**
 *	@brief  设置行间距
 */
- (void)dmo_setLineSpacing:(CGFloat)lineSpacing;

/**
 *	@brief 设置不同label中在不同区间的字体颜色
 */
- (void)dmo_rangeTextStringColor:(UIColor *)color range:(NSRange)range;

/**
 *	@brief 设置不同label中在不同区间的字体大小
 */
- (void)dmo_rangeTextStringFont:(UIFont *)font range:(NSRange)range;

/**
 *	@brief 设置不同label中在不同区间的字体大小和颜色
 */
- (void)dmo_rangeTextAttributeWithColor:(UIColor *)color withFont:(UIFont *)font range:(NSRange)range;

/**
 *    @brief 获取label文字的宽度
 */
+ (CGFloat )dmo_getLabelWidthByText:(NSString *)text font:(UIFont *)font;

/**
 *    @brief 获取label文字的高度
 */
+ (CGFloat)dmo_getLabelHeightByWidth:(CGFloat)width text:(NSString *)text font:(UIFont *)font;

/**
 *    @brief 获取类对象
 */
+ (UILabel *)dmo_labelWithFrame:(CGRect)frame text:(NSString *)text textAlignment:(NSTextAlignment)textAlignment font:(UIFont *)font;

/**
 *    @brief 获取类对象
 */
+ (UILabel *)dmo_labelWithFrame:(CGRect)frame text:(NSString *)text font:(UIFont *)font color:(UIColor *)color;

/**
 *    @brief 更改label字体
 */
- (void)dmo_setFontType:(NSString *)typeName;




@end
