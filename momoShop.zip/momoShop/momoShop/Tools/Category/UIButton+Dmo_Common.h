//
//  UIButton+common.h
//  kuaixiu-vendor
//
//  Created by dmo on 15/8/20.
//  Copyright (c) 2015年 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Dmo_Common)

/**
 *	@brief 封装Button属性
 */
- (void)setTitle:(NSString *)title withFont:(UIFont *)font withColor:(UIColor *)color withBackgroundColor:(UIColor *)backgroundColor padding:(UIEdgeInsets)padding withHorizontalAlignment:(UIControlContentHorizontalAlignment)horizontalAlignment forState:(UIControlState)controlState;

/**
 *    @brief 获取类对象
 */
+ (UIButton *)dmo_buttonWithFrame:(CGRect)frame type:(UIButtonType)type title:(NSString *)title titleColor:(UIColor *)titleColor imageName:(NSString *)imageName action:(SEL)sel target:(id)target;

@end
