//
//  AreaPopView.m
//  Example-ios
//
//  Created by wsy on 2017/8/11.
//  Copyright © 2017年 yayuanzi. All rights reserved.
//

#import "AreaPopView.h"

@implementation AreaPopView
@synthesize pArray;
@synthesize cArray;
@synthesize aArray;

+ (id)initWithBlock:(AreaBlock)block andAreaArray:(NSDictionary *)provinceDic{
    AreaPopView *popView = [[AreaPopView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    popView.areaBlock = block;
    popView.provinceDic = [NSMutableDictionary dictionaryWithDictionary:provinceDic];
    [[UIApplication sharedApplication].keyWindow addSubview:popView];
    
    UIButton *backButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    backButton.backgroundColor = kRGBA(0, 0, 0, 0.6);
    [backButton addTarget:popView action:@selector(backButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [popView addSubview:backButton];
    
    UIView *centerView = [UIView dmo_viewWithFrame:CGRectMake(0, kScreenHeight - 180 * kBL, kScreenWidth, 180 * kBL) backgroundColor:[UIColor whiteColor]];
    [centerView dmo_setCornerRadius:6.f];
    [popView addSubview:centerView];
    
    UIView *orangeColorViewForSelect = [UIView dmo_viewWithFrame:CGRectMake(0, 0, kScreenWidth, 40 * kBL) backgroundColor:[UIColor whiteColor]];
    [centerView addSubview:orangeColorViewForSelect];
    
    UIView *lineView = [UIView dmo_viewWithFrame:CGRectMake(0, 39 * kBL, kScreenWidth, 1) backgroundColor:kRGBA(210, 210, 210, 0.4)];
    [orangeColorViewForSelect addSubview:lineView];
    
    UILabel *selectDateLabel = [UILabel dmo_labelWithFrame:CGRectMake(0, 0, kScreenWidth, 40 * kBL) text:@"选择所在地区" textAlignment:NSTextAlignmentCenter font:kFONT(15)];
    [orangeColorViewForSelect addSubview:selectDateLabel];
    
    UIButton *selectDateCancelButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, 0, 50 * kBL, 40 * kBL) type:UIButtonTypeCustom title:@"取消" titleColor:kRGB(169, 169, 169) imageName:nil action:@selector(backButtonAction) target:popView];
    selectDateCancelButton.titleLabel.font = kFONT(13);
    [orangeColorViewForSelect addSubview:selectDateCancelButton];
    
    UIButton *selectDateEnterButton = [UIButton dmo_buttonWithFrame:CGRectMake(0, 0, 50 * kBL, 40 * kBL) type:UIButtonTypeCustom title:@"确定" titleColor:[UIColor blackColor] imageName:nil action:@selector(enterAction) target:popView];
    selectDateEnterButton.titleLabel.font = kFONT(13);
    selectDateEnterButton.maxX = kScreenWidth;
    [orangeColorViewForSelect addSubview:selectDateEnterButton];
    
    UIView *whiteColorView = [UIView dmo_viewWithFrame:CGRectMake(0, orangeColorViewForSelect.maxY, kScreenWidth, 140 * kBL) backgroundColor:[UIColor whiteColor]];
    [centerView addSubview:whiteColorView];
    
    popView.pArray = [NSArray arrayWithArray:[popView.provinceDic allKeys]];
    popView.cityDic = [provinceDic objectForKey:popView.pArray[0]][0];
    popView.cArray = [NSArray arrayWithArray:[popView.cityDic allKeys]];
    popView.aArray = [NSArray arrayWithArray:[popView.cityDic objectForKey:popView.cArray[0]]];
    
    popView.province = popView.pArray[0];
    popView.city = popView.cArray[0];
    popView.area = popView.aArray[0];
    
    UIPickerView *selectAddressPickerView = [[UIPickerView alloc]initWithFrame:whiteColorView.bounds];
    selectAddressPickerView.delegate = popView;
    selectAddressPickerView.dataSource = popView;
    [whiteColorView addSubview:selectAddressPickerView];

    return popView;
}

- (void)backButtonAction {
    [self removeFromSuperview];
}

- (void)enterAction {
    if (self.areaBlock != nil) {
        self.areaBlock(self.province,self.city,self.area);
    }
    [self removeFromSuperview];
}

#pragma mark -- UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 3;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (component == 0) {
        return pArray.count;
    }else if (component == 1) {
        return cArray.count;
    }else {
        return aArray.count;
    }
}

#pragma mark -- UIPickerViewDelegate
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component == 0) {
        return pArray[row];
    }else if (component == 1) {
        return cArray[row];
    }else {
        return aArray[row];
    }
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
    return kScreenWidth/3;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (component == 0) {
        self.province = self.pArray[row];
        self.cityDic = [self.provinceDic objectForKey:self.pArray[row]][0];
        self.cArray = [NSArray arrayWithArray:[self.cityDic allKeys]];
        self.aArray = [NSArray arrayWithArray:[self.cityDic objectForKey:self.cArray[0]]];
        self.city = self.cArray[0];
        self.area = self.aArray[0];
        
        [pickerView selectRow:0 inComponent:1 animated:YES];
        [pickerView selectRow:0 inComponent:2 animated:YES];
        [pickerView reloadComponent:1];
        [pickerView reloadComponent:2];
    }else if (component == 1) {
        
        self.city = self.cArray[row];
        self.aArray = [NSArray arrayWithArray:[self.cityDic objectForKey:self.cArray[row]]];
        self.area = self.aArray[0];
        
        [pickerView selectRow:0 inComponent:2 animated:YES];
        [pickerView reloadComponent:2];
    }else{
       self.area = self.aArray[row];
    }
}

@end
