//
//  LabelAndTextCell.h
//  normal
//
//  Created by dmooo on 2019/2/15.
//  Copyright © 2019年 dm. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LabelAndTextCell : UITableViewCell

@end

NS_ASSUME_NONNULL_END
