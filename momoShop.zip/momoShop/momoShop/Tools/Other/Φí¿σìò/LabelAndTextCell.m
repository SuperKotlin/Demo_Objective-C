//
//  LabelAndTextCell.m
//  normal
//
//  Created by dmooo on 2019/2/15.
//  Copyright © 2019年 dm. All rights reserved.
//

#import "LabelAndTextCell.h"
@interface LabelAndTextCell()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UITextField *textField;
@end
@implementation LabelAndTextCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
