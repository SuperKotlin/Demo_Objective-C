//
//  LabelAndButtonCell.m
//  normal
//
//  Created by dmooo on 2019/2/15.
//  Copyright © 2019年 dm. All rights reserved.
//

#import "LabelAndButtonCell.h"
@interface LabelAndButtonCell()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *placeholderLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *nameLabelWidth;

@end
@implementation LabelAndButtonCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

- (IBAction)clickBtn:(id)sender {

}

@end
