//
//  LocationToolObject.m
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/4/1.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "LocationToolObject.h"
#import <CoreLocation/CLLocationManager.h>

@implementation LocationToolObject
#pragma mark 判断是否打开定位

+(BOOL)opensTheLocation{
    if ([CLLocationManager locationServicesEnabled] && ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedWhenInUse ||[CLLocationManager authorizationStatus] == kCLAuthorizationStatusNotDetermined || [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorized || [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways)) {
        return YES;
    }else if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied) {
        return NO;
    }else{
        return NO;
    }
}

//打开设置
//[[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];

@end
