//
//  ZWSlideBar.h
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/3/27.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol ZWSlideBarDelegate <NSObject>
- (void)selectSlideBarItemAtIndex:(NSUInteger)index;

@end

@interface ZWSlideBar : UIView

- (id)initWithFrame:(CGRect)frame titleArr:(NSArray *)titleArr itemColor:(UIColor *)itemColor itemSelectedColor:(UIColor *)itemSelectedColor sliderColor:(UIColor *)sliderColor sliderWidth:(NSInteger)sliderWidth fontSize:(UIFont *)fontSize;

@property(assign,nonatomic) id<ZWSlideBarDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
