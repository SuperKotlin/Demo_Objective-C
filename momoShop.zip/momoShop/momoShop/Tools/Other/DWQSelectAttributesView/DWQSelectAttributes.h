//
//  DWQSelectAttributes.h
//  DWQSelectAttributes
//
//  Created by 杜文全 on 15/5/21.
//  Copyright © 2015年 com.sdzw.duwenquan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SelectAttributesDelegate <NSObject>
@required
- (void)selectBtnTitle:(NSString *)title tags:(NSInteger)tags btnTag:(NSInteger)btnTag;

@end

@interface DWQSelectAttributes : UIView
@property(nonatomic,copy) NSString *title;
@property(nonatomic,strong) NSArray *attributesArray;
@property(nonatomic,strong) UIButton *selectBtn;
@property(nonatomic,strong) UIView *packView;
@property(nonatomic,strong) UIView *btnView;
@property(nonatomic,assign) NSInteger tags;

@property(nonatomic,assign)id<SelectAttributesDelegate> delegate;

-(instancetype)initWithTitle:(NSString *)title attributesArray:(NSArray *)attributesArray andFrame:(CGRect)frame;


@end
