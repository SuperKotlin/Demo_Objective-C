//
//  DWQSelectView.m
//  DWQSelectAttributes
//
//  Created by 杜文全 on 15/5/21.
//  Copyright © 2015年 com.sdzw.duwenquan. All rights reserved.
//

#import "DWQSelectView.h"

@interface DWQSelectView ()
//规格分类
@property (nonatomic,strong) NSArray *rankArr;

@end
@implementation DWQSelectView

@synthesize alphaView,whiteView,headImgV,inventoryLab,priceLab,nameLab,skuLab,mainscrollview,cancelBtn,cartBtn,buyBtn,numView,numTextField,lessButton,addButton;

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        [self creatUI];
    }
    return self;
}
- (void)creatUI{
    //半透明视图
    alphaView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    alphaView.backgroundColor = kRGBA(0, 0, 0, 0.5);
    [self addSubview:alphaView];
    
    //装载商品信息的视图
    whiteView = [[UIView alloc] initWithFrame:CGRectMake(0, 200 * kBL, kScreenWidth, kScreenHeight - 200 * kBL)];
    whiteView.backgroundColor = [UIColor whiteColor];
    [self addSubview:whiteView];
    
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:whiteView.bounds byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight    cornerRadii:CGSizeMake(10, 10)];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = whiteView.bounds;
    maskLayer.path = maskPath.CGPath;
    whiteView.layer.mask = maskLayer;
    
    cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    cancelBtn.frame = CGRectMake(kScreenWidth - 34 * kBL, 14 * kBL, 18 * kBL, 18 * kBL);
    [cancelBtn setBackgroundImage:[UIImage imageNamed:@"close"] forState:0];
    [whiteView addSubview:cancelBtn];
    
    //商品图片
    headImgV = [[UIImageView alloc] initWithFrame:CGRectMake(14 * kBL, 40 * kBL, 78 * kBL, 78 * kBL)];
    [whiteView addSubview:headImgV];
    
    nameLab = [[UILabel alloc] initWithFrame:CGRectMake(headImgV.maxX + 6 * kBL, headImgV.minY, kScreenWidth - headImgV.maxX - 20 * kBL, 36 * kBL)];
    nameLab.numberOfLines = 0;
    nameLab.font = kFONT(14);
    nameLab.textColor = k51Color;
    [whiteView addSubview:nameLab];
    
    skuLab = [[UILabel alloc] initWithFrame:CGRectMake(nameLab.minX, nameLab.maxY, nameLab.width, 22 * kBL)];
    skuLab.numberOfLines = 0;
    skuLab.font = kFONT(13);
    skuLab.textColor = k153Color;
    skuLab.text = @"已选";
    [whiteView addSubview:skuLab];
    
    //商品价格
    priceLab = [[UILabel alloc] initWithFrame:CGRectMake(nameLab.minX, skuLab.maxY, nameLab.width / 2.0, 18 * kBL)];
    priceLab.text = @"¥0.00";
    priceLab.textColor = [UIColor redColor];
    priceLab.font = kFONT(16);
    [whiteView addSubview:priceLab];
    
    inventoryLab = [[UILabel alloc] initWithFrame:CGRectMake(priceLab.maxX, skuLab.maxY, nameLab.width / 2.0, 18 * kBL)];
    inventoryLab.text = @"库存0";
    inventoryLab.textColor = k153Color;
    inventoryLab.font = kFONT(14);
    inventoryLab.textAlignment = NSTextAlignmentRight;
    [whiteView addSubview:inventoryLab];
    
    //有的商品尺码和颜色分类特别多 所以用UIScrollView 分类过多显示不全的时候可滑动查看
    mainscrollview = [[UIScrollView alloc] initWithFrame:CGRectMake(0, headImgV.maxY + 10 * kBL, kScreenWidth, whiteView.height - headImgV.maxY - kFooterHeight - 52 * kBL)];
    mainscrollview.backgroundColor = [UIColor clearColor];
    mainscrollview.contentSize = CGSizeMake(0, 200);
    mainscrollview.showsHorizontalScrollIndicator = NO;
    mainscrollview.showsVerticalScrollIndicator = NO;
    [whiteView addSubview:mainscrollview];
    
    //数量加减
    numView = [[UIView alloc] initWithFrame:CGRectMake(14 * kBL, 0, kScreenWidth - 28 * kBL, 30 * kBL)];
    [mainscrollview addSubview:numView];
    
    UILabel *slLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 60, numView.height)];
    slLab.text = @"数量";
    slLab.font = kFONT(14);
    slLab.textColor = kBlackColor;
    [numView addSubview:slLab];
    
    lessButton = [[UIButton alloc] initWithFrame:CGRectMake(numView.width - 74 * kBL, 0, 20 * kBL, 20 * kBL)];
    [lessButton setImage:[UIImage imageNamed:@"cart_less"] forState:UIControlStateNormal];
    lessButton.centerY = slLab.centerY;
    [numView addSubview:lessButton];
    
    numTextField = [[UITextField alloc] initWithFrame:CGRectMake(lessButton.maxX, 0, 34 * kBL, lessButton.height)];
    numTextField.font = kFONT(13);
    numTextField.textAlignment = NSTextAlignmentCenter;
    numTextField.text = @"1";
    numTextField.backgroundColor = k244Color;
    numTextField.userInteractionEnabled = NO;
    [numView addSubview:numTextField];
    numTextField.centerY = slLab.centerY;
    
    addButton = [[UIButton alloc] initWithFrame:CGRectMake(numTextField.maxX, 0, lessButton.width, lessButton.height)];
    [addButton setImage:[UIImage imageNamed:@"cart_add"] forState:UIControlStateNormal];
    addButton.centerY = lessButton.centerY;
    [numView addSubview:addButton];
    
    //底部按钮
    CGFloat width = (whiteView.frame.size.width - 44 * kBL) / 2;
    //加入购物车按钮
    cartBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    cartBtn.frame = CGRectMake(18 * kBL, whiteView.height - kFooterHeight - 42 * kBL,width, 34 * kBL);
    [cartBtn setTitleColor:[UIColor whiteColor] forState:0];
    cartBtn.titleLabel.font = kFONT(14);
    [cartBtn setTitle:@"加入购物车" forState:0];
    [cartBtn setBackgroundImage:[UIImage imageNamed:@"shopcar_add"] forState:UIControlStateNormal];
    [whiteView addSubview:cartBtn];
    
    //立即购买按钮
    buyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    buyBtn.frame = CGRectMake(cartBtn.maxX + 8 * kBL, cartBtn.minY, width, cartBtn.height);
    [buyBtn setTitleColor:[UIColor whiteColor] forState:0];
    buyBtn.titleLabel.font = kFONT(14);
    [buyBtn setTitle:@"立即购买" forState:0];
    [buyBtn setBackgroundImage:[UIImage imageNamed:@"shopcar_buy"] forState:UIControlStateNormal];
    [whiteView addSubview:buyBtn];
}

@end
