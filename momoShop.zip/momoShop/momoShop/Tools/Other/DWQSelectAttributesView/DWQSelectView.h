//
//  DWQSelectView.h
//  DWQSelectAttributes
//
//  Created by 杜文全 on 15/5/21.
//  Copyright © 2015年 com.sdzw.duwenquan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DWQSelectView : UIView
@property (nonatomic,strong) UIView *alphaView;
@property (nonatomic,strong) UIView *whiteView;
@property (nonatomic,strong) UIImageView *headImgV;
@property (nonatomic,strong) UILabel *nameLab;  //商品名称
@property (nonatomic,strong) UILabel *priceLab;
@property (nonatomic,strong) UILabel *inventoryLab; //库存
@property (nonatomic,strong) UILabel *skuLab; //规格

@property(nonatomic,strong) UIScrollView *mainscrollview;
//数量加减
@property (nonatomic,strong) UIView *numView;
@property (nonatomic,strong) UIButton *lessButton;
@property (nonatomic,strong) UIButton *addButton;
@property (nonatomic,strong) UITextField *numTextField;
//操作按钮（关闭，加入购物车，立即购买）
@property (nonatomic,strong) UIButton *cancelBtn;
@property (nonatomic,strong) UIButton *cartBtn;
@property (nonatomic,strong) UIButton *buyBtn;


- (instancetype)initWithFrame:(CGRect)frame;


@end
