//
//  DWQSelectAttributes.m
//  DWQSelectAttributes
//
//  Created by 杜文全 on 15/5/21.
//  Copyright © 2015年 com.sdzw.duwenquan. All rights reserved.
//

#import "DWQSelectAttributes.h"
#define SelectColor kRGB(253, 198, 186)
#define bgColor kRGB(244, 244, 244)
#define titleColor kRGB(250, 63, 41)

@implementation DWQSelectAttributes

- (instancetype)initWithTitle:(NSString *)title attributesArray:(NSArray *)attributesArray andFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = frame;
        self.title = title;
        self.attributesArray = [NSArray arrayWithArray:attributesArray];
        [self rankView];
    }
    return self;
}

- (void)rankView{
    self.packView = [[UIView alloc] initWithFrame:self.frame];
    self.packView.top = 0;
    
    UILabel *titleLB = [[UILabel alloc] initWithFrame:CGRectMake(14 * kBL, 4 * kBL, kScreenWidth, 24 * kBL)];
    titleLB.text = self.title;
    titleLB.font = kFONT(15);
    [self.packView addSubview:titleLB];
    
    self.btnView = [[UIView alloc] initWithFrame:CGRectMake(0,CGRectGetMaxY(titleLB.frame), kScreenWidth, 40)];
    [self.packView addSubview:self.btnView];
    
    int count = 0;
    float btnWidth = 0;
    float viewHeight = 0;
    for (int i = 0; i < self.attributesArray.count; i++) {
        NSString *btnName = self.attributesArray[i];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setBackgroundColor:bgColor];
        [btn setTitleColor:k51Color forState:UIControlStateNormal];
        [btn setTitleColor:titleColor forState:UIControlStateSelected];
        btn.titleLabel.font = [UIFont systemFontOfSize:14];
        [btn setTitle:btnName forState:UIControlStateNormal];
        [btn dmo_setBorder:1.f color:bgColor];
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = 1000 + i;
        
        NSDictionary *dict = [NSDictionary dictionaryWithObject:kFONT(13) forKey:NSFontAttributeName];
        CGSize btnSize = [btnName sizeWithAttributes:dict];
        
        btn.height = btnSize.height + 12;
        CGFloat cellw = btnSize.width + 10;
        if (cellw < btn.height) {
            btn.width = btn.height + 6;
        }else{
            btn.width = cellw + 14;
        }
        
        if (i == 0){
            btn.left = 16 * kBL;
            btnWidth += CGRectGetMaxX(btn.frame);
        }else{
            btnWidth += CGRectGetMaxX(btn.frame) + 16;
            if (btnWidth > (kScreenWidth - 28 * kBL)) {
                count++;
                btn.left = 16 * kBL;
                btnWidth = CGRectGetMaxX(btn.frame);
            }else{
                btn.left += btnWidth - btn.width;
            }
        }
        btn.top += count * (btn.height+10)+10;
        viewHeight = CGRectGetMaxY(btn.frame)+10;
        [self.btnView addSubview:btn];
        [btn dmo_setCornerRadius:btn.height / 2.0];
    }
    self.btnView.height = viewHeight;
    self.packView.height = self.btnView.height+CGRectGetMaxY(titleLB.frame);
    self.height = self.packView.height + 4 * kBL;
    
    [self addSubview:self.packView];
}
- (void)btnClick:(UIButton *)btn{
    if (![self.selectBtn isEqual:btn]) {
        self.selectBtn.backgroundColor = bgColor;
        self.selectBtn.selected = NO;
        [self.selectBtn dmo_setBorder:1.f color:bgColor];
    }else{
        btn.backgroundColor = kRGB(254, 228, 229);
        [btn dmo_setBorder:1.f color:SelectColor];
    }
    btn.backgroundColor = kRGB(254, 228, 229);
    [btn dmo_setBorder:1.f color:SelectColor];
    btn.selected = YES;
    
    self.selectBtn = btn;
    self.selectBtn.tag = btn.tag;
    
//    if ([self.delegate respondsToSelector:@selector(selectBtnTitle:andBtn:)]) {
//        [self.delegate selectBtnTitle:btn.titleLabel.text andBtn:self.selectBtn];
//    }
    
    if ([self.delegate respondsToSelector:@selector(selectBtnTitle:tags:btnTag:)]) {
        [self.delegate selectBtnTitle:btn.titleLabel.text tags:(self.tags - kTagStart) btnTag:(btn.tag - 1000)];
    }
    
}

@end
