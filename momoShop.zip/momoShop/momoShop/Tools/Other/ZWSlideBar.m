//
//  ZWSlideBar.m
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/3/27.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "ZWSlideBar.h"
#define DEVICE_WIDTH CGRectGetWidth([UIScreen mainScreen].bounds)
#define DEFAULT_SLIDER_COLOR [UIColor redColor]
#define SLIDER_VIEW_HEIGHT 2

@interface ZWSlideBar ()
//文字大小
@property (assign, nonatomic) NSInteger itemFontSize;
//文字
@property (strong, nonatomic) NSArray *itemsTitle;
//文字颜色
@property (strong, nonatomic) UIColor *itemColor;
//选中文字颜色
@property (strong, nonatomic) UIColor *itemSelectedColor;
//
@property (strong, nonatomic) UIFont *fontSize;
//滑动条的颜色
@property (strong, nonatomic) UIColor *sliderColor;
//滑动条的宽度，不设置默认是文字的宽度
@property (nonatomic,assign) NSInteger sliderWidth;
//滑动条
@property (strong, nonatomic) UIView *sliderView;
//item
@property (nonatomic,strong) NSMutableArray *buttonArray;

@end

@implementation ZWSlideBar

- (id)initWithFrame:(CGRect)frame titleArr:(NSArray *)titleArr itemColor:(UIColor *)itemColor itemSelectedColor:(UIColor *)itemSelectedColor sliderColor:(UIColor *)sliderColor sliderWidth:(NSInteger)sliderWidth fontSize:(UIFont *)fontSize{
    if(self = [super initWithFrame:frame]){
        _itemsTitle = titleArr;
        _itemColor = itemColor;
        _itemSelectedColor = itemSelectedColor;
        _sliderColor = sliderColor;
        _sliderWidth = sliderWidth;
        _fontSize = fontSize;
        [self setUI];
    }
    return self;
}
- (void)setUI{
    CGFloat btnWidth = self.frame.size.width / self.itemsTitle.count;
    self.buttonArray = [[NSMutableArray alloc] init];
//    NSLog(@"_itemsTitle==%@",self.itemsTitle);
    for (int i = 0; i < self.itemsTitle.count; i ++) {
        UIButton *topButton = [[UIButton alloc] init];
        topButton.frame = CGRectMake(btnWidth * i, 0, btnWidth, self.frame.size.height);
        topButton.tag = kTagStart + i;
        topButton.titleLabel.font = _fontSize;
        [topButton setTitle:self.itemsTitle[i] forState:UIControlStateNormal];
        [topButton setTitleColor:self.itemColor forState:UIControlStateNormal];
        [topButton addTarget:self action:@selector(topButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:topButton];
        
        if (i == 0) {
            [topButton setTitleColor:self.itemSelectedColor forState:0];
            _sliderView = [[UIView alloc] init];
            _sliderView.frame = CGRectMake(0, topButton.maxY - SLIDER_VIEW_HEIGHT, _sliderWidth, SLIDER_VIEW_HEIGHT);
            _sliderView.backgroundColor = _sliderColor;
            _sliderView.centerX = topButton.centerX;
            [self addSubview:_sliderView];
        }
        
        [self.buttonArray addObject:topButton];
    }
}
- (void)topButtonAction:(UIButton *)sender {
    NSInteger tag = sender.tag;
    for (int i = 0; i < _buttonArray.count; i++) {
        UIButton *button = _buttonArray[i];
        [UIView animateWithDuration:0.5 animations:^{
            
        }];
        if (button.tag == tag) {
            [button setTitleColor:self.itemSelectedColor forState:0];
            self.sliderView.centerX = button.centerX;
        } else {
            [button setTitleColor:self.itemColor forState:0];
        }
    }
    [self.delegate selectSlideBarItemAtIndex:tag - kTagStart];
}

@end
