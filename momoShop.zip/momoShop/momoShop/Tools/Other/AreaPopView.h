//
//  AreaPopView.h
//  Example-ios
//
//  Created by wsy on 2017/8/11.
//  Copyright © 2017年 yayuanzi. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^AreaBlock) (NSString *province, NSString *city, NSString *area);
@interface AreaPopView : UIView<UIPickerViewDelegate,UIPickerViewDataSource>

@property (nonatomic, strong) AreaBlock areaBlock;

@property (nonatomic, copy) NSDictionary *provinceDic;

@property (nonatomic, copy) NSDictionary *cityDic;

//省市区
@property (nonatomic, copy) NSString *province;
@property (nonatomic, copy) NSString *city;
@property (nonatomic, copy) NSString *area;

@property (nonatomic, copy) NSArray *pArray;
@property (nonatomic, copy) NSArray *cArray;
@property (nonatomic, copy) NSArray *aArray;

+ (id)initWithBlock:(AreaBlock)block andAreaArray:(NSDictionary *)provinceDic;

@end
