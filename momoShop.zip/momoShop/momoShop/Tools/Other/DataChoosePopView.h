//
//  DataChoosePopView.h
//  DM-IOS
//
//  Created by wsy on 2017/6/16.
//  Copyright © 2017年 yayuanzi. All rights reserved.
//  日期选择器   年月日

#import <UIKit/UIKit.h>

typedef void (^DataChooseBlock) (NSString *date);

@interface DataChoosePopView : UIView

//日期
@property (nonatomic, copy) NSString *date;

@property (nonatomic, strong) DataChooseBlock block;

//日期选择器
@property (nonatomic, strong) UIDatePicker *datePicker;

+(id)initWithBlock:(DataChooseBlock)block;
@end
