//
//  LocationToolObject.h
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/4/1.
//  Copyright © 2019 dmo. All rights reserved.

//  用于判断用户是否开启了定位

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LocationToolObject : NSObject
/*
 * 判断是否打开定位
 */
+ (BOOL)opensTheLocation;


@end

NS_ASSUME_NONNULL_END
