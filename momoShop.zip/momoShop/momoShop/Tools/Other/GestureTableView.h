//
//  GestureTableView.h
//  CarSteward
//
//  Created by 李雪阳 on 2018/8/27.
//  Copyright © 2018年 singularity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GestureTableView : UITableView

@end
