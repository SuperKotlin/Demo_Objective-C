//
//  CTNetwork.h
//  ConsultTime
//
//  Created by 李维佳 on 2018/11/6.
//  Copyright © 2018年 liz. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, RequestType) {
    /**
     *  post请求
     */
    requestTypePost = 0,
    /**
     *  get请求
     */
    requestTypeGet,
};

@interface DmoNetwork : NSObject
+(DmoNetwork*)dmo_network;
typedef void(^successCallBack)(NSDictionary *obj);
typedef void(^failureCallBack)(NSString *errMessage);
- (void)dmo_requestWith:(NSString*)url parameters:(nullable id)parameters success:(successCallBack)successCallback failure:(failureCallBack)failureCallback requestType:(RequestType)requestType;
//- (void)liz_deleteWith:(NSString*)url success:(successCallBack)successCallback failure:(failureCallBack)failureCallback;


@end

NS_ASSUME_NONNULL_END
