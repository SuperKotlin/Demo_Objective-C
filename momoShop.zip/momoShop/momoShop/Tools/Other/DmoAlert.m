//
//  DmoAlert.m
//  normal
//
//  Created by dmooo on 2019/2/22.
//  Copyright © 2019年 dm. All rights reserved.
//

#import "DmoAlert.h"
@interface DmoAlert()
@property(nonatomic,strong)UIView*coverView;//遮罩层
@property(nonatomic,strong)UIImageView *alertView;
@property(nonatomic,strong)UIImageView *imgView;
@property(nonatomic,strong)UILabel*titleLabel;
@property(nonatomic,strong)UILabel*tipLabel;
@property(nonatomic,strong)UIButton *leftBtn;
@property(nonatomic,strong)UIButton *rightBtn;
@property(nonatomic,strong)UIView*lineView;
@property(nonatomic,strong)UIView*verticalView;
@property(nonatomic,copy)NSString *title;
@property(nonatomic,copy)NSString *content;
@property(nonatomic,copy)NSString *img;
@property(nonatomic,assign)BOOL isTwo;
@end

@implementation DmoAlert

- (instancetype)initAlertWithFrame:(CGRect)frame withImg:(NSString*)img withTitle:(NSString*)title withContent:(NSString*)content alertType:(AlertType)alertType{
    self = [super initWithFrame:frame];
    _title = title;
    _content = content;
    _img = img;
    switch (alertType) {
        case AlertTypeTwo:
        {
            _isTwo = YES;
            [self dmo_addSubviews2];
            [self dmo_setViewLayout2];
        }
            break;
        case AlertTypeOne:
        {
             _isTwo = NO;
            [self dmo_addSubviews];
            [self dmo_setViewLayout];
        }
            break;
        default:
            break;
    }
   
    return self;
}
#pragma mark ->Private Method
- (void)dmo_addSubviews {
    [self addSubview:self.coverView];
    [self addSubview:self.alertView];
    [self.alertView addSubview:self.imgView];
    [self.alertView addSubview:self.titleLabel];
    [self.alertView addSubview:self.leftBtn];
}
- (void)dmo_setViewLayout {
    WS(ws);
    [self.coverView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(ws).with.insets(UIEdgeInsetsMake(0, 0, 0, 0));
    }];
    [self.alertView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(ws);
        make.centerX.mas_equalTo(ws);
        make.size.mas_equalTo(CGSizeMake(200, 230));
    }];
    [self.imgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(ws).with.offset(-10);
        make.top.equalTo(ws.alertView.mas_top).with.offset(20);
        make.size.mas_equalTo(CGSizeMake(131, 105));//1.25
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.imgView.mas_bottom).with.offset(10);
        make.left.equalTo(ws.alertView).with.offset(10);
        make.right.equalTo(ws.alertView).with.offset(-10);
        make.height.mas_equalTo(25);
    }];
    [self.leftBtn mas_makeConstraints:^(MASConstraintMaker *make) {
         make.top.equalTo(ws.titleLabel.mas_bottom).with.offset(15);
         make.size.mas_equalTo(CGSizeMake(90, 36));
         make.centerX.mas_equalTo(ws);
    }];
}
- (void)dmo_addSubviews2 {
    [self addSubview:self.coverView];
    [self addSubview:self.alertView];
    [self.alertView addSubview:self.leftBtn];
    [self.alertView addSubview:self.verticalView];
    [self.alertView addSubview:self.rightBtn];
    [self.alertView addSubview:self.lineView];
    [self addSubview:self.imgView];
    [self.alertView addSubview:self.titleLabel];
    [self.alertView addSubview:self.tipLabel];
}
- (void)dmo_setViewLayout2 {
    WS(ws);
    [self.coverView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(ws).with.insets(UIEdgeInsetsMake(0, 0, 0, 0));
    }];
    [self.alertView mas_makeConstraints:^(MASConstraintMaker *make) {
         make.centerY.mas_equalTo(ws);
         make.centerX.mas_equalTo(ws);
         make.size.mas_equalTo(CGSizeMake(260, 280));
    }];
    [self.leftBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.alertView);
        make.left.equalTo(ws.alertView);
        make.size.mas_equalTo(CGSizeMake(130, 45));
    }];
    [self.verticalView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.alertView);
        make.centerX.mas_equalTo(ws);
        make.size.mas_equalTo(CGSizeMake(1, 45));
    }];
    [self.rightBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(ws.alertView);
        make.right.equalTo(ws.alertView);
        make.size.mas_equalTo(CGSizeMake(130, 45));
    }];
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(1);
        make.top.equalTo(ws.rightBtn.mas_top).with.offset(0);
        make.left.equalTo(ws.alertView);
        make.right.equalTo(ws.alertView);
    }];
    [self.imgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(ws);
        make.top.equalTo(ws.alertView.mas_top).with.offset(-40);
        make.size.mas_equalTo(CGSizeMake(180, 150));
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.imgView.mas_bottom).with.offset(10);
        make.left.equalTo(ws.alertView).with.offset(10);
        make.right.equalTo(ws.alertView).with.offset(-10);
        make.height.mas_equalTo(25);
    }];
    [self.tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ws.titleLabel.mas_bottom).with.offset(10);
        make.left.equalTo(ws.alertView).with.offset(10);
        make.right.equalTo(ws.alertView).with.offset(-10);
        make.bottom.equalTo(ws.lineView.mas_top).with.offset(-15);
    }];
}
#pragma mark ->Action Method
- (void)clickLeft:(UIButton*)btn{
    if (self.leftAction) {
        self.leftAction(btn);
    }
    [self removeFromSuperview];
}
- (void)clickRight:(UIButton*)btn{
    if (self.rightAction) {
        self.rightAction(btn);
    }
    [self removeFromSuperview];
}
#pragma mark ->setter/getter Method
- (UIView *)coverView {
    if (!_coverView) {
        _coverView = [[UIView alloc]init];
        _coverView.backgroundColor = [UIColor blackColor];
        _coverView.alpha = 0.6;
    }
    return _coverView;
}
- (UIImageView *)alertView {
    if (!_alertView) {
        _alertView = [[UIImageView alloc]init];
        _alertView.layer.masksToBounds = YES;
        _alertView.layer.cornerRadius = 8;
        _alertView.backgroundColor = [UIColor whiteColor];
        _alertView.userInteractionEnabled = YES;
    }
    return _alertView;
}
- (UIImageView *)imgView {
    if (!_imgView) {
        _imgView = [[UIImageView alloc]init];
//        _imgView.backgroundColor = [UIColor redColor];
        _imgView.image = [UIImage imageNamed:_img];
    }
    return _imgView;
}
- (UIButton *)leftBtn {
    if (!_leftBtn) {
        _leftBtn = [[UIButton alloc]init];
         [_leftBtn addTarget:self action:@selector(clickLeft:) forControlEvents:UIControlEventTouchUpInside];
        if (!_isTwo) {
            [_leftBtn setTitle:@"知道了" forState:UIControlStateNormal];
            [_leftBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            //248,115,107
            _leftBtn.backgroundColor = [UIColor colorWithRed:248/255.0 green:115/255.0 blue:107/255.0 alpha:1];
            _leftBtn.layer.masksToBounds = YES;
            _leftBtn.layer.cornerRadius = 16;
        }else{
            [_leftBtn setTitle:@"取消" forState:UIControlStateNormal];
            [_leftBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        }
        _leftBtn.titleLabel.font = [UIFont systemFontOfSize:16.0];
    }
    return _leftBtn;
}
- (UIButton *)rightBtn {
    if (!_rightBtn) {
        _rightBtn = [[UIButton alloc]init];
        [_rightBtn addTarget:self action:@selector(clickRight:) forControlEvents:UIControlEventTouchUpInside];
        [_rightBtn setTitle:@"确定" forState:UIControlStateNormal];
        [_rightBtn setTitleColor:kColorFromRGB(0x7B68EE) forState:UIControlStateNormal];
        _rightBtn.titleLabel.font = [UIFont systemFontOfSize:16.0];
    }
    return _rightBtn;
}
- (UIView *)lineView {
    if (!_lineView) {
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = kColorFromRGB(0xf1f1f1);
    }
    return _lineView;
}
- (UIView *)verticalView {
    if (!_verticalView) {
        _verticalView = [[UIView alloc]init];
        _verticalView.backgroundColor = kColorFromRGB(0xf1f1f1);
    }
    return _verticalView;
}
- (UILabel *)tipLabel {
    if (!_tipLabel) {
        _tipLabel = [[UILabel alloc]init];
        _tipLabel.numberOfLines = 0;
        _tipLabel.font = [UIFont systemFontOfSize:15.0];
        _tipLabel.textColor = [UIColor lightGrayColor];
        _tipLabel.text = _content;
        _tipLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _tipLabel;
}
- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc]init];
//        _titleLabel.numberOfLines = 2;
//        _titleLabel.font = [UIFont systemFontOfSize:15.0];
        _titleLabel.textColor = kColorFromRGB(0x7B68EE);
        _titleLabel.text = _title;
        _titleLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _titleLabel;
}

@end
