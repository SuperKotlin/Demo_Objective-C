//
//  DmoAlert.h
//  normal
//
//  Created by dmooo on 2019/2/22.
//  Copyright © 2019年 dm. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSInteger, AlertType) {
    /**
     * 两个按钮
     */
    AlertTypeTwo = 0,
    /**
     *  一个按钮
     */
    AlertTypeOne,
};
typedef void(^ButtonClick)(UIButton * sender);
@interface DmoAlert : UIView
- (instancetype)initAlertWithFrame:(CGRect)frame withImg:(NSString*)img withTitle:(NSString*)title withContent:(NSString*)content alertType:(AlertType)alertType;

/**
 左图标点击方法
 */
@property (nonatomic,copy) ButtonClick leftAction;
/**
 右图标点击方法
 */
@property (nonatomic,copy) ButtonClick rightAction;
@end

NS_ASSUME_NONNULL_END
