//
//  CTNetwork.m
//  ConsultTime
//
//  Created by 李维佳 on 2018/11/6.
//  Copyright © 2018年 liz. All rights reserved.
//

#import "DmoNetwork.h"
#import "AFNetworking.h"
@interface DmoNetwork()
@property(nonatomic,strong)AFHTTPSessionManager * manager;
@end
@implementation DmoNetwork

+(DmoNetwork*)dmo_network{
    return [[DmoNetwork alloc]init];
}

- (instancetype)init {
    if (self) {
        self.manager = [AFHTTPSessionManager manager];
        self.manager.requestSerializer = [AFHTTPRequestSerializer serializer];
        self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        self.manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain", @"multipart/form-data", @"application/json", @"text/html", @"image/jpeg", @"image/png", @"application/octet-stream", @"text/json", nil];
       self.manager.requestSerializer.timeoutInterval = 20.f;
    }
    return self;
}

- (void)dmo_requestWith:(NSString*)url parameters:(nullable id)parameters success:(successCallBack)successCallback failure:(failureCallBack)failureCallback requestType:(RequestType)requestType {
//    NSLog(@"开始网络请求");
    NSLog(@"parameters==%@",parameters);
    switch (requestType) {
        case requestTypePost:{
            [self.manager POST:url parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSDictionary *responseJSON = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
                successCallback(responseJSON);
                NSLog(@"url==%@",url);
                NSLog(@"responseJSON==%@",responseJSON);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                 failureCallback(@"网络错误");
            }];
        break;}
        case requestTypeGet:{
            [self.manager GET:url parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSDictionary *responseJSON = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
                successCallback(responseJSON);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failureCallback(@"网络错误");
            }];
            break;}
        default:
            break;
    }
    
}

//- (void)liz_deleteWith:(NSString*)url success:(successCallBack)successCallback failure:(failureCallBack)failureCallback{
//    [self.manager DELETE:url parameters:nil headers:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers  error:nil];
//         NSString*msg = dictionary[@"msg"];
//        if([dictionary[@"succeed"] integerValue]==0){
//            successCallback(dictionary);
//        }else{
//            failureCallback(msg);
//        }
//        
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        failureCallback(@"网络错误");
//    }];
//}
@end
