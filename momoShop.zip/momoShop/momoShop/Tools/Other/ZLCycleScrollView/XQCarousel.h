//
//  XQCarousel.h
//  视频和图片的混合轮播
//
//  Created by xzmwkj on 2018/7/10.
//  Copyright © 2018年 WangShuai. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol XQCarouselDelegate <NSObject>

@optional

/** 图片滚动回调 */
- (void)didScrollToIndex:(NSInteger)index;

@end

@interface XQCarousel : UIView

@property (nonatomic, strong) NSArray *contentArray;

+ (instancetype)scrollViewFrame:(CGRect)frame imageStringGroup:(NSArray *)imgArray;

@property (nonatomic, weak) id<XQCarouselDelegate> delegate;


@end
