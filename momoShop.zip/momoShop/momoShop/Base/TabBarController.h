//
//  TabBarController.h
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/3/23.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "CYLTabBarController.h"
#import <CYLTabBarController/CYLTabBarController.h>

NS_ASSUME_NONNULL_BEGIN
@interface HXKCYLBaseNavigationController : UINavigationController

@end

@interface TabBarController : CYLTabBarController

@end

NS_ASSUME_NONNULL_END
