//
//  TabBarController.m
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/3/23.
//  Copyright © 2019 dmo. All rights reserved.
//

static CGFloat const CYLTabBarControllerHeight = 44.f;

@interface HXKCYLBaseNavigationController ()<UINavigationControllerDelegate,UIGestureRecognizerDelegate>

@end

@implementation HXKCYLBaseNavigationController
- (void)viewDidLoad {
    [super viewDidLoad];
    // 重新设置侧滑手势的代理
    __weak typeof(self) weakSelf = self;
    if ([self respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.interactivePopGestureRecognizer.delegate = (id)weakSelf;
    }
}
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.viewControllers.count > 0) {
//        if([viewController isKindOfClass:[LIZ_TuanDuiViewController class]]){
//            viewController.hidesBottomBarWhenPushed = NO;
//        }else{
            viewController.hidesBottomBarWhenPushed = YES;
//        }
        
    } else {
        viewController.hidesBottomBarWhenPushed = NO;
    }
    [super pushViewController:viewController animated:animated];
}
// 开始接收到手势的代理方法
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    // 判断是否是侧滑相关的手势
    if (gestureRecognizer == self.interactivePopGestureRecognizer) {
        // 如果当前展示的控制器是根控制器就不让其响应
        if (self.viewControllers.count < 2 ||
            self.visibleViewController == [self.viewControllers objectAtIndex:0]) {
            return NO;
        }
    }
    return YES;
}
// 接收到多个手势的代理方法
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    // 判断是否是侧滑相关手势
    if (gestureRecognizer == self.interactivePopGestureRecognizer && [gestureRecognizer isKindOfClass:[UIPanGestureRecognizer class]]) {
        UIPanGestureRecognizer *pan = (UIPanGestureRecognizer *)gestureRecognizer;
        CGPoint point = [pan translationInView:self.view];
        // 如果是侧滑相关的手势，并且手势的方向是侧滑的方向就让多个手势共存
        if (point.x > 0) {
            return YES;
        }
    }
    return NO;
}

@end


#import "TabBarController.h"
#import "CYLBaseNavigationController.h"
#import "HomeViewController.h"
#import "CategoryViewController.h"
#import "FindViewController.h"
#import "ShopCartViewController.h"
#import "UserViewController.h"

//@interface TabBarController ()
//@property (nonatomic,strong) UIScrollView *pageScrollView;
//
//@end

@implementation TabBarController
- (instancetype)init {
    if (!(self = [super init])) {
        return nil;
    }
    /**
     * 以下两行代码目的在于手动设置让TabBarItem只显示图标，不显示文字，并让图标垂直居中。
     * 等效于在 `-tabBarItemsAttributesForController` 方法中不传 `CYLTabBarItemTitle` 字段。
     * 更推荐后一种做法。
     */
    UIEdgeInsets imageInsets = UIEdgeInsetsZero;//UIEdgeInsetsMake(4.5, 0, -4.5, 0);
    UIOffset titlePositionAdjustment = UIOffsetZero;
    
    CYLTabBarController *tabBarController = [CYLTabBarController tabBarControllerWithViewControllers:self.viewControllers
                                                                               tabBarItemsAttributes:self.tabBarItemsAttributesForController
                                                                                         imageInsets:imageInsets
                                                                             titlePositionAdjustment:titlePositionAdjustment
                                                                                             context:nil
                                             ];
    [self customizeTabBarAppearance:tabBarController];
    return (self = (TabBarController *)tabBarController);
}
- (NSArray *)viewControllers {
    HomeViewController *firstVC = [[HomeViewController alloc] init];
    UIViewController *firstNav = [[CYLBaseNavigationController alloc] initWithRootViewController:firstVC];
    
    CategoryViewController *secondVC = [[CategoryViewController alloc] init];
    UIViewController *secondNav = [[CYLBaseNavigationController alloc] initWithRootViewController:secondVC];
    
    FindViewController *threeVC = [[FindViewController alloc] init];
    UIViewController *threeNav = [[CYLBaseNavigationController alloc] initWithRootViewController:threeVC];
    
    ShopCartViewController *fourthVC = [[ShopCartViewController alloc] init];
    UIViewController *fourthNav = [[CYLBaseNavigationController alloc] initWithRootViewController:fourthVC];
    
    UserViewController *fifthVC = [[UserViewController alloc] init];
    UIViewController *fifthNav = [[CYLBaseNavigationController alloc] initWithRootViewController:fifthVC];
    
    NSArray *viewControllers = @[firstNav,secondNav,threeNav,fourthNav,fifthNav];
    return viewControllers;
}
- (NSArray *)tabBarItemsAttributesForController {
    NSDictionary *first = @{
                             CYLTabBarItemTitle : @"首页",
                             CYLTabBarItemImage : @"tab_home_nor",  /* NSString and UIImage are supported*/
                             CYLTabBarItemSelectedImage : @"tab_home_select"  /* NSString and UIImage are supported*/
                             };
//    CGFloat secondXOffset = -15;
    NSDictionary *second = @{
                              CYLTabBarItemTitle : @"分类",
                              CYLTabBarItemImage : @"tab_category_nor",
                              CYLTabBarItemSelectedImage : @"tab_category_select"
//                              CYLTabBarItemTitlePositionAdjustment: [NSValue valueWithUIOffset:UIOffsetMake(secondXOffset, 0)]
                              };
    NSDictionary *three = @{
                             CYLTabBarItemTitle : @"发现",
                             CYLTabBarItemImage : @"tab_find_nor",
                             CYLTabBarItemSelectedImage : @"tab_find_select"
                             //                              CYLTabBarItemTitlePositionAdjustment: [NSValue valueWithUIOffset:UIOffsetMake(-secondXOffset, 0)]
                             };
    NSDictionary *fourth = @{
                              CYLTabBarItemTitle : @"购物车",
                              CYLTabBarItemImage : @"tab_cart_nor",
                              CYLTabBarItemSelectedImage : @"tab_cart_select"
//                              CYLTabBarItemTitlePositionAdjustment: [NSValue valueWithUIOffset:UIOffsetMake(-secondXOffset, 0)]
                              };
    NSDictionary *fifth =  @{
                             CYLTabBarItemTitle : @"我的",
                             CYLTabBarItemImage : @"tab_user_nor",
                             CYLTabBarItemSelectedImage : @"tab_user_select"
                             };
    NSArray *tabBarItemsAttributes = @[first, second, three,fourth, fifth];
    
    return tabBarItemsAttributes;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [[UIApplication sharedApplication] setApplicationSupportsShakeToEdit:YES];
    [self becomeFirstResponder];
}
//- (void)viewWillAppear:(BOOL)animated{
//    [super viewWillAppear:animated];
//    [self initGuidePage];
//}

/**
 *  更多TabBar自定义设置：比如：tabBarItem 的选中和不选中文字和背景图片属性、tabbar 背景图片属性等等
 */
- (void)customizeTabBarAppearance:(CYLTabBarController *)tabBarController {
    // Customize UITabBar height
    // 自定义 TabBar 高度
    //    tabBarController.tabBarHeight = CYL_IS_IPHONE_X ? 65 : 40;
    
    // set the text color for unselected state
    // 普通状态下的文字属性
    NSMutableDictionary *normalAttrs = [NSMutableDictionary dictionary];
    normalAttrs[NSForegroundColorAttributeName] = kColorFromRGB(0xb2b2b2);
    normalAttrs[NSFontAttributeName] = kFONT(12.5);
    //b2b2b2
    
    // set the text color for selected state
    // 选中状态下的文字属性
    NSMutableDictionary *selectedAttrs = [NSMutableDictionary dictionary];
    selectedAttrs[NSForegroundColorAttributeName] = kDefaultColor;
    // fc436a
    
    // set the text Attributes
    // 设置文字属性
    UITabBarItem *tabBar = [UITabBarItem appearance];
    [tabBar setTitleTextAttributes:normalAttrs forState:UIControlStateNormal];
    [tabBar setTitleTextAttributes:selectedAttrs forState:UIControlStateSelected];
    
    // Set the dark color to selected tab (the dimmed background)
    // TabBarItem选中后的背景颜色
//    [self customizeTabBarSelectionIndicatorImage];
    
    // update TabBar when TabBarItem width did update
    // If your app need support UIDeviceOrientationLandscapeLeft or UIDeviceOrientationLandscapeRight，
    // remove the comment '//'
    // 如果你的App需要支持横竖屏，请使用该方法移除注释 '//'
//    [self updateTabBarCustomizationWhenTabBarItemWidthDidUpdate];
    
    // set the bar shadow image
    // This shadow image attribute is ignored if the tab bar does not also have a custom background image.So at least set somthing.
    [[UITabBar appearance] setBackgroundImage:[[UIImage alloc] init]];
    [[UITabBar appearance] setBackgroundColor:[UIColor whiteColor]];
//    [[UITabBar appearance] setTintColor:[UIColor whiteColor]];
    [[UITabBar appearance] setShadowImage:[UIImage imageNamed:@"line"]];
    
    // set the bar background image
    // 设置背景图片
    //    UITabBar *tabBarAppearance = [UITabBar appearance];
    //
    //    //FIXED:  https://github.com/ChenYilong/CYLTabBarController/issues/312
    //    [UITabBar appearance].translucent = NO;
    //    //FIXED: https://github.com/ChenYilong/CYLTabBarController/issues/196
    //    NSString *tabBarBackgroundImageName = @"tabbarBg";
    //    UIImage *tabBarBackgroundImage = [UIImage imageNamed:tabBarBackgroundImageName];
    //    UIImage *scanedTabBarBackgroundImage = [[self class] scaleImage:tabBarBackgroundImage];
    //    [tabBarAppearance setBackgroundImage:scanedTabBarBackgroundImage];
    
    // remove the bar system shadow image
    // 去除 TabBar 自带的顶部阴影
    // iOS10 后 需要使用 `-[CYLTabBarController hideTabBadgeBackgroundSeparator]` 见 AppDelegate 类中的演示;
//    [[UITabBar appearance] setShadowImage:[[UIImage alloc] init]];
}

- (void)updateTabBarCustomizationWhenTabBarItemWidthDidUpdate {
    void (^deviceOrientationDidChangeBlock)(NSNotification *) = ^(NSNotification *notification) {
        UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
        if ((orientation == UIDeviceOrientationLandscapeLeft) || (orientation == UIDeviceOrientationLandscapeRight)) {
            //            NSLog(@"Landscape Left or Right !");
        } else if (orientation == UIDeviceOrientationPortrait) {
            //            NSLog(@"Landscape portrait!");
        }
        [self customizeTabBarSelectionIndicatorImage];
    };
    [[NSNotificationCenter defaultCenter] addObserverForName:CYLTabBarItemWidthDidChangeNotification
                                                      object:nil
                                                       queue:[NSOperationQueue mainQueue]
                                                  usingBlock:deviceOrientationDidChangeBlock];
}

- (void)customizeTabBarSelectionIndicatorImage {
    ///Get initialized TabBar Height if exists, otherwise get Default TabBar Height.
    CGFloat tabBarHeight = CYLTabBarControllerHeight;
    CGSize selectionIndicatorImageSize = CGSizeMake(CYLTabBarItemWidth, tabBarHeight);
    //Get initialized TabBar if exists.
    UITabBar *tabBar = [self cyl_tabBarController].tabBar ?: [UITabBar appearance];
    [tabBar setSelectionIndicatorImage:
     [[self class] imageWithColor:[UIColor whiteColor]
                             size:selectionIndicatorImageSize]];
}

+ (UIImage *)scaleImage:(UIImage *)image {
    CGFloat halfWidth = image.size.width/2;
    CGFloat halfHeight = image.size.height/2;
    UIImage *secondStrechImage = [image resizableImageWithCapInsets:UIEdgeInsetsMake(halfHeight, halfWidth, halfHeight, halfWidth) resizingMode:UIImageResizingModeStretch];
    return secondStrechImage;
}

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size {
    if (!color || size.width <= 0 || size.height <= 0) return nil;
    CGRect rect = CGRectMake(0.0f, 0.0f, size.width + 1, size.height);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

//#pragma mark -- 初始化引导页
//- (void)initGuidePage{
//    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"isFirstLaunch"]){
//        NSLog(@"第一次启动APP");
//        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFirstLaunch"];
//        [[NSUserDefaults standardUserDefaults] synchronize];
//
//        self.pageScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
//        self.pageScrollView.pagingEnabled = YES;
//        self.pageScrollView.showsHorizontalScrollIndicator = NO;
//        self.pageScrollView.contentSize = CGSizeMake(kScreenWidth * 5, kScreenHeight);
//        self.pageScrollView.bounces = NO;
//        [self.view addSubview:self.pageScrollView];
//
//        for (int i = 0; i < 4; i++) {
//            UIImageView *pageImageView = [UIImageView dmo_imageViewWithFrame:CGRectMake(kScreenWidth * i, 0, kScreenWidth, kScreenHeight) imageName:[NSString stringWithFormat:@"guide_page%d",i + 1]];
//            [self.pageScrollView addSubview:pageImageView];
//        }
//
//        UIButton *startButton = [UIButton dmo_buttonWithFrame:CGRectMake(kScreenWidth * 4, kScreenHeight - 46, kScreenWidth, 46) type:UIButtonTypeCustom title:@"开始使用" titleColor:[UIColor whiteColor] imageName:nil action:@selector(startButtonAction) target:self];
//        startButton.titleLabel.font = kFONT(16);
//        startButton.backgroundColor = kDefaultColor;
//        [self.pageScrollView addSubview:startButton];
//    }
//}
//- (void)startButtonAction{
//    self.pageScrollView.hidden = YES;
//}

@end
