//
//  AppDelegate.h
//  selfoperated-ios
//
//  Created by buwen zhou on 2019/5/5.
//  Copyright © 2019 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

