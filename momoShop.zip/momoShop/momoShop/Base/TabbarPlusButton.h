//
//  TabbarPlusButton.h
//  yimiaomiao-ios
//
//  Created by buwen zhou on 2019/3/23.
//  Copyright © 2019 dmo. All rights reserved.
//

#import "CYLPlusButton.h"

NS_ASSUME_NONNULL_BEGIN
//@protocol plusButtonPushDelegate <NSObject>
//- (void)plusButtonPush;
//
//@end

@interface TabbarPlusButton : CYLPlusButton<CYLPlusButtonSubclassing>
//@property(nonatomic,assign) id<plusButtonPushDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
